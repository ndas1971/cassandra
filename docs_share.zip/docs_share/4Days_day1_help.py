###Example of creating a keyspace
(Check Installation.txt on how to start cassandra in docker)

Determine the default data center name, if using NetworkTopologyStrategy, 
using nodetool status.

$ docker exec -it cass_cluster nodetool status

The output is:

Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address    Load       Tokens  Owns (effective)  Host ID      Rack
UN  127.0.0.1  41.62 KB   256     100.0%            75dcca8f...  rack1

$ docker exec -it cass_cluster cqlsh



#Use SimpleStrategy for SimpleSnitch, 
#Note replication_factor should be less than number of nodes 
#A snitch determines which datacenters and racks replication-nodes belong to

cqlsh> CREATE KEYSPACE IF NOT EXISTS cycling 
    WITH REPLICATION = { 'class' : 'SimpleStrategy', 'replication_factor' : 1 };

you can change the replication factor of a keyspace after creation 

#Use the keyspace.

cqlsh> USE cycling;

###Understanding PRIMARY KEYs 

##Using a simple primary key (PK determines Partition(node where data resides))

cqlsh> CREATE TABLE IF NOT EXISTS cycling.cyclist_name 
( id UUID, lastname text, firstname text, PRIMARY KEY (id) );

OR 
cqlsh> USE cycling;
CREATE TABLE IF NOT EXISTS cyclist_name 
    ( id UUID PRIMARY KEY, lastname text, firstname text );

OR 
cqlsh> USE cycling;
CREATE TABLE IF NOT EXISTS cyclist_name 
    ( id UUID, lastname text, firstname text, PRIMARY KEY (id) );


Many table properties, default ones are shown 

cqlsh> DESCRIBE TABLE cyclist_name;

CREATE TABLE cycling.cyclist_name (
    id uuid PRIMARY KEY,
    firstname text,
    lastname text
) WITH bloom_filter_fp_chance = 0.01  #prob that a particular SSTable has a row , 1=disable, check SSTable directly
    AND caching = {'keys': 'ALL', 'rows_per_partition': 'NONE'} #all keys cached, no rows_per_partition
    AND comment = ''  #comment of the table
    AND compaction = {'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold': '32', 'min_threshold': '4'} # when no of SStables = 4, compaction begins 
    AND compression = {'chunk_length_in_kb': '64', 'class': 'org.apache.cassandra.io.compress.LZ4Compressor'} # for compressing SSTable  , how much block is compressed 
    AND crc_check_chance = 1.0      #always check compression block for CRC 
    AND dclocal_read_repair_chance = 0.1  #prob when read repairs happens at local DC even after successful read at a CL 
    AND default_time_to_live = 0          #disable TTL for this table , in secs 
    AND gc_grace_seconds = 864000         #when data is deleted, after 10 days, data would be really deleted via compaction , Run manual compaction if required 
    AND min_index_interval = 128          #config of index summaries(IS) , lower value means faster access, but high memeory 
                                          #IS contains sampling of index(with min interval) which enables faster access to SSTable
    AND max_index_interval = 2048         #config of index summaries , max interval possible (ie sparsest possible sampling) whereas min is densest possible sampling
    AND memtable_flush_period_in_ms = 0   #disable, how frequently additional flushing happens (memtable to SSTable) (normal flusing is not impacted by this settings)
    AND read_repair_chance = 0.0        #prob when read repairs happens at all DCs even after successful read at a CL 
    AND speculative_retry = '99PERCENTILE'; # sends extra read messages even without waiting for read completion - if read takes 99% of average read time 


Insertion, update, and deletion operations on rows 
sharing the same partition key for a table are performed atomically 
and in isolation(as those rows belong to same node)

To insert simple data into the table cycling.cyclist_name, use the INSERT command. 

cqlsh> INSERT INTO cycling.cyclist_name (id, lastname, firstname) 
    VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne');

#check 
> select * from cycling.cyclist_name;

##Compound Primary Key - Partition key + clustering column
Clustering sorts data within each partition 
based on the definition of the clustering columns.

By Default , columns are sorted in ascending alphabetical order. 

cqlsh> CREATE TABLE cycling.cyclist_category ( 
    category text, 
    points int, 
    id UUID, 
    lastname text,     
    PRIMARY KEY (category, points)  //partition col: category, sorting/clustering col: points 
    ) WITH CLUSTERING ORDER BY (points DESC);
    
#Another example 
#partition col: race_id, sorting col: race_start_date  and within race_start_date , sorted by race_end_date
cqlsh> CREATE TABLE IF NOT EXISTS cycling.calendar (
   race_id int, 
   race_name text, 
   race_start_date timestamp, 
   race_end_date timestamp, 
   PRIMARY KEY (race_id, race_start_date, race_end_date)); 
   
You can insert complex string constants using double dollar signs 
to enclose a string with quotes, backslashes, or other characters 
that would normally need to be escaped.
#time eg '13:30:54.234'
#timestamp  eg '2015-05-03 13:30:54.234' , '2011-02-03' , 'yyyy-mm-dd'T'HH:mm:ssZ'

cqlsh> INSERT INTO cycling.calendar 
    (race_id, race_start_date, race_end_date, race_name) VALUES 
    (201, '2015-02-18', '2015-02-22', $$Women's Tour of New Zealand$$);
    
##Composite Partition Key - Partioning based on more keys 
Keep in mind that to retrieve data from the table, 
values for all columns defined in the partition key have to be supplied.

Cassandra stores an entire row of data on a node determined by partition keys .

cqlsh> CREATE TABLE IF NOT EXISTS cycling.rank_by_year_and_name ( 
  race_year int, 
  race_name text, 
  cyclist_name text, 
  rank int, 
  PRIMARY KEY ((race_year, race_name), rank) );

cqlsh>  TRUNCATE cycling.rank_by_year_and_name;
Insert the data:

cqlsh> 
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Benjamin PRADES', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Adam PHELAN', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Thomas LEBAS', 3);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Ilnur ZAKARIN', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Carlos BETANCUR', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2014, '4th Tour of Beijing', 'Phillippe GILBERT', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank)  
   VALUES (2014, '4th Tour of Beijing', 'Daniel MARTIN', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank)  
   VALUES (2014, '4th Tour of Beijing', 'Johan Esteban CHAVES', 3);

Use a simple SELECT query to display all data from a table.

cqlsh> EXPAND OFF;

cqlsh> SELECT * FROM cycling.rank_by_year_and_name;

race_year | race_name                                  | rank | cyclist_name
-----------+--------------------------------------------+------+----------------------
      2014 |                        4th Tour of Beijing |    1 |    Phillippe GILBERT
      2014 |                        4th Tour of Beijing |    2 |        Daniel MARTIN
      2014 |                        4th Tour of Beijing |    3 | Johan Esteban CHAVES
      2015 |   Giro d'Italia - Stage 11 - Forli > Imola |    1 |        Ilnur ZAKARIN
      2015 |   Giro d'Italia - Stage 11 - Forli > Imola |    2 |      Carlos BETANCUR
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    1 |      Benjamin PRADES
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    2 |          Adam PHELAN
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    3 |         Thomas LEBAS


#ERROR as all partioning keys are not included 
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 ;

#OK now 
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 
    AND race_name='4th Tour of Beijing';

#Use also clustering columns for sorting 
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 
    AND race_name='4th Tour of Beijing' AND rank=1;

#only  AND query, 
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 
    AND race_name='4th Tour of Beijing' AND rank >= 1;

#Allow filtering can ignore partition key, giving only clustering key, 
#but not performant as all partitions are quired
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE  rank=1 ALLOW FILTERING;

You can also pick the columns to display instead of choosing all data.

cqlsh> SELECT category, points, lastname FROM cycling.cyclist_category;

For a large table, limit the number of rows retrieved using LIMIT. 
The default limit is 10,000 rows. 
To sample data, pick a smaller number. 
To retrieve more than 10,000 rows set LIMIT to a large value.

cqlsh> SELECT * From cycling.cyclist_name LIMIT 3;

You can fine-tune the display order using the ORDER BY clause. 

The partition key must be defined in the WHERE clause and the ORDER BY clause 
defines the clustering column to use for ordering.

cqlsh> CREATE TABLE cycling.cyclist_cat_pts 
    ( category text, points int, id UUID,lastname text, 
    PRIMARY KEY (category, points) ); 

INSERT INTO cycling.cyclist_cat_pts (category, points, id, lastname) VALUES 
('GC', 780, 829aa84a-4bba-411f-a4fb-38167a987cda, 'SUTHERLAND');
INSERT INTO cycling.cyclist_cat_pts (category, points, id, lastname) VALUES 
('GC', 1269, 220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO');

cqlsh> SELECT * FROM cycling.cyclist_cat_pts WHERE category = 'GC' 
    ORDER BY points ASC;



##Controlling the number of rows returned using PER PARTITION LIMIT
PER PARTITION LIMIT option sets the maximum number of rows 
that the query returns from each partition. 

To get the top two racers in every race year and race name
(must have CLUSTERING based on  rank and DESC ordering)
use the SELECT statement with PER PARTITION LIMIT 2.

cqlsh> SELECT * FROM cycling.rank_by_year_and_name  PER PARTITION LIMIT 2;


###Understanding Clustering columns 
Partition key is always required and use with = or IN 
Use clustering keys with AND  

Identify the higher level clustering columns 
using the equals (=) or IN operators. 
and restrict the lowest level using the range operators (>, >=, <, or <=).
(higher level -> col_1, col_2, col_3, col_4 <- lower level )

cqlsh>
CREATE KEYSPACE IF NOT EXISTS dummy 
    WITH REPLICATION = { 'class' : 'SimpleStrategy', 'replication_factor' : 1 };
 
CREATE TABLE dummy.numbers (
   key int,
   col_1 int,
   col_2 int,
   col_3 int,
   col_4 int,
   PRIMARY KEY ((key), col_1, col_2, col_3, col_4));

INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,1);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,2);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,3);
INSERT INTO dummy.numbers (key, col_1, col_2, col_3, col_4) VALUES (101,2,2,2,3);
Use dummy;

#Understand 
The database stores and locates the data using a nested sort order. 
The data is stored in a hierarchy that the query must traverse:

{ "key" : "100"  { 
         "col_1" : "1"  {
                  "col_2" : "1" {
                            "col_3" : "1" { 
                                       "col_4" : "1", 
                                       "col_4" : "2", 
                                        "col_4" : "3"  },
                            "col_3" : "2" {
                                      "col_4" : "1",
                                      "col_4" : "2",
                                      "col_4" : "3"  } }, 
                  "col_2" : "2" {
                            "col_3" : "2" {
                                      "col_4" : "1",
                                      "col_4" : "2",
                                      "col_4" : "3"  } } }, 
         "col_1" : "2"  {
                  "col_2" : "1" {
                            "col_3" : "1" …

To full scan of partitions , clustering columns can be omitted 
(Partition key(which node) should never be omitted) 

> SELECT * FROM numbers WHERE key = 100;

> SELECT * FROM numbers WHERE key IN ( 100, 101) ;

Use an IN condition on the last column of the partition key only 
when it is preceded by equality conditions.

IN can also be used in clustering columns 
> SELECT * FROM numbers WHERE key IN ( 100, 101)  AND col_1 IN (1,2);

> SELECT * FROM numbers WHERE key IN ( 100, 101)  AND (col_1, col_2) IN ((1,1), (2,2));
//ie col_1=1 and col_2=1 or col_1=2 and col_2=2 
//but OR does not exists, so only can be written as IN 

key | col_1 | col_2 | col_3 | col_4
----+-------+-------+-------+-------
100 |     1 |     1 |     1 |     1
100 |     1 |     1 |     1 |     2
100 |     1 |     1 |     1 |     3
100 |     1 |     1 |     2 |     1
100 |     1 |     1 |     2 |     2
100 |     1 |     1 |     2 |     3
100 |     2 |     2 |     2 |     1
100 |     2 |     2 |     2 |     2
100 |     2 |     2 |     2 |     3
101 |     2 |     2 |     2 |     3

Compare this with 
> SELECT * FROM numbers WHERE key IN ( 100, 101)  AND col_1 IN (1,2) AND col_2 IN (1,2);

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     1 |     1 |     1 |     3
 100 |     1 |     1 |     2 |     1
 100 |     1 |     1 |     2 |     2
 100 |     1 |     1 |     2 |     3
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     3
 100 |     2 |     1 |     2 |     1
 100 |     2 |     1 |     2 |     2
 100 |     2 |     1 |     2 |     3
 100 |     2 |     2 |     2 |     1
 100 |     2 |     2 |     2 |     2
 100 |     2 |     2 |     2 |     3
 101 |     2 |     2 |     2 |     3

Compare this with 
> SELECT * FROM numbers WHERE key IN ( 100, 101)  AND (col_1, col_2) >= (1,1);
//ie col_1 =1 and col_2 >= 1 or col_1 = 2 and col_2 >= 1 .....
//but OR does not exists, so only can be written as >=  
 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     1 |     1 |     1 |     3
 100 |     1 |     1 |     2 |     1
 100 |     1 |     1 |     2 |     2
 100 |     1 |     1 |     2 |     3
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     3
 100 |     2 |     1 |     2 |     1
 100 |     2 |     1 |     2 |     2
 100 |     2 |     1 |     2 |     3
 100 |     2 |     2 |     2 |     1
 100 |     2 |     2 |     2 |     2
 100 |     2 |     2 |     2 |     3
 101 |     2 |     2 |     2 |     3

(note lower level clustering can be omitted, but never higher level.. 
check non-performant workaround ALLOW filtering) 

To make queries more efficient, 
the database requires that the higher level columns in the sort order 
(col_1, col_2, and col_3) are identified using the equals or IN operators. 

Ranges, (>, >=, <, or <=) are allowed on the last column (col_4).

> SELECT * FROM numbers 
WHERE key = 100 
AND col_1 = 1 AND col_2 = 1 AND col_3 = 1
AND col_4 <= 2;

The results contain the first two rows:

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2

(2 rows)

The IN operator can impact performance on medium-large datasets. 

>  SELECT * FROM numbers 
WHERE key = 100 
AND col_1 IN (1, 2) 
AND col_2 = 1 AND col_3 = 1
AND col_4 <= 2;


 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2

(4 rows)


##Invalid restrictions
Below Works 
> SELECT * FROM numbers; //OK as below is implied 
> SELECT * FROM numbers ALLOW FILTERING;

But, Queries that attempt to return ranges without identifying 
any of the higher level segments are rejected:

> SELECT * FROM numbers 
WHERE key = 100 
AND col_4 <= 2;  //no higher level, so rejected , Use ALLOW FILTERING explicitely

The request is invalid:

InvalidRequest: Error from server: code=2200 [Invalid query] message="PRIMARY KEY column "col_4" 
cannot be restricted as preceding column "col_1" is not restricted"

CAUTION: You can force the query using the ALLOW FILTERING option; 
however, this loads the entire partition and negatively impacts performance 
by causing long READ latencies.

> SELECT * FROM numbers 
WHERE key = 100 
AND col_4 <= 2 ALLOW FILTERING;

##Only restricting top level clustering columns
Unlike partition columns, a query can omit lower level clustering column 
in logical statements.

> SELECT * FROM numbers 
WHERE key = 100 AND col_1 = 1
AND col_2 > 1;

The query returns the following data:

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3

(3 rows)

##Slice syntax - using range_operator (>, >=, <, or <=)
(clustering1, clustering2[, ...]) range_operator (value1, value2[, ...]) 
    [AND (clustering1, clustering2[, ...]) range_operator (value1, value2[, ...])]

The following statement identifies the row where column 1, 2, and 3 
are equal to 2 and column 4 is less than or equal to 1.
(note this query can be not written as <= can only be used against last column
not higher level)

> SELECT * FROM numbers
WHERE key = 100 
AND (col_1, col_2, col_3, col_4) <= (2, 2, 2, 1);

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     1 |     1 |     1 |     3
 100 |     1 |     1 |     2 |     1
 100 |     1 |     1 |     2 |     2
 100 |     1 |     1 |     2 |     3
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     3
 100 |     2 |     1 |     2 |     1
 100 |     2 |     1 |     2 |     2
 100 |     2 |     1 |     2 |     3
 100 |     2 |     2 |     2 |     1

(16 rows)
it is tricky to find out how many rows are returned   because it returns 
all rows below (2, 2, 2, 1)(based on sorted storage), well in this case, might be easy.. 
but check next case 

> SELECT * FROM numbers where key=100;

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     1 |     1 |     1 |     3
 100 |     1 |     1 |     2 |     1
 100 |     1 |     1 |     2 |     2
 100 |     1 |     1 |     2 |     3
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     3 
 100 |     2 |     1 |     2 |     1
 100 |     2 |     1 |     2 |     2
 100 |     2 |     1 |     2 |     3
 100 |     2 |     2 |     2 |     1   <---- 
 
 
 100 |     2 |     2 |     2 |     2
 100 |     2 |     2 |     2 |     3

The location might be hypothetical, 
that is the dataset does not contain a row that exactly matches the values. 
For example, the query specifies slice values of (2, 1, 1, 4).
Nevertheless, returns results which satisfies range 

> SELECT * FROM numbers
WHERE key = 100 
AND (col_1, col_2, col_3, col_4) <= (2, 1, 1, 4);

Note it is tricky to find out how many rows are returned because 
col_2 contains 2 . This is because how the data is stored and all rows 
below (2, 1, 1, 4) are returned 

key | col_1 | col_2 | col_3 | col_4
----+-------+-------+-------+-------
100 |     1 |     1 |     1 |     1
100 |     1 |     1 |     1 |     2
100 |     1 |     1 |     1 |     3
100 |     1 |     1 |     2 |     1
100 |     1 |     1 |     2 |     2
100 |     1 |     1 |     2 |     3
100 |     1 |     2 |     2 |     1
100 |     1 |     2 |     2 |     2
100 |     1 |     2 |     2 |     3
100 |     2 |     1 |     1 |     1
100 |     2 |     1 |     1 |     2
100 |     2 |     1 |     1 |     3
(12 rows)

> SELECT * FROM numbers where key=100;

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     1 |     1 |     1 |     3
 100 |     1 |     1 |     2 |     1
 100 |     1 |     1 |     2 |     2
 100 |     1 |     1 |     2 |     3
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     3  <---- 
 
 100 |     2 |     1 |     2 |     1
 100 |     2 |     1 |     2 |     2
 100 |     2 |     1 |     2 |     3
 100 |     2 |     2 |     2 |     1
 100 |     2 |     2 |     2 |     2
 100 |     2 |     2 |     2 |     3

> SELECT * FROM numbers  
WHERE key = 100 AND col_1 = 1 AND col_2 = 1 
AND (col_3, col_4) >= (1, 2) 
AND (col_3, col_4) < (2, 3);

key | col_1 | col_2 | col_3 | col_4
----+-------+-------+-------+------
100 |     1 |     1 |     1 |     2
100 |     1 |     1 |     1 |     3
100 |     1 |     1 |     2 |     1
100 |     1 |     1 |     2 |     2

When returning a slice between two rows, 
the slice statements must define the same clustering columns. 
The query is rejected if the columns are different:
#BELOW IS WRONG 
> SELECT * FROM numbers
WHERE key = 100 AND col_1 = 1  
AND (col_2, col_3, col_4) >= (1, 1, 2) 
AND (col_3, col_4) < (2, 3);

InvalidRequest: Error from server: code=2200 [Invalid query] 
message="Column "col_3" cannot be restricted by two inequalities not starting with the same col


###IMP - AVOID Range Slice as far as possible as not performant -- ADVANCED 
A query will be processed as a range slice if it it meets any of below 
    no partition key in the WHERE clause
    the IN operator is used on a column that is not a partition key
    the TOKEN function is used.
    Slices of clustering segments 
        (clustering1, clustering2[, ...]) range_operator (value1, value2[, ...]) 
        [AND (clustering1, clustering2[, ...]) range_operator (value1, value2[, ...])]

#Example 
CREATE TABLE IF NOT EXISTS dummy.demo_users (
    name text,
    age int,
    data text,
    PRIMARY KEY ((name), age)
);

#the following queries would all be processed as range slices:
SELECT * FROM dummy.demo_users
(no partition key in WHERE clause)

SELECT * FROM dummy.demo_users WHERE age > 50 ALLOW FILTERING
(no partition key in WHERE clause)

SELECT * FROM dummy.demo_users WHERE (age) IN (29, 30, 31) ALLOW FILTERING
(IN statement used on non-partition key)

SELECT * FROM dummy.demo_users WHERE token(name) > 15535
(TOKEN function used)
    
##How can I avoid problems with range slices?
The ideal approach is to stop using above queries . 
This usually involves:
    splitting up one range slice query into multiple queries 
        that hit one partition each, 
    or
    creating a new table with different partition keys 
    so that the necessary data can be easily read via partition keys.
    (we would check in datamodel)


###Creating a counter table
A counter is a special column used to store an integer that is changed 
in increments.

Counters are useful for many data models. 
Some examples:
    To keep track of the number of web page views received on a company website
    To keep track of the number of games played online or the number of players who have joined an online game

To implement a counter column, create a table that only includes(MUST)
    The primary key (can be one or more columns)
        Use all non-counter columns as part of the PRIMARY KEY definition.
    The counter column

Many counter-related settings can be set in the cassandra.yaml file.
https://cassandra.apache.org/doc/latest/cassandra/configuration/cass_yaml_file.html
eg counter_write_request_timeout_in_ms, counter_cache_size_in_mb, 
counter_cache_save_period, counter_cache_keys_to_save

A counter column cannot be indexed or deleted.

To load data into a counter column, or to increase or decrease 
the value of the counter, use the UPDATE command. 

Cassandra rejects USING TIMESTAMP or USING TTL when updating a counter column.

cqlsh> USE cycling;
    CREATE TABLE popular_count (
      id UUID PRIMARY KEY,
      popularity counter
      );

Loading data into a counter column is different than other tables. 
The data is updated rather than inserted.

cqlsh> UPDATE cycling.popular_count
 SET popularity = popularity + 1  //can only be incr/decremented , +/- N 
 WHERE id = 6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47;

Take a look at the counter value and note that popularity has a value of 1.

cqlsh> SELECT * FROM cycling.popular_count;

Additional increments or decrements will change the value of the counter column. 


###Creating columns with a single value (static column)
In a table that uses clustering columns(must have clustering columns), 
Any/all non-clustering and non partitioning columns can be declared 
static  in the table definition. 

Static columns are only static/constant for each partition 
(ie static for a partition key, which is not dependent on clustering cols)

> CREATE TABLE t (
  k text,
  s text STATIC,
  i int,
  PRIMARY KEY (k, i)
);
INSERT INTO t (k, s, i) VALUES ('k', 'I''m shared', 0);
INSERT INTO t (k, s, i) VALUES ('k', 'I''m still shared', 1);
SELECT * FROM t;

Output:

 k |                  s | i   
----------------------------
k  | "I'm still shared" | 0 
k  | "I'm still shared" | 1       

Use the DISTINCT keyword to select static columns. 
In this case, the database retrieves only the beginning (static column) 
of the partition, hence performant 

> SELECT DISTINCT s FROM t;

Remove the table 
cqlsh> DROP table t;

###Quick Data types 
Data Type- Time Highlights
time eg '13:30:54.234'
timestamp  eg '2015-05-03 13:30:54.234' , '2011-02-03' , 'yyyy-mm-dd'T'HH:mm:ssZ'

Complex data type 
    set<T> { literal, literal, literal }
    list<T>  [ literal, literal, literal ]
    map<T,T> { literal: literal, ... }
    
list<text> nested not possible, to nest use frozen 
list<frozen <list<int>>>, but can not be updated element wise 

tuple<T,T,T…>  (3, 'bar', 2.1)
UDT { birthday : '1993-06-18', nationality : 'New Zealand', }

###Creating the set type 
(preferred compared to list - Use for low cardninality data) 
A set consists of a group of elements with unique values. 

The values of a set are stored unordered, but will return the elements in sorted 
order when queried. 

Use the set data type to store data that has a 
many-to-one/one-to-many relationship with another column. 

For example, in the example below, a set called teams stores 
all the teams that a cyclist has been a member of during their career.

cqlsh> CREATE TABLE cycling.cyclist_career_teams 
    ( id UUID PRIMARY KEY, lastname text, teams set<text> );

##Inserting and updating data into a set

cqlsh>INSERT INTO cycling.cyclist_career_teams (id,lastname,teams) 
  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS', 
  { 'Rabobank-Liv Woman Cycling Team','Rabobank-Liv Giant','Rabobank Women Team','Nederland bloeit' } );

Use + or - to add/remove from Set (one of many items)

cqlsh> UPDATE cycling.cyclist_career_teams 
  SET teams = teams + {'Team DSB - Ballast Nedam'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

cqlsh> UPDATE cycling.cyclist_career_teams
  SET teams = teams - {'Team DSB - Ballast Nedam'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

A set, list, or map needs to have at least one element 
because an empty set, list, or map is stored as a null .

cqlsh> UPDATE cycling.cyclist_career_teams SET teams = {} 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;
#OR equivalent 
cqlsh> DELETE teams FROM cycling.cyclist_career_teams 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

A query for the teams returns null.

cqlsh> SELECT id, teams FROM cycling.cyclist_career_teams  
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Delete entire row 
cqlsh> DELETE FROM cycling.cyclist_career_teams 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Now update would insert this (other values would be null)
> UPDATE cycling.cyclist_career_teams 
  SET teams = teams + {'Team DSB - Ballast Nedam'} 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

When using the frozen keyword, you cannot update parts of nested set . 
(but for nested collection, frozen is must)
Read full and the manipulate 

> CREATE TABLE cycling.cyclist_career_teams_f 
    ( id UUID PRIMARY KEY, lastname text, teams set<frozen<set<text> > > );

> INSERT INTO cycling.cyclist_career_teams_f (id,lastname,teams) 
  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS', 
  { {'A','B'}, {'A', 'C'} } );

> select * from cycling.cyclist_career_teams_f;

Use + and - to add/remove on outer one, 
but Inner one is frozen so can not be updated individually 
 
> UPDATE cycling.cyclist_career_teams_f
  SET teams = teams + {{'D','E'}} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

> UPDATE cycling.cyclist_career_teams_f
  SET teams = teams - {{'D','E'}} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;


###Creating the list type (duplicates and in order)
Use it for  many-to-one relationship with another column.
 

cqlsh> CREATE TABLE cycling.upcoming_calendar 
    ( year int, month int, events list<text>, PRIMARY KEY ( year, month) );

cqlsh> INSERT INTO cycling.upcoming_calendar 
    (year, month, events) VALUES (2015, 06, 
    ['Criterium du Dauphine','Tour de Suisse']);

Use the UPDATE command to insert values into the list. 

Use +/- to add/remove, Can do prepend/append by putting elements before/after 
Appending and prepending a new element to the list writes only the new element.
(so performant) 

> UPDATE cycling.upcoming_calendar
    SET events = ['The Parx Casino Philly Cycling Classic'] + events 
    WHERE year = 2015 AND month = 06;

//append 
UPDATE cycling.upcoming_calendar 
    SET events = events + ['Tour de France Stage 10'] 
    WHERE year = 2015 AND month = 06;

Mutate an element , but cassandra reads full list and then update (so not performant)
(zero based, if more than length, throws error - index out of bounds)

> UPDATE cycling.upcoming_calendar 
    SET events[0] = 'Vuelta Ciclista a Venezuela' 
    WHERE year = 2015 AND month = 06;

Remove an element 
(non existence index is errored)
cqlsh> DELETE events[1] FROM cycling.upcoming_calendar 
    WHERE year = 2015 AND month = 06;

If another thread or client prepends elements to the list 
before the operation is done, incorrect data will be removed.

Remove all elements having a particular value 

> UPDATE cycling.upcoming_calendar 
    SET events = events - ['Tour de France Stage 10'] 
    WHERE year = 2015 AND month = 06;

Note individual elements eg events[0] can not be selected 

cqlsh> select * from cycling.upcoming_calendar;

#Using frozen for nested collection - inner list is frozen 
> CREATE TABLE cycling.upcoming_calendar_f 
    ( year int, month int, events list<frozen <list<text> > >, 
    PRIMARY KEY ( year, month) );

> INSERT INTO cycling.upcoming_calendar_f 
    (year, month, events) 
    VALUES (2015, 06, [['Criterium du Dauphine','Tour de Suisse']]);

> UPDATE cycling.upcoming_calendar_f 
    SET events = [['The Parx Casino Philly Cycling Classic']] + events 
    WHERE year = 2015 AND month = 06;

> UPDATE cycling.upcoming_calendar_f 
    SET events = events + [['Tour de France Stage 10']] 
    WHERE year = 2015 AND month = 06;

There is no nested syntax like events[0][0] , full list should be updated 
(in driver, probably, read events at first, then modify in driver language and replace the entire list)
> UPDATE cycling.upcoming_calendar_f 
    SET events[0] = ['Vuelta Ciclista a Venezuela'] 
    WHERE year = 2015 AND month = 06;

> select * from cycling.upcoming_calendar_f;



###Creating the map type
(Key value pair, keys are like set-unique)

cqlsh> CREATE TABLE cycling.cyclist_teams 
    ( id UUID PRIMARY KEY, lastname text, firstname text, teams map<int,text> );

> INSERT INTO cycling.cyclist_teams (id, lastname, firstname, teams) 
VALUES (
  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,
  'VOS', 
  'Marianne', 
  {2015 : 'Rabobank-Liv Woman Cycling Team', 
  2014 : 'Rabobank-Liv Woman Cycling Team', 2013 : 'Rabobank-Liv Giant', 
    2012 : 'Rabobank Women Team', 2011 : 'Nederland bloeit' }); 

Note: Using INSERT in this manner will replace the entire map.

Use +/- to add/remove key-value element 

> UPDATE cycling.cyclist_teams 
    SET teams = teams + {2009 : 'DSB Bank - Nederland bloeit'} 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Update an value  
(if existing , update, else create new K:V pair)

cqlsh> UPDATE cycling.cyclist_teams 
    SET teams[2006] = 'Team DSB - Ballast Nedam' 
    WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Delete an element 
(non existence key is silently ignored)

cqlsh> DELETE teams[2009] 
    FROM cycling.cyclist_teams WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

remove all elements having a particular value 

cqlsh> UPDATE cycling.cyclist_teams 
    SET teams = teams - {2013,2014} 
    WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;
    
Select 
cqlsh > select * from cycling.cyclist_teams
    WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Use frozen, all the above holds good, 
but note that there is no nested [][] indexing syntax 

> CREATE TABLE cycling.cyclist_teams_f 
    ( id UUID PRIMARY KEY, lastname text, firstname text, 
    teams list< frozen <map<int,text> > >);
    
> CREATE TABLE cycling.cyclist_teams_ff 
    ( id UUID PRIMARY KEY, lastname text, firstname text, 
    teams map<int, frozen< list<text> > >);



