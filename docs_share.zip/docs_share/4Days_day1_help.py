DAY-1
    Cassandra Introduction 
        Architecture requirements 
        CQL Quick Concepts
        CQL vs SQL
        Introducing Replication in Cassandra
        Replication strategy
    Understanding CQL  
    Creating and updating a keyspace
    Creating a table
        Various type of Partition key
    Creating advanced data types in tables
        set, list, map - when to use 
        tuple and UDT 
    Creating functions
    Inserting and updating data
    Querying tables
    Setting TTL for a table and columns 
----------------------------------------------

###Creating and updating a keyspace
https://docs.datastax.com/en/cql-oss/3.3/cql/cql_using/useCreateKeyspace.html

If you fail to change the default snitch and use NetworkTopologyStrategy, 
Cassandra will fail to complete any write request, such as inserting data into a table, 
and log this error message:

Unable to complete request: one or more nodes were unavailable.

#Syntax 
CREATE  KEYSPACE [IF NOT EXISTS] keyspace_name WITH REPLICATION = { 
      'class' : 'SimpleStrategy', 'replication_factor' : N } 
     | 'class' : 'NetworkTopologyStrategy', 
       'dc1_name' : N [, ...] 
   } AND durable_writes = true;
   
DURABLE_WRITES = true|false
    false: bypass the commit log when writing to the keyspace by disabling durable writes 
    Default value is true.
    CAUTION: Never disable durable writes when using SimpleStrategy replication.


##Example of creating a keyspace
Determine the default data center name, if using NetworkTopologyStrategy, using nodetool status.

$ docker exec -it cass_cluster nodetool status

The output is:

Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address    Load       Tokens  Owns (effective)  Host ID      Rack
UN  127.0.0.1  41.62 KB   256     100.0%            75dcca8f...  rack1

$ docker exec -it cass_cluster cqlsh

Note ~/.cassandra/cqlshrc defines many cqlsh options like default user etc 
https://docs.datastax.com/en/archived/cql/3.3/cql/cql_reference/cqlshUsingCqlshrc.html
;; Used for displaying timestamps (and reading them with COPY)
; datetimeformat = %Y-%m-%d %H:%M:%S%z


#Use SimpleStrategy for SimpleSnitch, Note replication_factor should be less than number of nodes 
#A snitch determines which datacenters and racks nodes belong to

cqlsh> CREATE KEYSPACE IF NOT EXISTS cycling WITH REPLICATION = { 'class' : 'SimpleStrategy', 'replication_factor' : 1 };


#Use the keyspace.

cqlsh> USE cycling;

### PRIMARY KEYs 

##Using a simple primary key (PK determines Partition)
Use a simple primary key to create a single column that you can use to query and return results. 

cqlsh> USE cycling;
CREATE TABLE IF NOT EXISTS cyclist_name ( id UUID PRIMARY KEY, lastname text, firstname text );

OR 
cqlsh> USE cycling;
CREATE TABLE IF NOT EXISTS cyclist_name ( id UUID, lastname text, firstname text, PRIMARY KEY (id) );

OR 
cqlsh> CREATE TABLE IF NOT EXISTS cycling.cyclist_name ( id UUID, lastname text, firstname text, PRIMARY KEY (id) );

Many table properties, default ones are shown 
cqlsh> DESCRIBE TABLE cyclist_name;
CREATE TABLE cycling.cyclist_name (
    id uuid PRIMARY KEY,
    firstname text,
    lastname text
) WITH bloom_filter_fp_chance = 0.01  #prob that a particular SSTable has a row , 1=disable, check SSTable directly
    AND caching = {'keys': 'ALL', 'rows_per_partition': 'NONE'} #all rows cached, no limit on ows_per_partition
    AND comment = ''  #comment of the table
    AND compaction = {'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold': '32', 'min_threshold': '4'} # when no of SStables = 4, compaction begins 
    AND compression = {'chunk_length_in_kb': '64', 'class': 'org.apache.cassandra.io.compress.LZ4Compressor'} # for compressing SSTable  , how much block is compressed 
    AND crc_check_chance = 1.0      #always check compression block for CRC 
    AND dclocal_read_repair_chance = 0.1  #prob when read repairs happens at local DC even after successful read at a CL 
    AND default_time_to_live = 0          #disable TTL for this table , in secs 
    AND gc_grace_seconds = 864000         #when data is deleted, after 10 days, data would be really deleted via compaction , Run manual compaction if required 
    AND min_index_interval = 128          #config of index summaries(IS) , lower value means faster access, but high memeory 
                                          #IS contains sampling of index(with min interval) which enables faster access to SSTable
    AND max_index_interval = 2048         #config of index summaries , max interval possible (ie sparsest possible sampling) whereas min is densest possible sampling
    AND memtable_flush_period_in_ms = 0   #disable, how frequently additional flushing happens (memtable to SSTable) (normal flusing is not impacted by this settings)
    AND read_repair_chance = 0.0        #prob when read repairs happens at all DCs even after successful read at a CL 
    AND speculative_retry = '99PERCENTILE'; # sends extra read messages even without waiting for read completion - if read takes 99% of average read time 


Insertion, update, and deletion operations on rows sharing the same partition key 
for a table are performed atomically and in isolation(as those rows belong to same node)

To insert simple data into the table cycling.cyclist_name, use the INSERT command. 

cqlsh> INSERT INTO cycling.cyclist_name (id, lastname, firstname) VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne');

#check 
> select * from cycling.cyclist_name;

##Compound Primary Key - Partition key + clustering column
Clustering is a storage engine process that sorts data within each partition 
based on the definition of the clustering columns. 

By Default , columns are sorted in ascending alphabetical order. 

cqlsh> CREATE TABLE cycling.cyclist_category ( 
    category text, 
    points int, 
    id UUID, 
    lastname text,     
    PRIMARY KEY (category, points)  //partition col: category, sorting/clustering col: points 
    ) WITH CLUSTERING ORDER BY (points DESC);
    
#Another example 
#partition col: race_id, sorting col: race_start_date  and within race_start_date , sorted by race_end_date
cqlsh> CREATE TABLE IF NOT EXISTS cycling.calendar (
   race_id int, 
   race_name text, 
   race_start_date timestamp, 
   race_end_date timestamp, 
   PRIMARY KEY (race_id, race_start_date, race_end_date)); 
   
You can insert complex string constants using double dollar signs to enclose a string 
with quotes, backslashes, or other characters that would normally need to be escaped.
#time eg '13:30:54.234'
#timestamp  eg '2015-05-03 13:30:54.234' , '2011-02-03' , 'yyyy-mm-dd'T'HH:mm:ssZ'

cqlsh> INSERT INTO cycling.calendar (race_id, race_start_date, race_end_date, race_name) VALUES 
  (201, '2015-02-18', '2015-02-22', $$Women's Tour of New Zealand$$);
    
##Composite Partition Key - Partioning based on more keys 
Keep in mind that to retrieve data from the table, values for all columns defined in the partition key 
have to be supplied.

Cassandra stores an entire row of data on a node determined by partition keys .

cqlsh> USE cycling;
    CREATE TABLE rank_by_year_and_name ( 
    race_year int, 
    race_name text, 
    cyclist_name text, 
    rank int, 
    PRIMARY KEY ((race_year, race_name), rank) 
    );
#OR 
cqlsh> CREATE TABLE IF NOT EXISTS cycling.rank_by_year_and_name ( 
  race_year int, 
  race_name text, 
  cyclist_name text, 
  rank int, 
  PRIMARY KEY ((race_year, race_name), rank) );

cqlsh>  TRUNCATE cycling.rank_by_year_and_name;
Insert the data:

cqlsh> 
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Benjamin PRADES', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Adam PHELAN', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Thomas LEBAS', 3);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Ilnur ZAKARIN', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Carlos BETANCUR', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank) 
   VALUES (2014, '4th Tour of Beijing', 'Phillippe GILBERT', 1);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank)  
   VALUES (2014, '4th Tour of Beijing', 'Daniel MARTIN', 2);
INSERT INTO cycling.rank_by_year_and_name (race_year, race_name, cyclist_name, rank)  
   VALUES (2014, '4th Tour of Beijing', 'Johan Esteban CHAVES', 3);

Use a simple SELECT query to display all data from a table.

cqlsh> EXPAND OFF;

cqlsh> SELECT * FROM cycling.rank_by_year_and_name;

race_year | race_name                                  | rank | cyclist_name
-----------+--------------------------------------------+------+----------------------
      2014 |                        4th Tour of Beijing |    1 |    Phillippe GILBERT
      2014 |                        4th Tour of Beijing |    2 |        Daniel MARTIN
      2014 |                        4th Tour of Beijing |    3 | Johan Esteban CHAVES
      2015 |   Giro d'Italia - Stage 11 - Forli > Imola |    1 |        Ilnur ZAKARIN
      2015 |   Giro d'Italia - Stage 11 - Forli > Imola |    2 |      Carlos BETANCUR
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    1 |      Benjamin PRADES
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    2 |          Adam PHELAN
      2015 | Tour of Japan - Stage 4 - Minami > Shinshu |    3 |         Thomas LEBAS


The example below illustrates how to create a query that uses category as a filter.

#ERROR as all partioning keys are not included 
cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 ;

#OK now 
SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 AND race_name='4th Tour of Beijing';

#Use also clustering columns for sorting 
SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 AND race_name='4th Tour of Beijing' AND rank=1;

#ONly AND query, 
SELECT * FROM cycling.rank_by_year_and_name WHERE race_year = 2014 AND race_name='4th Tour of Beijing' AND rank>=1;

#Allow filtering can ignore partition key, giving only clustering key, but not performant as all partitions are quired
SELECT * FROM cycling.rank_by_year_and_name WHERE  rank=1 ALLOW FILTERING;

You can also pick the columns to display instead of choosing all data.

cqlsh> SELECT category, points, lastname FROM cycling.cyclist_category;

For a large table, limit the number of rows retrieved using LIMIT. 
The default limit is 10,000 rows. 
To sample data, pick a smaller number. To retrieve more than 10,000 rows set LIMIT to a large value.

cqlsh> SELECT * From cycling.cyclist_name LIMIT 3;

You can fine-tune the display order using the ORDER BY clause. 

The partition key must be defined in the WHERE clause and the ORDER BY clause 
defines the clustering column to use for ordering.

cqlsh> CREATE TABLE cycling.cyclist_cat_pts ( category text, points int, id UUID,lastname text, PRIMARY KEY (category, points) ); 

INSERT INTO cycling.cyclist_cat_pts (category, points, id, lastname) VALUES 
('GC', 780, 829aa84a-4bba-411f-a4fb-38167a987cda, 'SUTHERLAND');
INSERT INTO cycling.cyclist_cat_pts (category, points, id, lastname) VALUES 
('GC', 1269, 220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO');

cqlsh> SELECT * FROM cycling.cyclist_cat_pts WHERE category = 'GC' ORDER BY points ASC;



##Controlling the number of rows returned using PER PARTITION LIMIT
PER PARTITION LIMIT option sets the maximum number of rows that the query returns from each partition. 
To get the top two racers in every race year and race name
(must have CLUSTERING based on  rank and DESC ordering)
use the SELECT statement with PER PARTITION LIMIT 2.

cqlsh> SELECT * FROM cycling.rank_by_year_and_name  PER PARTITION LIMIT 2;


###Understanding Clustering columns 
Because the database uses the clustering columns to determine the location of the data 
on a particular  partition, you must identify the higher level clustering columns 
definitively using the equals (=) or IN operators. 

In a query, you can only restrict the lowest level using the range operators (>, >=, <, or <=).

CREATE TABLE numbers (
   key int,
   col_1 int,
   col_2 int,
   col_3 int,
   col_4 int,
   PRIMARY KEY ((key), col_1, col_2, col_3, col_4));

INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,1,3);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,1,2,3);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,1,2,2,3);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,1,3);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,1,2,3);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,1);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,2);
INSERT INTO numbers (key, col_1, col_2, col_3, col_4) VALUES (100,2,2,2,3);


The database stores and locates the data using a nested sort order. 
The data is stored in a hierarchy that the query must traverse:

{ "key" : "100"  { 
         "col_1" : "1"  {
                  "col_2" : "1" {
                            "col_3" : "1" { 
                                       "col_4" : "1", 
                                       "col_4" : "2", 
                                        "col_4" : "3"  },
                            "col_3" : "2" {
                                      "col_4" : "1",
                                      "col_4" : "2",
                                      "col_4" : "3"  } }, 
                  "col_2" : "2" {
                            "col_3" : "2" {
                                      "col_4" : "1",
                                      "col_4" : "2",
                                      "col_4" : "3"  } } }, 
         "col_1" : "2"  {
                  "col_2" : "1" {
                            "col_3" : "1" …

To full scan of partitions , clustering columns can be omitted (Partition key(which node) can never be omitted) 
> SELECT * FROM numbers WHERE key = 100;

To avoid full scans of the partition and to make queries more efficient, 
the database requires that the higher level columns in the sort order (col_1, col_2, and col_3) 
are identified using the equals or IN operators. 

Ranges are allowed on the last column (col_4).

> SELECT * FROM numbers 
WHERE key = 100 
AND col_1 = 1 AND col_2 = 1 AND col_3 = 1
AND col_4 <= 2;

The results contain the first two rows:

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2

(2 rows)

The IN operator can impact performance on medium-large datasets. 
When selecting multiple segments, the database loads and filters all the specified segments.

Tip: Use TRACING [ON | OFF] to analyze the impact of various queries in your environment.

For example, to find all values less than or equal to 2 in both col_1 segments 1 and 2:

>  SELECT * FROM numbers 
WHERE key = 100 
AND col_1 IN (1, 2) 
AND col_2 = 1 AND col_3 = 1
AND col_4 <= 2;


 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     1 |     1 |     1
 100 |     1 |     1 |     1 |     2
 100 |     2 |     1 |     1 |     1
 100 |     2 |     1 |     1 |     2

(4 rows)


##Invalid restrictions
Below Works 
> SELECT * FROM numbers; //OK as below is implied 
> SELECT * FROM numbers ALLOW FILTERING;

But, Queries that attempt to return ranges without identifying any of the higher level segments are rejected:

> SELECT * FROM numbers 
WHERE key = 100 
AND col_4 <= 2;

The request is invalid:

InvalidRequest: Error from server: code=2200 [Invalid query] message="PRIMARY KEY column "col_4" 
cannot be restricted as preceding column "col_1" is not restricted"

CAUTION: You can force the query using the ALLOW FILTERING option; 
however, this loads the entire partition and negatively impacts performance by causing long READ latencies.

> SELECT * FROM numbers 
WHERE key = 100 
AND col_4 <= 2 ALLOW FILTERING;

#Only restricting top level clustering columns
Unlike partition columns, a query can omit lower level clustering column in logical statements.

For example, to filter one of the mid-level columns, restrict the first level column using equals or IN, 
then specify a range on the second level:

> SELECT * FROM numbers 
WHERE key = 100 AND col_1 = 1
AND col_2 > 1;

The query returns the following data:

 key | col_1 | col_2 | col_3 | col_4
-----+-------+-------+-------+-------
 100 |     1 |     2 |     2 |     1
 100 |     1 |     2 |     2 |     2
 100 |     1 |     2 |     2 |     3

(3 rows)

Returning ranges that span clustering segments

##Slice syntax:
(clustering1, clustering2[, ...]) range_operator (value1, value2[, ...]) 
[AND (clustering1, clustering2[, ...]) range_operator (value1, value2[, ...])]

#Slices across full partition
The slice determines the exact location within the sorted columns; 
therefore, the highest level is evaluated first, then the second, and so forth in order to drill down 
to the precise row location. 

The following statement identifies the row where column 1, 2, and 3 
are equal to 2 and column 4 is less than or equal to 1.
(Highest levels are = even though it is <=) 

The database locates the matching row and then returns every record 
before the identified row in the results set.

> SELECT * FROM numbers
WHERE key = 100 
AND (col_1, col_2, col_3, col_4) <= (2, 2, 2, 1);


The location might be hypothetical, that is the dataset does not contain a row that exactly matches the values. 
For example, the query specifies slice values of (2, 1, 1, 4).

> SELECT * FROM numbers
WHERE key = 100 
AND (col_1, col_2, col_3, col_4) <= (2, 1, 1, 4);

The query finds where the row would be in the order if a row with those values existed 
and returns all rows before it:

##Slices of clustering segments
The same rules apply to slice restrictions when finding a slice on a lower level segment; 
identify the higher level clustering segments using equals or IN 
and specify a range on the lower segments.

For example, to return rows where the value is greater than (1, 3) and less than or equal to (2, 5):

> SELECT * FROM numbers  
WHERE key = 100 AND col_1 = 1 AND col_2 = 1 
AND (col_3, col_4) >= (1, 2) 
AND (col_3, col_4) < (2, 3);

When finding a between range, the two slice statements must be on the same columns 
for lowest columns in the hierarchy.

##Invalid queries
When returning a slice between two rows, the slice statements must define the same clustering columns. 
The query is rejected if the columns are different:

> SELECT * FROM numbers
WHERE key = 100 AND col_1 = 1  
AND (col_2, col_3, col_4) >= (1, 1, 2) 
AND (col_3, col_4) < (2, 3);

InvalidRequest: Error from server: code=2200 [Invalid query] 
message="Column "col_3" cannot be restricted by two inequalities not starting w


###IMP - AVOID Range Slice 
A query will be processed as a range slice if it it meets any of the following criteria:
    no partition key in the WHERE clause
    the IN operator is used on a column that is not a partition key
    the TOKEN function is used.
    Slices of clustering segments (lesser evil)

#Example 
CREATE TABLE IF NOT EXISTS demo_users (
    name text,
    age int,
    data text,
    PRIMARY KEY ((name), age)
);

#the following queries would all be processed as range slices:
SELECT * FROM demo_users
(no partition key in WHERE clause)

SELECT * FROM demo_users WHERE age > 50 ALLOW FILTERING
(no partition key in WHERE clause)

SELECT * FROM demo_users WHERE (age) IN ((29), (30), (31)) ALLOW FILTERING
(IN statement used on non-partition key)

SELECT * FROM demo_users WHERE token(name) > 15535
(TOKEN function used)
    
##How can I avoid problems with range slices?
The ideal approach is to stop using range slices. This usually involves:
    splitting up one range slice query into multiple queries that hit one partition each, 
    or
    creating a new table with different partition keys so that the necessary data can be easily read 
    via partition keys.


###Creating a counter table
A counter is a special column used to store an integer that is changed in increments.

Counters are useful for many data models. 
Some examples:
    To keep track of the number of web page views received on a company website
    To keep track of the number of games played online or the number of players who have joined an online game

To implement a counter column, create a table that only includes:
    The primary key (can be one or more columns)
        Use all non-counter columns as part of the PRIMARY KEY definition.
    The counter column

Many counter-related settings can be set in the cassandra.yaml file.
https://cassandra.apache.org/doc/latest/cassandra/configuration/cass_yaml_file.html
eg counter_write_request_timeout_in_ms, counter_cache_size_in_mb, 
counter_cache_save_period, counter_cache_keys_to_save

A counter column cannot be indexed or deleted.

To load data into a counter column, or to increase or decrease the value of the counter, 
use the UPDATE command. 

Cassandra rejects USING TIMESTAMP or USING TTL when updating a counter column.

cqlsh> USE cycling;
    CREATE TABLE popular_count (
      id UUID PRIMARY KEY,
      popularity counter
      );

Loading data into a counter column is different than other tables. 
The data is updated rather than inserted.

cqlsh> UPDATE cycling.popular_count
 SET popularity = popularity + 1
 WHERE id = 6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47;

Take a look at the counter value and note that popularity has a value of 1.

cqlsh> SELECT * FROM cycling.popular_count;

Additional increments or decrements will change the value of the counter column. 


###Creating columns with a single value (static column)
In a table that uses clustering columns, non-clustering(and non partitioning) columns can be declared 
static  in the table definition. 

Static columns are only static/constant for each partition 
(ie for partition key, not dependent on clustering cols)

> CREATE TABLE t (
  k text,
  s text STATIC,
  i int,
  PRIMARY KEY (k, i)
);
INSERT INTO t (k, s, i) VALUES ('k', 'I''m shared', 0);
INSERT INTO t (k, s, i) VALUES ('k', 'I''m still shared', 1);
SELECT * FROM t;

Output:

 k |                  s | i   
----------------------------
k  | "I'm still shared" | 0 
k  | "I'm still shared" | 1       

#Restriction:
A table that does not define any clustering columns cannot have a static column. 
The table that does not have clustering columns has a one-row partition 
in which every column is inherently static.

A column designated to be the partition key cannot be static.

You can batch conditional updates to a static column.

Use the DISTINCT keyword to select static columns. 
In this case, the database retrieves only the beginning (static column) of the partition.

> SELECT DISTINCT s FROM t;

Remove the table 
cqlsh> DROP table t;

###Creating the set type - preferred compared to list 
A set consists of a group of elements with unique values. 

The values of a set are stored unordered, but will return the elements in sorted order when queried. 

Use the set data type to store data that has a many-to-one/one-to-many relationship with another column. 

For example, in the example below, a set called teams stores all the teams that a cyclist 
has been a member of during their career.

cqlsh> CREATE TABLE cycling.cyclist_career_teams ( id UUID PRIMARY KEY, lastname text, teams set<text> );

##Inserting and updating data into a set
If a table specifies a set to hold data, then either INSERT or UPDATE is used to enter data.

Note single partition update is always atomic, so concurrent updates would be serialized 

Insert data into the set, enclosing values in curly brackets.
Set values must be unique, because no order is defined in a set internally.

cqlsh>INSERT INTO cycling.cyclist_career_teams (id,lastname,teams) 
  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS', 
  { 'Rabobank-Liv Woman Cycling Team','Rabobank-Liv Giant','Rabobank Women Team','Nederland bloeit' } );

Add an element(or comma separated multiple elements) to a set using the UPDATE command 
and the addition (+) operator.

cqlsh> UPDATE cycling.cyclist_career_teams 
  SET teams = teams + {'Team DSB - Ballast Nedam'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Remove an element(or comma separated multiple elements) from a set using the subtraction (-) operator.

cqlsh> UPDATE cycling.cyclist_career_teams
  SET teams = teams - {'Team DSB - Ballast Nedam'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

A set, list, or map needs to have at least one element 
because an empty set, list, or map is stored as a null .

cqlsh> UPDATE cycling.cyclist_career_teams SET teams = {} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;
#OR 
cqlsh> DELETE teams FROM cycling.cyclist_career_teams WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;


A query for the teams returns null.

cqlsh> SELECT id, teams FROM cycling.cyclist_career_teams  WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Delete entire row 
cqlsh> DELETE FROM cycling.cyclist_career_teams WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Now update would insert this (other values would be null)
> UPDATE cycling.cyclist_career_teams 
  SET teams = teams + {'Team DSB - Ballast Nedam'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

When using the frozen keyword, you cannot update parts of nested set . 
(but for nested collection, frozen is must)
The entire value must be overwritten. Cassandra treats the value of a frozen, type like a blob.

> CREATE TABLE cycling.cyclist_career_teams_f ( id UUID PRIMARY KEY, lastname text, teams set<frozen<set<text> > > );

> INSERT INTO cycling.cyclist_career_teams_f (id,lastname,teams) 
  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS', 
  { {'A','B'}, {'A', 'C'} } );

> select * from cycling.cyclist_career_teams_f;

Add an element to a set using the UPDATE command and the addition (+) operator.

> UPDATE cycling.cyclist_career_teams_f
  SET teams = teams + {{'D','E'}} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Remove an element from a set using the subtraction (-) operator.

> UPDATE cycling.cyclist_career_teams_f
  SET teams = teams - {{'D','E'}} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;




###Creating the list type
Unlike a set, the values stored in a list do not need to be unique and can be duplicated. 

In addition, a list stores the elements in a particular order and may be inserted or retrieved 
according to an index value.

Use the list data type to store data that has a possible many-to-one relationship with another column.
 
For example, in the example below, a list called events stores all the race events on an upcoming calendar. 

cqlsh> CREATE TABLE cycling.upcoming_calendar ( year int, month int, events list<text>, PRIMARY KEY ( year, month) );

Insert data into the list, enclosing values in square brackets.This replaces full list 

cqlsh> INSERT INTO cycling.upcoming_calendar (year, month, events) VALUES (2015, 06, ['Criterium du Dauphine','Tour de Suisse']);

Use the UPDATE command to insert values into the list. 
Prepend an element to the list by enclosing it in square brackets and using the addition (+) operator.

> UPDATE cycling.upcoming_calendar SET events = ['The Parx Casino Philly Cycling Classic'] + events WHERE year = 2015 AND month = 06;

Append an element to the list by switching the order of the new element data and the list name in the UPDATE command.

cqlsh> UPDATE cycling.upcoming_calendar SET events = events + ['Tour de France Stage 10'] WHERE year = 2015 AND month = 06;

These update operations are implemented internally without any read-before-write. 
Appending and prepending a new element to the list writes only the new element.

replace  an element at a particular position using the list index position in square brackets.
(zero based, if more than length, throws error - index out of bounds)

> UPDATE cycling.upcoming_calendar SET events[0] = 'Vuelta Ciclista a Venezuela' WHERE year = 2015 AND month = 06;

To replace an element at a particular position, Cassandra reads the entire list,
and then rewrites the part of the list that needs to be shifted to the new index positions. 
Consequently, adding an element at a particular position results in greater latency 
than appending or prefixing an element to a list.

Remove an element from a list, use the DELETE command and the list index position in square brackets. 
For example, remove the event just placed in the list in the last step.

(non existence index is errored)
cqlsh> DELETE events[1] FROM cycling.upcoming_calendar WHERE year = 2015 AND month = 06;

The method of removing elements using an indexed position from a list requires an internal read. 
In addition, the client-side application could only discover the indexed position by reading the whole list 
and finding the values to remove, adding INTERNAL latency to the operation. 

If another thread or client prepends elements to the list before the operation is done, 
incorrect data will be removed.

Remove all elements having a particular value using the UPDATE command, the subtraction operator (-), 
and the list value in square brackets.

> UPDATE cycling.upcoming_calendar SET events = events - ['Tour de France Stage 10'] WHERE year = 2015 AND month = 06;

Using the UPDATE command as shown in this example is recommended over the last example 
because it is safer and faster.

Note individual elements eg events[0] can not be selected 

cqlsh> select * from cycling.upcoming_calendar;

#Using frozen 
> CREATE TABLE cycling.upcoming_calendar_f ( year int, month int, events list<frozen <list<text> > >, PRIMARY KEY ( year, month) );

> INSERT INTO cycling.upcoming_calendar_f (year, month, events) VALUES (2015, 06, [['Criterium du Dauphine','Tour de Suisse']]);

> UPDATE cycling.upcoming_calendar_f SET events = [['The Parx Casino Philly Cycling Classic']] + events WHERE year = 2015 AND month = 06;

> UPDATE cycling.upcoming_calendar_f SET events = events + [['Tour de France Stage 10']] WHERE year = 2015 AND month = 06;

There is no nested syntax like events[0][0] , full list should be updated 
(in driver, probably, read events at first, then modify in driver language and replace the entire list)
> UPDATE cycling.upcoming_calendar_f SET events[0] = ['Vuelta Ciclista a Venezuela'] WHERE year = 2015 AND month = 06;

> select * from cycling.upcoming_calendar_f;



###Creating the map type
A map relates one item to another with a key-value pair. 
For each key, only one value may exist, and duplicates cannot be stored. 

Both the key and the value are designated with a data type.

Using the map type, you can store timestamp-related information in user profiles. 

Each element of the map is internally stored as one Cassandra column that you can modify, replace, delete, 
and query. Each element can have an individual time-to-live and expire when the TTL ends.

Define teams in a table cyclist_teams. 
Each team listed in the map will have an integer data type for the year a cyclist belonged to the team
and a textdata type for the team name. 

cqlsh> CREATE TABLE cycling.cyclist_teams ( id UUID PRIMARY KEY, lastname text, firstname text, teams map<int,text> );

If a table specifies a map to hold data, then either INSERT or UPDATE is used to enter data.

Set or replace map data, using the INSERT or UPDATE command, and enclosing the integer 
and text values in a map collection with curly brackets, separated by a colon.

> INSERT INTO cycling.cyclist_teams (id, lastname, firstname, teams) 
VALUES (
  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,
  'VOS', 
  'Marianne', 
  {2015 : 'Rabobank-Liv Woman Cycling Team', 2014 : 'Rabobank-Liv Woman Cycling Team', 2013 : 'Rabobank-Liv Giant', 
    2012 : 'Rabobank Women Team', 2011 : 'Nederland bloeit' }); 

Note: Using INSERT in this manner will replace the entire map.

Use the UPDATE command to insert values into the map. 
Append an element to the map by enclosing the key-value pair in curly brackets and using the addition (+) operator.

> UPDATE cycling.cyclist_teams SET teams = teams + {2009 : 'DSB Bank - Nederland bloeit'} WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Set a specific element using the UPDATE command, enclosing the specific key of the element, 
an integer, in square brackets, and using the equals operator to map the value assigned to the key.
(if existing , update, else create new K:V pair)

cqlsh> UPDATE cycling.cyclist_teams SET teams[2006] = 'Team DSB - Ballast Nedam' WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Delete an element from the map using the DELETE command and enclosing the specific key of the element 
in square brackets:
(non existence key is silently ignored)
cqlsh> DELETE teams[2009] FROM cycling.cyclist_teams WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Alternatively, remove all elements having a particular value using the UPDATE command, 
the subtraction operator (-), and the map key values in curly brackets.

cqlsh> UPDATE cycling.cyclist_teams SET teams = teams - {2013,2014} WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

Use frozen, all the above holds good, but note that there is no nested [][] indexing syntax 
> CREATE TABLE cycling.cyclist_teams_f ( id UUID PRIMARY KEY, lastname text, firstname text, teams list< frozen <map<int,text> > >);
> CREATE TABLE cycling.cyclist_teams_ff ( id UUID PRIMARY KEY, lastname text, firstname text, map<int, frozen< list<text> > >);



###Querying tables Retrieval using collections

Retrieve teams for a particular cyclist id from the set.

cqlsh> INSERT INTO cycling.cyclist_career_teams (
  id,lastname,teams
) VALUES (
  5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 
  'VOS', 
  {
    'Rabobank-Liv Woman Cycling Team',
    'Rabobank-Liv Giant',
    'Rabobank Women Team',
    'Nederland bloeit'
  }
);

> INSERT INTO cycling.cyclist_career_teams (id,lastname,teams) VALUES (e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN', { 'Rabobank-Liv Woman Cycling Team','Sengers Ladies Cycling Team','Team Flexpoint' } );
> INSERT INTO cycling.cyclist_career_teams (id,lastname,teams) VALUES (cb07baad-eac8-4f65-b28a-bddc06a0de23, 'ARMITSTEAD', { 'Boels-Dolmans Cycling Team','AA Drink - Leontien.nl','Team Garmin - Cervelo' } );
> INSERT INTO cycling.cyclist_career_teams (id,lastname,teams) VALUES (1c9ebc13-1eab-4ad5-be87-dce433216d40, 'BRAND', { 'Rabobank-Liv Woman Cycling Team','Rabobank-Liv Giant','AA Drink - Leontien.nl','Leontien.nl' } );


cqlsh> SELECT lastname, teams FROM cycling.cyclist_career_teams WHERE id = 5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

To query a table containing a collection, Cassandra retrieves the collection in its entirety. 
Keep collections small enough to be manageable because the collection store in memory. 

Cassandra returns results in an order based on the type of the elements in the collection. 
For example, a set of text elements is returned in alphabetical order. 

If you want elements of the collection returned in insertion order, use a list.

Retrieve events stored in a list from the upcoming calendar for a particular year and month.

cqlsh> SELECT * FROM cycling.upcoming_calendar WHERE year=2015 AND month=06;

Note: The order is not alphabetical, but rather in the order of insertion.

Retrieve teams for a particular cyclist id from the map.

cqlsh> SELECT lastname, firstname, teams FROM cycling.cyclist_teams WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

The order of the map output depends on the key type of the map. 
In this case, the key is an integer type.


###Updating 
Unlike the INSERT command, the UPDATE command supports counters. 
Otherwise, the UPDATE and INSERT operations are identical.

UPDATE [keyspace_name.] table_name
    [USING TTL time_value | USING TIMESTAMP timestamp_value]
    SET assignment [, assignment] . . . 
        WHERE row_specification
        [IF EXISTS | IF NOT EXISTS | IF condition [AND condition] . . .] ;
        
Where 
assignment
    column_name = column_value [, column_name = column_value] . . . 
    | counter_column_name = counter_column_name + | - counter_offset
    | list_name = ['list_item' [, 'list_item'] . . . ]
    | list_name = list_name + | - ['list_item' [, 'list_item'] . . . ] 
    | list_name = ['list_item' [, 'list_item'] . . . ] + list_name  
    | map_name = map_name + | - { map_key : map_value [, map_key : map_value . . . }
    | map_name[ index ] = map_value
    | set_name = set_name + | - { ['set_item'] } 
row_specification
    The WHERE clause must identify the row or rows to be updated by primary key:
        To specify one row, use primary_key_name = primary_key_value. 
            If the primary key is a combination of elements, follow this with 
            AND primary_key_name = primary_key_value .... 
            The WHERE clause must specify a value for every component of the primary key.
        To specify more than one row, use primary_key_name IN ( primary_key_value, primary_key_value … ). 
        This only works for the last component of the primary key.
    Note: To update a static column, you only need to specify the partition key.
IF EXISTS / IF NOT EXISTS | IF condition
    An IF clause can limit the command's action on rows that match the WHERE clause:
        Use IF EXISTS to make the UPDATE fail when rows match the WHERE conditions.
        Use IF NOT EXISTS to make the UPDATE fail when no rows exist match the WHERE conditions.
        Use IF to specify one or more conditions that must test true
            for the values in the specified row or rows.


