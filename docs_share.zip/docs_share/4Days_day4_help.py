###Another HandsON 
Create test keyspace with SimpleStrategy and 1 replication 


Drop Table test.cyclist_name if exists 

Create a table, test.cyclist_name with below and id is Primary key 
  id UUID ,
  lastname text,
  firstname text
  
Insert UUid() in id and empty other columns 

Truncate the table 


Insert data with TTL 86400 and timestamp 123456789
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK', 'Steven'

View output 

Insert using Lightweight Transaction (LWT)
c4b65263-fe58-4846-83e8-f0e1c13d518f, 'RATTO', 'Rissella'

View output 
select * from test.cyclist_name;

truncate the table 

Insert 6 rows of cyclists
5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'


View output 

Delete data in firstname, lastname from a row,  Alex Frame, (it would make them  null in name columns)

View output

Delete an entire row,Alex Frame altogether using LWT 


View output

Delete a row when id = fb372533-eb95-4bb4-8685-6ef61e994caa and  based on  condition firstname = 'Michael' and lastname = 'Smith'
will it delete ?

View output

Delete a row , Steven Kruikswijk

View output

Delete rows using an IN clause on a primary key, delete Marianne and Paolo

View output

Reinsert data 
5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'

add comment column 

Update comment 'Rides hard, gets along with others, a real winner' for Michael MATTHEWS using LWT 


multicolumn update , update firstname and lastname to Marianne and VOS when id = 88b8fd18-b1ed-4e96-bf79-4280797cba80
What would it do?

View output

multicolumn update , update firstname to Null for  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,fb372533-eb95-4bb4-8685-6ef61e994caa
What would it do?

View output

update for id e7cd5752-bc0d-4157-a80f-7523add8dbcd, Anna VAN DER BREGGEN as firstname lastname 


View output

if - LWT , if comment is null for fb372533-eb95-4bb4-8685-6ef61e994caa, 
update to 'Rides hard, gets along with others, a real winner'

View output

Drop keyspace test 

###Handling One to One Relationship with Simple Example
One to one relationship means two tables have one to one correspondence. 

For example, the student can register only one course, 
and I want to search on a student 
that in which course a particular student is registered in.

In RDBMS, one table would be student , other table course 
and student table has FK of course id 

In Cassandra,one table encompass all the details of the student and course

> Create table if not exists Student_Course1 (
        Student_rollno int primary key,
        Student_name text,
        Course_name text,
        Course_cost float,
    );


> Select * from Student_Course1 where Student_rollno=23;

###  Handling one to many relationships with Simple Example
One to many relationships means having one to many correspondence 
between two tables.

#Query: Given student roll number, get all course names/details 
Since course details are fairly constant, use set or map 

> Create table if not exists Student_Course21 (
        Student_rollno int,
        Student_name text,   
        courses map<text, double>,  //name: cost 
        PRIMARY KEY(Student_rollno)
    );
> INSERT INTO Student_Course1 
    (Student_rollno, Student_name, Course_name, Course_cost) 
    VALUES  (23, 'somename','course a',100.0);

> Select * from Student_Course21 where Student_rollno=23;;

For complex course details 
(eg {course_name : { title: value, duration: value ,....}}

> Create table Student_Course21_test (
        Student_rollno int,
        Student_name text,   
        courses map<text, frozen<map<text,text>>>,
        PRIMARY KEY(Student_rollno)
    );
    
Since there are lot of student_rollnumber, 
lot of small partitions are created 
If you want to create batchwise student details(little bigger partitions) 
Create a derived batch id 

> Create table Student_Course22_test  (
        Student_rollno int,
        Student_name text,   
        batch_id int,
        courses map<text, frozen<map<text,text>>>,
        PRIMARY KEY(batch_id, Student_rollno) //compound key - Student_rollno as clustering 
    );

#Query: Given course name, get all students details
For example, a course can be studied by many students. 
I want to search all the students that are studying a particular course.

In RDBMS, one table would be student , other table course 
and student table has FK of course id , so many students can have same course_id 

In Cassandra , compound key is the solution 
(Note Set of rollno can be created, but it is high cardinality and highly 
dynamic data )

> Create table if not exists  Student_Course23 (
        Course_name text,
        Student_rollno int,
        Student_name text,    
        Course_cost float,
        PRIMARY KEY(Course_name,Student_rollno)
    );

> Select * from Student_Course where Course_name='Course Name';

Note if course data is imbalanced, then few partitions would have large data 
One way to handle is to use composite key 
(either another field as key or derived data or even phantom data 
(eg random number modulo N for N partitions)

> Create table Student_Course24_test
    (
        Course_name text,
        Student_rollno int,
        Student_name text,  
        course_name_first_alphabet text,
        PRIMARY KEY((Course_name,course_name_first_alphabet), Student_rollno)
    );
    
    
##INSERT 
> BEGIN BATCH
INSERT INTO Student_Course21 (Student_rollno, Student_name, courses) 
    VALUES (23, 'somename', { 'course a' : 100.0 } );
INSERT INTO Student_Course23 
    (Course_name, Student_rollno, Student_name, Course_cost) 
    VALUES  ('course a', 23, 'somename',100.0);
APPLY BATCH;

> Select Course_name from Student_Course1 where Student_rollno=23;
> Select courses from Student_Course21 where Student_rollno=23;
> Select Student_rollno from Student_Course23 where Course_name='course a';

###HANDSON - Many to Many - Data  modeling 
Emps and Deps – base tables
    one depart has many employees  and one employee is part of many departs 

Query to support:
1) Join - Given emp_id, get all depart_id. Given depart_id, get all emp_ids
2) Select -  select * from Emps where Birthdate = '25/04/1975'
3) Group By - select count(*) from Emps group by City
4) Order By - select * from Emps where Birthdate = '25/04/1975‘ order by emp_id


###SOLUTION - Many to Many - Data  modeling  
departments and employees with Many-to-many relationships 
ie one department has many employees  and one employee has many departs 

So we have two tables: Emps and Deps. 

> CREATE TABLE Emps (
emp_id uuid,
emp_name text,
birtdate text,
city text,
PRIMARY KEY(emp_id) );

> CREATE TABLE Deps (
dep_id uuid,
dep_name text,
PRIMARY KEY(dep_id) );

#Query - Given emp_id, get all depart_id. Given depart_id, get all emp_ids
> CREATE TABLE Emps_Deps_Join_table_by_emp_id (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,
dep_name text,
PRIMARY KEY(emp_id, dep_id) );  //Partition = emp_id, sorting = dep_id 

#One dep to many emp 
> CREATE TABLE Emps_Deps_Join_table_by_dep_id (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,
dep_name text,
PRIMARY KEY(dep_id, emp_id) ); 

##Insert 
BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
INSERT INTO Emps_Deps_Join_table_by_dep_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
INSERT INTO Emps_Deps_Join_table_by_dep_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
INSERT INTO Emps_Deps_Join_table_by_dep_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
INSERT INTO Emps_Deps_Join_table_by_dep_id 
    (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
APPLY BATCH;

Then for one dept , get all emps 
> select * from Emps_Deps_Join_table_by_dep_id 
    where dep_id=6d5f1665-89c0-45fc-8cfd-60a373b01621;

#Example Query and tables 
1) select * from Emps where birtdate = '2011-09-03'

To support this query we need to add one more column family named Birthdate_Emps 
in which key is a date and column names are IDs of those employees 
that were born on the date. 

> CREATE TABLE Birthdate_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,    //optional 
dep_name text,  //optional
PRIMARY KEY(birtdate) );

##OPTION-2 
OR Create a Materialized view 
(enable /etc/cassandra/cassandra.yaml in each node, enable_materialized_views: true)
$  sed -i 's/enable_materialized_views: false/enable_materialized_views: true/g' \
    /etc/cassandra/cassandra.yaml

a materialized view is a table built from data in another table 
with a new primary key and new properties(old PKs must be present) 
(has few limitations , check docs)

> CREATE MATERIALIZED VIEW Birthdate_Emps
AS SELECT emp_id,name,birtdate,city,dep_id,dep_name  
    FROM Emps_Deps_Join_table_by_dep_id 
    WHERE birtdate IS NOT NULL AND dep_id IS NOT NULL AND emp_id IS NOT NULL
    PRIMARY KEY (birtdate, dep_id, emp_id);

##OPTION-3 OR Create secondary index 
If data already exists for the column, it will be indexed asynchronously
A general rule of thumb is to index a column with low cardinality of few values

> CREATE INDEX rbirthdate ON Emps_Deps_Join_table_by_dep_id (birtdate);

Then 
> select * from Emps_Deps_Join_table_by_dep_id where birtdate = '2011-09-03'

Note 
Materialized views are suited for high cardinality data. 
The data in a materialized view is arranged serially 
based on the view's primary key. 
Materialized views cause hotspots when low cardinality data is inserted.

Secondary indexes are suited for low cardinality data. 
Queries of high cardinality columns on secondary indexes require Cassandra 
to access all nodes in a cluster, causing high read latency.


#Another Query vs Support 
3) Group By select count(*) from Emps group by City

From implementation viewpoint Group By is very similar 
to select/indexing described above. 
You just need to add a table City_Emps with cities as keys 
and employee IDs as column names. 

In this case you will count the number of employees on retrieval. 

> CREATE TABLE City_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
PRIMARY KEY(city, emp_id) );

#OR create MV 
> CREATE MATERIALIZED VIEW City_Emps
AS SELECT emp_id,name,birtdate,city,dep_id,dep_name  
    FROM Emps_Deps_Join_table_by_dep_id 
    WHERE city IS NOT NULL AND dep_id IS NOT NULL AND emp_id IS NOT NULL
    PRIMARY KEY (city,  emp_id, dep_id);

#or create Secondary Index (low cardinality)
> CREATE INDEX rcity ON Emps_Deps_Join_table_by_dep_id (city);

Then 
>select COUNT(*) from Emps_Deps_Join_table_by_dep_id where city = 'CITY-A'


#Another Query and Solution 
4) Order By, select * from Emps where Birthdate = '2011-09-03' order by emp_id

> CREATE TABLE Birthdate_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,    //optional 
dep_name text,  //optional
PRIMARY KEY(birtdate, emp_id)) WITH CLUSTERING ORDER BY (emp_id ASC);

If bottom five is needed, use LIMIT 5 
and WITH CLUSTERING ORDER BY (emp_id DESC), we get Top 5 



###Getting started with Cassandra time series data modeling

##Time Series Pattern 1
We will use the weather station ID as the row/partition key. 

The timestamp of the reading will be the column name 
and the temperature the column value . 

> CREATE TABLE temperature (
   weatherstation_id text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY (weatherstation_id, event_time)
);

Now we can insert a few data points for our weather station.

>  
INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:01:00','72F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:02:00','73F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:03:00','73F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:04:00','74F');

 
A simple query looking for all data on a single weather station.
 
> SELECT event_time,temperature
FROM temperature
WHERE weatherstation_id='1234ABCD';

A range query looking for data between two dates. 
This is also known as a slice since it will read a sequence of data from disk.
(as event_time is clustering columns)

> SELECT temperature
FROM temperature
WHERE weatherstation_id='1234ABCD'
AND event_time > '2021-08-27 07:01:00'
AND event_time < '2021-08-27 07:04:00';

##Partitioning to limit row size – Time Series Pattern 2
In some cases, the amount of data gathered for a single device isn't practical 
to fit onto a single row. 
Cassandra can store up to 2 billion columns per row, 
but if were storing data every millisecond 
you wouldn't even get a month's worth of data. 

The solution is to use a pattern called Composite key 

This will give us a row per day, per weather station, 
and an easy way to find the data. 

> CREATE TABLE temperature_by_day (
   weatherstation_id text,
   date text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY ((weatherstation_id,date),event_time)
);

> 
INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-26','2021-08-27 07:01:00','72F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-26','2021-08-27 07:02:00','73F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-27','2021-08-27 07:01:00','73F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-27','2021-08-27 07:02:00','74F');

 
To get all the weather data for a single day, 
 
> SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD'
AND date='2021-08-27';

#OR with clusetering columns 
 > SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD'
AND date='2021-08-27' AND event_time >= '2021-08-27 07:01:00'
AND event_time < '2021-08-27 07:04:00';

#But to include only one key from partition, 
#use ALLOW FILTERING(performance might be bad as many nodes)
> SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD' ALLOW FILTERING;
 

##Reverse order timeseries with expiring columns – Time Series Pattern 3
Another common pattern with time series data is rolling storage 
using TTL in seconds 

Imagine we are using this data for a dashboard application 
and we only want to show the last 10 temperature readings. 

Older data is no longer useful, so can be purged eventually. 

> CREATE TABLE latest_temperatures (
   weatherstation_id text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY (weatherstation_id,event_time), 
) WITH CLUSTERING ORDER BY (event_time DESC);

Now when we insert data. 
Note the TTL of 20 which means the data will expire in 20 seconds.
 
> INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:03:00','72F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:02:00','73F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:01:00','73F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:04:00','74F') USING TTL 20;

Then check (and wait for 20 Sec and check again)
> SELECT event_time,temperature
FROM latest_temperatures
WHERE weatherstation_id='1234ABCD';

As soon as you insert the data, start selecting all rows over and over. 
Eventually you will see all the data disappear. 

###Example - Wide Partitions in Apache Cassandra
> Use dummy; 
> Create TABLE Unique_test_table (a text,b int, c text, PRIMARY KEY(a,b)) 

Cassandra would find the node based on murmur3 of PartionKey a and then 
create no of rows based different values of clustering key b 

>
INSERT INTO Unique_test_table(a,b,c) VALUES('test',2,'test2')
INSERT INTO Unique_test_table(a,b,c) VALUES('test',1,'test1')
INSERT INTO Unique_test_table(a,b,c) VALUES('test-new',1,'test1')

Note the how row/cells etc are formed 
$ docker exec -it cass_cluster bash 
$ ls -R /var/lib/cassandra/data/dummy
$ /opt/cassandra/tools/bin/sstabledump /var/lib/cassandra/data/dummy/Unique_test_table-bedc4ba012cf11ea93f72f6848f9d70d/md-1-big-Data.db

[
  {
    "partition" : {
      "key" : [ "test" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 37,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2019-11-29T17:43:35.752796Z" },
        "cells" : [
          { "name" : "c", "value" : "test1" }
        ]
      },
      {
        "type" : "row",
        "position" : 37,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2019-11-29T17:43:31.144961Z" },
        "cells" : [
          { "name" : "c", "value" : "test2" }
        ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "test-new" ],
      "position" : 54
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 95,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2019-11-29T17:43:41.438779Z" },
        "cells" : [
          { "name" : "c", "value" : "test1" }
        ]
      }
    ]
  }
]

Cassandra can store theoratically 2B cells ,
Partitions is called Wide when lot of cells are present because 
of lot of values of clustering columns , here b 

One way to remove wide partition is create a composite keys 
(so data would be partitioned into new node )
eg a and some derived value a1 eg month, year etc if possible 

Note partition key can not be changed post table creation , hence 
correct partition keys need to be designed at the onset  

> Create TABLE Unique_test_table_v2 
    (a text, b int, c text, a1 text, PRIMARY KEY((a,a1),b)) 

Wide partitions in Cassandra can put tremendous pressure on the Java heap 
and garbage collector, impact read latencies, and can cause issues ranging 
from load shedding and dropped messages to crashed and downed nodes.

So, keep partitions under 400MB, and preferably under 100MB
By creating composite keys instead of putting them in clustering columns 

##Calculating No of values/cells   
N_v = N_r * (N_c - N_{pk} - N_s) + N_s

where 
N_v 
    The number of values (or cells) in the partition
N_s 
    number of static columns 
N_r 
    number of rows 
N_c 
    number of columns 
N_{pk}
    number of primary key columns 
    
#Example 
CREATE TABLE hotel.available_rooms_by_hotel_date (
  hotel_id text,
  date date,
  room_number smallint,
  is_available boolean,
  PRIMARY KEY ((hotel_id), date, room_number) )
  WITH comment = 'Q4. Find available rooms by hotel date';

The table has four columns total (Nc = 4), 
including three primary key columns (Npk = 3) and no static columns (Ns = 0). 

Plugging these values into the formula, the result is:
N_v = N_r*(4 - 3 - 0) + 0 = 1N_r

Therefore the number of values/cells for this table is equal to the number of rows. 

Estimate  number of rows for example , here base on date and  room_number

Let’s assume the system will be used to store two years of inventory at a time, 
and there are 5,000 hotels in the system, 
with an average of 100 rooms in each hotel.

Since there is a partition for each hotel, 
the estimated number of rows per partition is as follows:
N_r = 100 rooms/hotel x 730 days = 73,000 rows

This relatively small number of rows per partition is not going 
to get you in too much trouble, 

#Calculating Parttion Size on Disk
S_t = SUM( sizeOf(ck_i) ) for all i + 
        SUM( sizeOf(cs_i})) for all i +
           N_r * ( SUM( sizeOf(cr) ) +  SUM( sizeOf(cc}))  ) +
                N_v *  SUM( sizeOf(t_avg) )
Where 
N_v 
    The number of values (or cells) in the partition
N_r 
    number of rows 
ck,cs,cr,cc 
    refers to partition key columns, 
    cs to static columns, 
    cr to regular columns, and 
    cc to clustering columns.
t_avg 
    The term tavg refers to the average number of bytes of metadata 
    stored per cell, such as timestamps.~8 bytes 
sizeOf()
    refers to the size in bytes of the CQL data type of each referenced column.

For  available_rooms_by_hotel_date table 
    single partition key column, the hotel_id, which is of type text. 
        Assuming that hotel identifiers are simple 5-character codes, 
        you have a 5-byte value, 
        so the sum of the partition key column sizes is 5 bytes.
    No static column 
    The two clustering columns are the date, which is 4 bytes, 
        and the room_number, which is a 2-byte short integer, 
        giving a sum of 6 bytes. 
    There is only a single regular column, the boolean is_available, 
        which is 1 byte in size. 
        
   Summing the regular column size (1 byte) plus the clustering column size 
   (6 bytes) gives a total of 7 bytes. 
        To finish up the term, multiply this value by the number of rows 
        (73,000), giving a result of 511,000 bytes (0.51 MB).
    
    The metadata size is 8 bytes 
    So (73,000) and multiply by 8, which gives 0.58 MB.

Partition size = 16 bytes + 0 bytes + 0.51 MB + 0.58 MB = 1.1 MB
Quite OK 

    
