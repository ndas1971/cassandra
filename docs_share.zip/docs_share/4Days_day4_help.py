    Batching data insertion and updates
    Indexing
        secondary index - why and restrictions
    Using materialized views Vs Secondary indexes 
    Altering a table
    Removing a keyspace, schema, or data
    Configuring cqlsh from a file
    Understanding DataModel
        Denormalization
        Rules
            Practical examples 
        Time series data modeling and TTL
            Practical example         
    Cassandra internals
        Rack and network topology
        Snitches
        Introduction to configuration and cluster operations 
        Understanding read, write, update paths 
        Deletes and Tombstones
            Viewing Tombstone             
        Repairing Nodes 
        Consistency

--------------------------------------------------------------

###Another HandsON 
Create test keyspace with SimpleStrategy and 1 replication 


Drop Table test.cyclist_name if exists 

Create a table, test.cyclist_name with below and id is Primary key 
  id UUID ,
  lastname text,
  firstname text
  
Insert UUid() in id and empty other columns 

Truncate the table 


Insert data with TTL 86400 and timestamp 123456789
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK', 'Steven'

View output 

Insert using Lightweight Transaction (LWT)
c4b65263-fe58-4846-83e8-f0e1c13d518f, 'RATTO', 'Rissella'

View output 
select * from test.cyclist_name;

truncate the table 

Insert 6 rows of cyclists
5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'


View output 

Delete data in firstname, lastname from a row,  Alex Frame, (it would make them  null in name columns)

View output

Delete an entire row,Alex Frame altogether using LWT 


View output

Delete a row when id = fb372533-eb95-4bb4-8685-6ef61e994caa and  based on  condition firstname = 'Michael' and lastname = 'Smith'
will it delete ?

View output

Delete a row , Steven Kruikswijk

View output

Delete rows using an IN clause on a primary key, delete Marianne and Paolo

View output

Reinsert data 
5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'

add comment column 

Update comment 'Rides hard, gets along with others, a real winner' for Michael MATTHEWS using LWT 


multicolumn update , update firstname and lastname to Marianne and VOS when id = 88b8fd18-b1ed-4e96-bf79-4280797cba80
What would it do?

View output

multicolumn update , update firstname to Null for  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,fb372533-eb95-4bb4-8685-6ef61e994caa
What would it do?

View output

update for id e7cd5752-bc0d-4157-a80f-7523add8dbcd, Anna VAN DER BREGGEN as firstname lastname 


View output

if - LWT , if comment is null for fb372533-eb95-4bb4-8685-6ef61e994caa, 
update to 'Rides hard, gets along with others, a real winner'

View output

Drop keyspace test 

###Handling One to One Relationship with Simple Example
One to one relationship means two tables have one to one correspondence. 

For example, the student can register only one course, 
and I want to search on a student that in which course a particular student is registered in.

In RDBMS, one table would be student , other table course 
and student table has FK of course id 

So in this case, your table schema should encompass all the details of the student and course

> Create table if not exists Student_Course1 (
        Student_rollno int primary key,
        Student_name text,
        Course_name text,
        Course_cost float,
    );


> Select * from Student_Course1 where Student_rollno=23;

###  Handling one to many relationships with Simple Example
One to many relationships means having one to many correspondence between two tables.

#Query: Given student roll number, get all course names/details 
Since course details are fairly constant, use set or map 

> Create table if not exists Student_Course21 (
        Student_rollno int,
        Student_name text,   
        courses map<text, double>,  //name: cost 
        PRIMARY KEY(Student_rollno)
    );
> INSERT INTO Student_Course1 (Student_rollno, Student_name, Course_name, Course_cost) VALUES  (23, 'somename','course a',100.0);

> Select * from Student_Course21 where Student_rollno=23;;

For complex course details 
(eg {course_name : { title: value, duration: value ,....}}

> Create table Student_Course21_test (
        Student_rollno int,
        Student_name text,   
        courses map<text, frozen<map<text,text>>>,
        PRIMARY KEY(Student_rollno)
    );
    
Since there are lot of student_rollnumber, lot of small partitions are created 
If you want to create batchwise student details(little bigger partitions) Create a derived batch id 

> Create table Student_Course22_test  (
        Student_rollno int,
        Student_name text,   
        batch_id int,
        courses map<text, frozen<map<text,text>>>,
        PRIMARY KEY(batch_id, Student_rollno) //compound key - Student_rollno as clustering 
    );

#Query: Given course name, get all students details
For example, a course can be studied by many students. 
I want to search all the students that are studying a particular course.

In RDBMS, one table would be student , other table course 
and student table has FK of course id , so many students can have same course_id 

Create Compound key with clustering cols eg Course_name is partition key and Student_rollno is sorting col 
(actually creates Wide format - check below - limitation - 2B columns )

Note set of student roll numbers also can be created, but since course and it's students are quite dynamic 
Lets not create set of student roll number 

> Create table if not exists  Student_Course23 (
        Course_name text,
        Student_rollno int,
        Student_name text,    
        Course_cost float,
        PRIMARY KEY(Course_name,Student_rollno)
    );

I can retrieve all the students for a particular course by the following query.

> Select * from Student_Course where Course_name='Course Name';

Note if course data is imbalanced, then few partitions would have large data 
One way to handle is to use composite key (either another field as key or derived data 
or even phantom data (eg random number modulo N for N partitions)

> Create table Student_Course24_test
    (
        Course_name text,
        Student_rollno int,
        Student_name text,  
        course_name_first_alphabet text,
        PRIMARY KEY((Course_name,course_name_first_alphabet), Student_rollno)
    );
    
##INSERT 
> BEGIN BATCH
INSERT INTO Student_Course21 (Student_rollno, Student_name, courses) VALUES (23, 'somename', { 'course a' : 100.0 } );
INSERT INTO Student_Course23 (Course_name, Student_rollno, Student_name, Course_cost) VALUES  ('course a', 23, 'somename',100.0);
APPLY BATCH;

> Select Course_name from Student_Course1 where Student_rollno=23;
> Select courses from Student_Course21 where Student_rollno=23;
> Select Student_rollno from Student_Course23 where Course_name='course a';

###Many to Many - Data  modeling - HANDSON 
Emps and Deps – base tables
    one depart has many employees  and one employee is part of many departs 
Query to support:
1) Join - Given emp_id, get all depart_id. Given depart_id, get all emp_ids
2) Select -  select * from Emps where Birthdate = '25/04/1975'
3) Group By - select count(*) from Emps group by City
4) Order By - select * from Emps where Birthdate = '25/04/1975‘ order by emp_id


###Many to Many - Data  modeling  - SOLUTION  
departments and employees with Many-to-many relationships 
ie one department has many employees  and one employee has many departs 

So we have two tables: Emps and Deps. 

> CREATE TABLE Emps (
emp_id uuid,
emp_name text,
birtdate text,
city text,
PRIMARY KEY(emp_id) );

> CREATE TABLE Deps (
dep_id uuid,
dep_name text,
PRIMARY KEY(dep_id) );

#Query - Given emp_id, get all depart_id. Given depart_id, get all emp_ids
> CREATE TABLE Emps_Deps_Join_table_by_emp_id (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,
dep_name text,
PRIMARY KEY(emp_id, dep_id) );  //Partition = emp_id, sorting = dep_id 

#One dep to many emp 
> CREATE TABLE Emps_Deps_Join_table_by_dep_id (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,
dep_name text,
PRIMARY KEY(dep_id, emp_id) ); 

##Insert 
BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
INSERT INTO Emps_Deps_Join_table_by_dep_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
INSERT INTO Emps_Deps_Join_table_by_dep_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1664-89c0-45fc-8cfd-60a373b01621, 'DEPT_A');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
INSERT INTO Emps_Deps_Join_table_by_dep_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01621, 'ABC', '2021-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
APPLY BATCH;

BEGIN BATCH
INSERT INTO Emps_Deps_Join_table_by_emp_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
INSERT INTO Emps_Deps_Join_table_by_dep_id (emp_id,name,birtdate,city,dep_id,dep_name) 
    VALUES (6d5f1663-89c0-45fc-8cfd-60a373b01622, 'XYZ', '2011-09-03', 'CITY-A', 6d5f1665-89c0-45fc-8cfd-60a373b01621, 'DEPT_B');
APPLY BATCH;

Then for one dept , get all emps 
> select * from Emps_Deps_Join_table_by_dep_id where dep_id=6d5f1665-89c0-45fc-8cfd-60a373b01621;


1) select * from Emps where birtdate = '2011-09-03'

To support this query we need to add one more column family named Birthdate_Emps in which key is a date 
and column names are IDs of those employees that were born on the date. 

> CREATE TABLE Birthdate_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,    //optional 
dep_name text,  //optional
PRIMARY KEY(birtdate) );

##OPTION-2 
OR Create a Materialized view (enable /etc/cassandra/cassandra.yaml in each node, enable_materialized_views: true)
$  sed -i 's/enable_materialized_views: false/enable_materialized_views: true/g' /etc/cassandra/cassandra.yaml

a materialized view is a table built from data in another table with a new primary key and new properties. 
(has few limitations , check docs)
https://blog.softwaremill.com/what-is-wrong-with-apache-cassandra-materialized-views-a7a25431dad

> CREATE MATERIALIZED VIEW Birthdate_Emps
AS SELECT emp_id,name,birtdate,city,dep_id,dep_name  FROM Emps_Deps_Join_table_by_dep_id 
WHERE birtdate IS NOT NULL AND dep_id IS NOT NULL AND emp_id IS NOT NULL
PRIMARY KEY (birtdate, dep_id, emp_id);

Restrictions for materialized views:
    Include all of the source table's primary keys in the materialized view's primary key.
    Only one new column can be added to the materialized view's primary key. Static columns are not allowed.
    Exclude rows with null values in the materialized view primary key column.
    
When data is deleted from Emps_Deps_Join_table_by_dep_id, Cassandra deletes the same data from any related materialized views.
Cassandra can only write data directly to source tables, not to materialized views. 
Cassandra updates a materialized view asynchronously after inserting data into the source table, 
so the update of materialized view is delayed. 
Cassandra performs a read repair to a materialized view only after updating the source table.

##OPTION-3 
OR Create secondary index 
If data already exists for the column, it will be indexed asynchronously
Secondary indexes are tricky to use and can impact performance greatly. 
The index table is stored on each node in a cluster, so a query involving a secondary index can rapidly 
become a performance nightmare if multiple nodes are accessed. 
A general rule of thumb is to index a column with low cardinality of few values

> CREATE INDEX rbirthdate ON Emps_Deps_Join_table_by_dep_id (birtdate);

Then 
> select * from Emps_Deps_Join_table_by_dep_id where birtdate = '2011-09-03'

Note 
Materialized views are suited for high cardinality data. 
The data in a materialized view is arranged serially based on the view's primary key. 
Materialized views cause hotspots when low cardinality data is inserted.

Secondary indexes are suited for low cardinality data. 
Queries of high cardinality columns on secondary indexes require Cassandra 
to access all nodes in a cluster, causing high read latency.



3) Group By select count(*) from Emps group by City

From implementation viewpoint Group By is very similar to select/indexing described above. 
You just need to add a column family City_Emps with cities as keys and employee IDs as column names. 

In this case you will count the number of employees on retrieval. 

> CREATE TABLE City_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
PRIMARY KEY(city, emp_id) );

#OR create MV 
> CREATE MATERIALIZED VIEW City_Emps
AS SELECT emp_id,name,birtdate,city,dep_id,dep_name  FROM Emps_Deps_Join_table_by_dep_id 
WHERE city IS NOT NULL AND dep_id IS NOT NULL AND emp_id IS NOT NULL
PRIMARY KEY (city,  emp_id, dep_id);

#or create Secondary Index (low cardinality)
> CREATE INDEX rcity ON Emps_Deps_Join_table_by_dep_id (city);

Then 
>select COUNT(*) from Emps_Deps_Join_table_by_dep_id where city = 'CITY-A'



4) Order By, select * from Emps where Birthdate = '2011-09-03' order by emp_id

> CREATE TABLE Birthdate_Emps (
emp_id uuid,
name text,
birtdate text,
city text,
dep_id uuid,    //optional 
dep_name text,  //optional
PRIMARY KEY(birtdate, emp_id)) WITH CLUSTERING ORDER BY (emp_id ASC);

If bottom five is needed, use LIMIT 5 and WITH CLUSTERING ORDER BY (emp_id DESC), we get Top 5 



###Getting started with Cassandra time series data modeling

##Time Series Pattern 1
We will use the weather station ID as the row key. 

The timestamp of the reading will be the column name and the temperature the column value . 

Since each column is dynamic, our row will grow as needed to accommodate the data. 
We will also get the built-in sorting of Cassandra to keep everything in order.
(cassandra limit, 2B cells ie (event_time, and temperature)
(Note below is actually one row, with many cells (event_time and temperature) for a key, weatherstation_id)

> CREATE TABLE temperature (
   weatherstation_id text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY (weatherstation_id,event_time)
);

Now we can insert a few data points for our weather station.

>  INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:01:00','72F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:02:00','73F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:03:00','73F');

INSERT INTO temperature(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:04:00','74F');

 
A simple query looking for all data on a single weather station.
 
> SELECT event_time,temperature
FROM temperature
WHERE weatherstation_id='1234ABCD';

A range query looking for data between two dates. 
This is also known as a slice since it will read a sequence of data from disk.
(as event_time is clustering columns)

> SELECT temperature
FROM temperature
WHERE weatherstation_id='1234ABCD'
AND event_time > '2021-08-27 07:01:00'
AND event_time < '2021-08-27 07:04:00';

##Partitioning to limit row size – Time Series Pattern 2
In some cases, the amount of data gathered for a single device isn't practical to fit onto a single row. 
Cassandra can store up to 2 billion columns per row, but if were storing data every millisecond 
you wouldn't even get a month's worth of data. 

The solution is to use a pattern called Composite key 

Using data already available in the event, we can use the date portion of the timestamp 
and add that to the weather station id. 

This will give us a row per day, per weather station, and an easy way to find the data. 

> CREATE TABLE temperature_by_day (
   weatherstation_id text,
   date text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY ((weatherstation_id,date),event_time)
);

Now when we insert data, the key will group all weather data for a single day on a single row.
 
> INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-26','2021-08-27 07:01:00','72F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-26','2021-08-27 07:02:00','73F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-27','2021-08-27 07:01:00','73F');

INSERT INTO temperature_by_day(weatherstation_id,date,event_time,temperature)
VALUES ('1234ABCD','2021-08-27','2021-08-27 07:02:00','74F');

 
To get all the weather data for a single day, we can query using both elements of the key.
 
> SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD'
AND date='2021-08-27';

#OR with clusetering columns 
 > SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD'
AND date='2021-08-27' AND event_time >= '2021-08-27 07:01:00'
AND event_time < '2021-08-27 07:04:00';

#But to include only one key from partition, use ALLOW FILTERING(performance might be bad as many nodes)
> SELECT *
FROM temperature_by_day
WHERE weatherstation_id='1234ABCD' ALLOW FILTERING;
 

##Reverse order timeseries with expiring columns – Time Series Pattern 3
Another common pattern with time series data is rolling storage. 

Imagine we are using this data for a dashboard application and we only want to show 
the last 10 temperature readings. 

Older data is no longer useful, so can be purged eventually. 
With many other databases, you would have to setup a background job to clean out older data. 

With Cassandra, we can take advantage of a feature called expiring columns to have our data quietly 
disappear after a set amount of seconds. 

> CREATE TABLE latest_temperatures (
   weatherstation_id text,
   event_time timestamp,
   temperature text,
   PRIMARY KEY (weatherstation_id,event_time), 
) WITH CLUSTERING ORDER BY (event_time DESC);

Now when we insert data. Note the TTL of 20 which means the data will expire in 20 seconds.
 
> INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:03:00','72F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:02:00','73F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:01:00','73F') USING TTL 20;

INSERT INTO latest_temperatures(weatherstation_id,event_time,temperature)
VALUES ('1234ABCD','2021-08-27 07:04:00','74F') USING TTL 20;

Then check (and wait for 20 Sec and check again)
> SELECT event_time,temperature
FROM latest_temperatures
WHERE weatherstation_id='1234ABCD';

As soon as you insert the data, start selecting all rows over and over. 
Eventually you will see all the data disappear. 



