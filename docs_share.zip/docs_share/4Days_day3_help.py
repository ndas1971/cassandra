    Batching data insertion and updates
    Indexing
        secondary index - why and restrictions
    Using materialized views Vs Secondary indexes 
    Altering a table
    Removing a keyspace, schema, or data
    Configuring cqlsh from a file
    Understanding DataModel
        Denormalization
        Rules
            Practical examples 
        Time series data modeling and TTL
            Practical example         
    Cassandra internals
        Rack and network topology
        Snitches
        Introduction to configuration and cluster operations 
        Understanding read, write, update paths 
        Deletes and Tombstones
            Viewing Tombstone             
        Repairing Nodes 
        Consistency
-------------------------------------------------------

###Batching inserts, updates and deletes
Combines multiple data modification language (DML) statements (such as INSERT, UPDATE, and DELETE) 
to achieve atomicity and isolation when targeting a single partition, 
or only atomicity when targeting multiple partitions.

Atomicity ensures that either all or nothing is written. 
Isolation ensures that partial insertion or updates are not accessed until all operations are complete.

Single partition batch operations are atomic automatically, LWT ensures isolation 

Multiple partition batch ensures atomicity by using batchlog 

Use batching if atomicity is a primary concern for a group of operations. 

Single partition batch operations are processed server-side as a single mutation for improved performance, 
provided the number of operations do not exceed the maximum size of a single operation 
or cause the query to time out. 

Multiple partition batch operations often suffer from performance issues, 
and should only be used if atomicity must be ensured.

###Bad usage of BATCH - write to several different partitions, given the partition key id.
DONT DO THIS 

BEGIN BATCH

  INSERT INTO cycling.cyclist_name (
    id, lastname, firstname
  ) VALUES (
    6d5f1663-89c0-45fc-8cfd-60a373b01622,'HOSKINS', 'Melissa'
  );

  INSERT INTO cycling.cyclist_name (
    id, lastname, firstname
  ) VALUES (
    38ab64b6-26cc-4de9-ab28-c257cf011659,'FERNANDES', 'Marcia'
  );

  INSERT INTO cycling.cyclist_name (
    id, lastname, firstname
  ) VALUES (
    9011d3be-d35c-4a8d-83f7-a3c543789ee7,'NIEWIADOMA', 'Katarzyna'
  );

  INSERT INTO cycling.cyclist_name (
    id, lastname, firstname
  ) VALUES (
    95addc4c-459e-4ed7-b4b5-472f19a67995,'ADRIAN', 'Vera'
  );

APPLY BATCH;


###Single partition batch - Write only single partition - (GOOD USE of BATCH)
The best use of a batch request is for a single partition(ie same Partition key) 
with multiple tables in the same keyspace. 

This batching example includes conditional updates combined with using static columns. 
 

Note:
Conditional batches cannot provide custom timestamps. 
UPDATE and DELETE statements within a conditional batch cannot use IN conditions to filter rows.
Conditional updates uses Lightweight transaction 
However, a batch containing conditional updates can only operate within a single partition, 
    because the underlying Paxos(concensus protocol) implementation only works at partition-level granularity. 
    If one statement in a batch is a conditional update, the conditional logic must return true, 
    or the entire batch fails. If the batch contains two or more conditional updates, 
    all the conditions must return true, or the entire batch fails. 

Recall that single partition batches are not logged.So performance is good 

In a table that uses clustering columns, non-clustering columns can be declared static(one value per partition)

cqlsh> CREATE TABLE cycling.cyclist_expenses ( 
  cyclist_name text, 
  balance float STATIC, 
  expense_id int, 
  amount float, 
  description text, 
  paid boolean, 
  PRIMARY KEY (cyclist_name, expense_id) 
);

Note that balance is STATIC. 


cqlsh> BEGIN BATCH
  INSERT INTO cycling.cyclist_expenses (cyclist_name, balance) VALUES ('Vera ADRIAN', 0) IF NOT EXISTS;
  INSERT INTO cycling.cyclist_expenses (cyclist_name, expense_id, amount, description, paid) VALUES ('Vera ADRIAN', 1, 7.95, 'Breakfast', false);
  APPLY BATCH;

DON'T INCLUDE BELOW UPDATE in batch as The operations may not perform in the order listed in the BATCH statement. 
As all the statements processed in a BATCH statement timestamp the records with the same value.  
SO UPDATE might fail if it is executed before first INSERT 

Use below seperately 
Now the balance will reflect that breakfast was unpaid.
> UPDATE cycling.cyclist_expenses SET balance = -7.95 WHERE cyclist_name = 'Vera ADRIAN' IF balance = 0;


The table cyclist_expenses stores records about each purchase by a cyclist 
and includes the running balance of all the cyclist's purchases. 
BELOW is OK as order does not matter 

cqlsh> BEGIN BATCH
INSERT INTO cycling.cyclist_expenses (cyclist_name, expense_id, amount, description, paid) VALUES ('Vera ADRIAN', 2, 13.44, 'Lunch', true);
INSERT INTO cycling.cyclist_expenses (cyclist_name, expense_id, amount, description, paid) VALUES ('Vera ADRIAN', 3, 25.00, 'Dinner', false);
UPDATE cycling.cyclist_expenses SET balance = -32.95 WHERE cyclist_name = 'Vera ADRIAN' IF balance = -7.95;
APPLY BATCH;


Finally, the cyclist pays off all outstanding bills and the balance of the account goes to zero.
Because the column is static, you can provide only the partition key when updating the data. 
To update a non-static column, you would also have to provide a clustering key. 

cqlsh> BEGIN BATCH
UPDATE cycling.cyclist_expenses SET balance = 0 WHERE cyclist_name = 'Vera ADRIAN' IF balance = -32.95;
UPDATE cycling.cyclist_expenses SET paid = true WHERE cyclist_name = 'Vera ADRIAN' AND expense_id = 1 IF paid = false;
UPDATE cycling.cyclist_expenses SET paid = true WHERE cyclist_name = 'Vera ADRIAN' AND expense_id = 3 IF paid = false;
APPLY BATCH;

Using batched conditional updates, you can maintain a running balance. 
If the balance were stored in a separate table, maintaining a running balance would not be 
possible because a batch having conditional updates cannot span multiple partitions.

cqlsh> select * from cycling.cyclist_expenses;

 cyclist_name | expense_id | balance | amount | description | paid
--------------+------------+---------+--------+-------------+------
  Vera ADRIAN |          1 |       0 |   7.95 |   Breakfast | True
  Vera ADRIAN |          2 |       0 |  13.44 |       Lunch | True
  Vera ADRIAN |          3 |       0 |     25 |      Dinner | True
  
###Multiple partition logged batch
A classic example for using BATCH for a multiple partition insert involves writing the same data 
to two related tables

cqlsh> CREATE TABLE cycling.cyclist_names (
  cyclist_name text PRIMARY KEY,
  race_id int
);

CREATE TABLE cycling.cyclist_by_id (
  race_id int PRIMARY KEY,
  cyclist_name text
);

cqlsh> BEGIN BATCH
INSERT INTO cycling.cyclist_names (cyclist_name, race_id) VALUES ('Vera ADRIAN', 100);
INSERT INTO cycling.cyclist_by_id (race_id, cyclist_name) VALUES (100, 'Vera ADRIAN');
APPLY BATCH;

Here, it is important that the same data is written to both tables to keep them in synchronization. 
Another common use for this batch operation is updating usernames and passwords.

###Misuse of BATCH statement
Misused, BATCH statements can cause many problems in a distributed database like Cassandra. 
Batch operations that involve multiple nodes are a definite anti-pattern. 

Keep in mind which partitions data will be written to when grouping INSERT and UPDATE statements 
in a BATCH statement. Writing to several partitions might require interaction with several nodes 
in the cluster, causing a great deal of latency for the write operation.

This example shows an anti-pattern since the BATCH statement will write to several different partitions, 
given the partition key id.

cqlsh> BEGIN BATCH //DONT DO THIS 
INSERT INTO cycling.cyclist_name (id, lastname, firstname) VALUES  (6d5f1663-89c0-45fc-8cfd-60a373b01622,'HOSKINS', 'Melissa');
INSERT INTO cycling.cyclist_name (id, lastname, firstname) VALUES  (38ab64b6-26cc-4de9-ab28-c257cf011659,'FERNANDES', 'Marcia');
INSERT INTO cycling.cyclist_name (id, lastname, firstname) VALUES  (9011d3be-d35c-4a8d-83f7-a3c543789ee7,'NIEWIADOMA', 'Katarzyna');
INSERT INTO cycling.cyclist_name (id, lastname, firstname) VALUES  (95addc4c-459e-4ed7-b4b5-472f19a67995,'ADRIAN', 'Vera');
APPLY BATCH;

In this example, four partitions are accessed, but consider the effect of including 100 partitions 
in a batch - the performance would degrade considerably.

###Using Time stamp in Batch 
https://docs.datastax.com/en/cql-oss/3.x/cql/cql_reference/cqlBatch.html

Specify the epoch time in micoseconds after USING TIMESTAMP:

BEGIN [UNLOGGED | LOGGED] BATCH 
[USING TIMESTAMP [epoch_microseconds]]
   dml_statement [USING TIMESTAMP [epoch_microseconds]];
   [dml_statement; ...]
APPLY BATCH;

When the time is not specified, Cassandra inserts the current time.

Same timestamp for all DMLs - Insert on first line of batch.

BEGIN BATCH USING TIMESTAMP [epoch_microseconds]
   DML_statement1;
   DML_statement2;
   DML_statement3;
APPLY BATCH;

Individual transactions - Insert at the end of a DML:

BEGIN BATCH
   DML_statement1;
   DML_statement2 USING TIMESTAMP [epoch_microseconds];
   DML_statement3;
APPLY BATCH;

#Examples
Applying a client supplied timestamp to all DMLs

Insert meals paid for Vera Adrian using the user-defined date when inserting the records:

cqlsh> TRUNCATE cycling.cyclist_expenses ;

cqlsh> BEGIN BATCH USING TIMESTAMP 1481124356754405
INSERT INTO cycling.cyclist_expenses 
   (cyclist_name, expense_id, amount, description, paid) 
   VALUES ('Vera ADRIAN', 2, 13.44, 'Lunch', true);
INSERT INTO cycling.cyclist_expenses 
   (cyclist_name, expense_id, amount, description, paid) 
   VALUES ('Vera ADRIAN', 3, 25.00, 'Dinner', true);
APPLY BATCH;

Note: Combining two statements for the same partition results in a single table mutation.

View the records vertically:

cqlsh> expand ON

Verify that the timestamps are all the same:

cqlsh> SELECT cyclist_name, expense_id,
        amount, WRITETIME(amount),
        description, WRITETIME(description),
        paid,WRITETIME(paid)
   FROM cycling.cyclist_expenses
WHERE cyclist_name = 'Vera ADRIAN';

Both records were entered with the same timestamp.

@ Row 1
------------------------+------------------
 cyclist_name           | Vera ADRIAN
 expense_id             | 2
 amount                 | 13.44
 writetime(amount)      | 1481124356754405
 description            | Lunch
 writetime(description) | 1481124356754405
 paid                   | True
 writetime(paid)        | 1481124356754405

@ Row 2
------------------------+------------------
 cyclist_name           | Vera ADRIAN
 expense_id             | 3
 amount                 | 25
 writetime(amount)      | 1481124356754405
 description            | Dinner
 writetime(description) | 1481124356754405
 paid                   | False
 writetime(paid)        | 1481124356754405

(2 rows)

If any DML statement in the batch uses compare-and-set (CAS) logic, 
for example the following batch with IF NOT EXISTS, an error is returned:

cqlsh> TRUNCATE cycling.cyclist_expenses ;

cqlsh> BEGIN BATCH USING TIMESTAMP 1481124356754405
  INSERT INTO cycling.cyclist_expenses 
     (cyclist_name, expense_id, amount, description, paid) 
     VALUES ('Vera ADRIAN', 2, 13.44, 'Lunch', true);
  INSERT INTO cycling.cyclist_expenses 
     (cyclist_name, expense_id, amount, description, paid) 
     VALUES ('Vera ADRIAN', 3, 25.00, 'Dinner', false) IF NOT EXISTS;
APPLY BATCH;

InvalidRequest: Error from server: code=2200 [Invalid query] message="Cannot provide custom timestamp for conditional BATCH"

###Batching counter updates
A batch of counters should use the COUNTER option because, unlike other writes in Cassandra, 
a counter update is not an idempotent operation.

CREATE TABLE IF NOT EXISTS cycling.UserActionCounts (
  keyalias int PRIMARY KEY,
  total counter
);

CREATE TABLE IF NOT EXISTS cycling.AdminActionCounts (
  keyalias int PRIMARY KEY,
  total counter
);

cqlsh> BEGIN COUNTER BATCH
  UPDATE cycling.UserActionCounts SET total = total + 2 WHERE keyalias = 523;
  UPDATE cycling.AdminActionCounts SET total = total + 2 WHERE keyalias = 701;
APPLY BATCH;

Counter batches cannot include non-counter columns in the DML statements, 
just as a non-counter batch cannot include counter columns. 

Counter batch statements cannot provide custom timestamps.



###Secondary Indexing
Use for low cardinality data else not performant as multiple partitions might be searched 
Not possible for counter column 
Not performant when frequently updated or deleted column

Secondary indexes are used to query a table using a column that is not normally queryable
(ie not in primary key or when all partition keys are not mentioned ).

The table rank_by_year_and_name can yield the rank of cyclists for races.

#Already created and data inserted 
cqlsh> CREATE TABLE IF NOT EXISTS cycling.rank_by_year_and_name ( 
  race_year int, 
  race_name text, 
  cyclist_name text, 
  rank int, 
  PRIMARY KEY ((race_year, race_name), rank) 
);

Both race_year and race_name must be specified as these columns comprise the partition key.

cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year=2015 AND race_name='Tour of Japan - Stage 4 - Minami > Shinshu';

Below fails as all keys are not included (if not used with ALLOW FILTERING)

cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year=2015;

An index name is optional and must be unique within a keyspace. Old data would be indexed asynchronously
If you do not provide a name, Cassandra will assign a name like race_year_idx.

cqlsh> CREATE INDEX ryear ON cycling.rank_by_year_and_name (race_year);

cqlsh> SELECT * FROM cycling.rank_by_year_and_name WHERE race_year=2015;

A clustering column can also be used to create an index. 
An index is created on rank, and used in a query.

cqlsh> CREATE INDEX rrank ON cycling.rank_by_year_and_name (rank);
SELECT * FROM cycling.rank_by_year_and_name WHERE rank = 1;

Random column 
> CREATE INDEX ON cycling.rank_by_year_and_name (cyclist_name);
 SELECT * FROM cycling.rank_by_year_and_name WHERE cyclist_name='something';


##Using multiple indexes in the same Query possible 
Indexes can be created on multiple columns and used in queries. 
In a real-world situation, certain columns might not be good choices(eg with high cardinality)

The table cycling.alt_stats can yield the statistics about cyclists.

cqlsh> CREATE TABLE cycling.cyclist_alt_stats_mod (
   id UUID PRIMARY KEY,
   lastname text,
   birthday date,
   nationality text,
   weight float,
   w_units text,
   height float,
   first_race date,
   last_race date);

INSERT INTO cycling.cyclist_alt_stats_mod (
   id,
   last_race)
VALUES (
   ed584e99-80f7-4b13-9a90-9dc5571e6821,
   todate(now()));

INSERT INTO cycling.cyclist_alt_stats_mod (
   id,
   first_race)
VALUES (
   ed584e99-80f7-4b13-9a90-9dc5571e6821,
   '2006-03-15');

UPDATE cycling.cyclist_alt_stats_mod
  SET birthday = '1987-03-07'
WHERE id = ed584e99-80f7-4b13-9a90-9dc5571e6821;

UPDATE cycling.cyclist_alt_stats_mod
  SET last_race = toDate(now())
WHERE id = ed584e99-80f7-4b13-9a90-9dc5571e6821;

INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height, first_race, last_race) VALUES (ed584e99-80f7-4b13-9a90-9dc5571e6821,'TSATEVICH', '1989-07-05', 'Russia', 64, 'kg', 1.69, '2006-03-15','2017-04-16');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (a9e96714-2dd0-41f9-8bd0-557196a44ecf,'ISAYCHEV', '1986-04-21', 'Russia', 80, 'kg', 1.88,'2003-04-22','2017-03-05');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (823ec386-2a46-45c9-be41-2425a4b7658e,'BELKOV', '1985-01-09', 'Russia', 71, 'kg', 1.84,'2002-03-22','2017-04-16');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (e0953617-07eb-4c82-8f91-3b2757981625,'BRUTT', '1982-01-29', 'Russia', 68, 'kg', 1.78,'1998-02-15','2017-04-16');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (078654a6-42fa-4142-ae43-cebdc67bd902,'LAGUTIN', '1981-01-14', 'Russia', 63, 'kg', 1.82,'1996-05-21','2010-10-02');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (d74d6e70-7484-4df5-8551-f5090c37f617,'GRMAY', '1991-08-25', 'Ethiopia', 63, 'kg', 1.75, '2006-05-21','2017-04-16');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (c09e9451-50da-483d-8108-e6bea2e827b3,'VEIKKANEN', '1981-03-29', 'Finland', 66, 'kg', 1.78,'1996-05-21','2012-10-02');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (f1deff54-7d96-4981-b14a-b70be4da82d2,'TLEUBAYEV', null, 'Kazakhstan', null, null, null, '2003-04-22','2017-04-16');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (1ba0417d-62da-4103-b710-de6fb227db6f,'PAULINHO', '1990-05-27', 'Portugal', null, null, null, '2006-03-15','2017-03-05');
INSERT INTO cycling.cyclist_alt_stats_mod (id, lastname, birthday, nationality, weight, w_units, height,  first_race, last_race) VALUES (4ceb495c-55ab-4f71-83b9-81117252bb13,'DUVAL', '1990-05-27','France', null, null, null, '2006-03-15','2017-04-16');


Create indexes on the columns birthday and nationality.

cqlsh> CREATE INDEX birthday_idx ON cycling.cyclist_alt_stats_mod ( birthday );
CREATE INDEX nationality_idx ON cycling.cyclist_alt_stats_mod ( nationality );

Query for all the cyclists with a particular birthday from a certain country.

cqlsh> SELECT * FROM cycling.cyclist_alt_stats_mod WHERE birthday = '1982-01-29' AND nationality = 'Russia' ALLOW FILTERING;

WITHOUT ALLOW FILTERING, query fails 
The error is not due to multiple indexes, but the lack of a partition key definition in the query.



###Indexing a collection
Collections can be indexed and queried to find a collection containing a particular value. 
Sets and lists are indexed slightly differently from maps, given the key-value nature of maps.

Sets and lists can index all values found by indexing the collection column. 

Maps can index a map key, map value, or map entry using the methods , KEYS, no method by default, ENTRIES
Multiple indexes can be created on the same map column in a table, so that map keys, values, 
or entries can be queried. 

In addition, frozen collections can be indexed using FULL to index the full content of a frozen collection.

Note: All the cautions eg low cardinality about using secondary indexes apply to indexing collections.

For set and list collections, create an index on the column name. 
Create an index on a set to find all the cyclists that have been on a particular team.

> CREATE TABLE IF NOT EXISTS cycling.cyclist_career_teams ( id UUID PRIMARY KEY, lastname text, teams set<text> );

cqlsh> CREATE INDEX team_idx ON cycling.cyclist_career_teams ( teams );
cqlsh> SELECT * FROM cycling.cyclist_career_teams WHERE teams CONTAINS 'Nederland bloeit';

For map collections, create an index on the map key, map value, or map entry. 
Create an index on a map key to find all cyclist/team combinations for a particular year.

> CREATE TABLE IF NOT EXISTS cycling.cyclist_teams ( id UUID PRIMARY KEY, lastname text, firstname text, teams map<int,text> );

cqlsh> CREATE INDEX team_year_idx ON cycling.cyclist_teams ( KEYS (teams) );
cqlsh> SELECT * From cycling.cyclist_teams WHERE teams CONTAINS KEY 2015;

On value 
CREATE INDEX team_year_idx2 ON cycling.cyclist_teams  (teams) ;
SELECT * From cycling.cyclist_teams WHERE teams CONTAINS 'Team DSB - Ballast Nedam';

Create an index on the map entries and find cyclists who are the same age. 
An index using ENTRIES is only valid for maps.

cqlsh> CREATE TABLE cycling.birthday_list (cyclist_name text PRIMARY KEY, blist map<text,text>);
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Allan DAVIS', {'blist_age':'35', 'bday':'27/07/1980', 'blist_nation':'AUSTRALIA'});
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Claudio VANDELLI', {'blist_age':'54', 'bday':'27/07/1961', 'blist_nation':'ITALY'});
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Laurence BOURQUE', {'blist_age':'23', 'bday':'27/07/1992', 'blist_nation':'CANADA'});
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Claudio HEINEN', {'blist_age':'23', 'bday':'27/07/1992', 'blist_nation':'GERMANY'});
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Luc HAGENAARS', {'blist_age':'28', 'bday':'27/07/1987', 'blist_nation':'NETHERLANDS'});
INSERT INTO cycling.birthday_list (cyclist_name, blist) VALUES ('Toine POELS', {'blist_age':'52', 'bday':'27/07/1963', 'blist_nation':'NETHERLANDS'});


cqlsh> CREATE INDEX blist_idx ON cycling.birthday_list (ENTRIES(blist));
cqlsh> SELECT * FROM cycling.birthday_list WHERE blist['blist_age'] = '23';

Using the same index, find cyclists from the same country.

cqlsh> SELECT * FROM cycling.birthday_list WHERE blist['blist_nation'] = 'NETHERLANDS';

Create an index on the map values and find cyclists who have a particular value found in the specified map. 
An index using VALUES is only valid for maps.

cqlsh> CREATE INDEX blist_id2x ON cycling.birthday_list (VALUES(blist));
cqlsh> SELECT * FROM cycling.birthday_list WHERE blist CONTAINS 'NETHERLANDS';

Create an index on the full content of a FROZEN map. 
The table in this example stores the number of Pro wins, Grand Tour races, and Classic races 
that a cyclist has competed in. The SELECT statement finds any cyclist who has 39 Pro race wins, 
7 Grand Tour starts, and 14 Classic starts.

cqlsh> CREATE TABLE cycling.race_starts (cyclist_name text PRIMARY KEY, rnumbers FROZEN<LIST<int>>);
INSERT INTO cycling.race_starts (cyclist_name, rnumbers) VALUES ('John DEGENKOLB', [39,7,14]);

cqlsh> CREATE INDEX rnumbers_idx ON cycling.race_starts (FULL(rnumbers));
cqlsh> SELECT * FROM cycling.race_starts WHERE rnumbers = [39,7,14];




###Using materialized views 

In Cassandra, a materialized view is a table built from data in another table with a new primary key
and new properties. 

In the materialized view, data is updated automatically by changes to the source table.

Materialized views are suited for high cardinality data. 
Secondary indexes are suited for low cardinality data. 

Note this feature is experimental and Know limitation exists 
https://docs.datastax.com/en/cql-oss/3.3/cql/cql_using/knownLimitationsMV.html

Use below recommendations to avoid know limitations 
    Write to base tables with materialized views using consistency levels greater than ONE 
        (such as LOCAL_QUORUM) to avoid base-view inconsistency
    Run full repair on both the base table and the view whenever a node is removed, replaced, down or added 
        Dont run incremental repair        
    Run repair periodically on views (at every gc_grace_seconds) to ensure that tombstones 
        for views are successfully propagated to all replicas, and to prevent data resurrection.
        https://cassandra.apache.org/doc/latest/cassandra/operating/repair.html
    Dont delete columns on base table not selected in MV 
    OR select all columns of base table in MV 
    

A view must have a primary key and that primary key must conform to the following restrictions:
    it must contain all the primary key columns of the base table(order might change)
        (so new extra column can be partition key or clustering key)
        This ensures that every row of the view correspond to exactly one row of the base table.
    it can only contain a single column that is not a primary key column in the base table.
    Exclude rows with null values in the materialized view primary key column.
    
So for instance, give the following base table definition:

> CREATE TABLE t (
    k int,
    c1 int,
    c2 int,
    v1 int,
    v2 int,
    PRIMARY KEY (k, c1, c2)
);

then the following view definitions are allowed:

> CREATE MATERIALIZED VIEW mv1 AS
   SELECT * FROM t
   WHERE k IS NOT NULL AND c1 IS NOT NULL AND c2 IS NOT NULL
   PRIMARY KEY (c1, k, c2);  //now c1 is partition key 

> CREATE MATERIALIZED VIEW mv1 AS
  SELECT * FROM t
  WHERE k IS NOT NULL AND c1 IS NOT NULL AND c2 IS NOT NULL
  PRIMARY KEY (v1, k, c1, c2); //now v1 is partition key 

but the following ones are not allowed:

// Error: cannot include both v1 and v2 in the primary key as both are not in the base table primary key

> CREATE MATERIALIZED VIEW mv1 AS
   SELECT * FROM t
   WHERE k IS NOT NULL AND c1 IS NOT NULL AND c2 IS NOT NULL AND v1 IS NOT NULL
   PRIMARY KEY (v1, v2, k, c1, c2);

// Error: must include k in the primary as it's a base table primary key column

> CREATE MATERIALIZED VIEW mv1 AS
   SELECT * FROM t
   WHERE c1 IS NOT NULL AND c2 IS NOT NULL
   PRIMARY KEY (c1, c2);



##Creating a materialized view

When another INSERT is executed on cyclist_mv, Cassandra updates the source table 
and both of these materialized views. 

When data is deleted from cyclist_mv, Cassandra deletes the same data from any related materialized views.

Cassandra can only write data directly to source tables, not to materialized views. 
Cassandra updates a materialized view asynchronously after inserting data into the source table, 
so the update of materialized view is delayed. 

Cassandra performs a read repair to a materialized view only after updating the source table.

> CREATE TABLE IF NOT EXISTS cycling.cyclist_mv (
  cid UUID PRIMARY KEY, 
  name text, 
  age int, 
  birthday date, 
  country text
);

> INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (e7ae5cf3-d358-4d99-b900-85902fda9bb0,'Alex FRAME', 22, '1993-06-18', 'New Zealand');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (220844bf-4860-49d6-9a4b-6b5d3a79cbfb,'Paolo TIRALONGO', 38, '1977-07-08', 'Italy');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47,'Steven KRUIKSWIJK', 28, '1987-06-07', 'Netherlands');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (ffdfa2a7-5fc6-49a7-bfdc-3fcdcfdd7156,'Pascal EENKHOORN', 18, '1997-02-08', 'Netherlands');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (18f471bf-f631-4bc4-a9a2-d6f6cf5ea503,'Bram WELTEN', 18, '1997-03-29', 'Netherlands');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (15a116fc-b833-4da6-ab9a-4a7775752836,'Adrien COSTA', 18, '1997-08-19', 'United States');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (862cc51f-00a1-4d5a-976b-a359cab7300e,'Joakim BUKDAL', 20, '1994-09-04', 'Denmark');
INSERT INTO cycling.cyclist_mv (cid,name,age,birthday,country) VALUES (c9c9c484-5e4a-4542-8203-8d047a01b8a8,'Cristian EGIDIO', 27, '1987-09-04', 'Brazil');

This table holds values for the name, age, birthday, and country affiliation of several cyclists.
The cyclist_mv table can be the basis of a materialized view that uses age in the primary key.

> CREATE MATERIALIZED VIEW cycling.cyclist_by_age 
    AS SELECT age, birthday, name, country FROM cyclist_mv 
    WHERE age IS NOT NULL AND cid IS NOT NULL 
    PRIMARY KEY (age, cid);

Because the new materialized view is partitioned by age, 
it supports queries based on the cyclists' ages.

> SELECT age, name, birthday FROM cycling.cyclist_by_age WHERE age = 18;

Other materialized views, based on the same source table, 
can organize information by cyclists' birthdays or countries of origin.

> CREATE MATERIALIZED VIEW cycling.cyclist_by_birthday 
    AS SELECT age, birthday, name, country 
    FROM cyclist_mv 
    WHERE birthday IS NOT NULL AND cid IS NOT NULL
    PRIMARY KEY (birthday, cid);

CREATE MATERIALIZED VIEW cycling.cyclist_by_country 
    AS SELECT age, birthday, name, country 
    FROM cyclist_mv 
    WHERE country IS NOT NULL AND cid IS NOT NULL
    PRIMARY KEY (country, cid);

The following queries use the new materialized views.

> SELECT age, name, birthday FROM cycling.cyclist_by_country WHERE country = 'Netherlands';

> SELECT age, name, birthday FROM cycling.cyclist_by_birthday WHERE birthday = '1987-09-04';




###Altering a table
https://docs.datastax.com/en/cql-oss/3.3/cql/cql_using/useAlterTableTOC.html

ALTER TABLE keyspace_name.table_name 
    ALTER column_name TYPE   cql_type
    | ADD column_name cql_type 
    | DROP column_name 
    |  RENAME column_name TO column_name
    |  WITH property [ AND property ] . . . } 

but when you ADD a new column, you can define it as a map or collection, 
If the table is a counter, you can ADD a column of type counter.

ALTER TYPE 
    removed 
    https://issues.apache.org/jira/browse/CASSANDRA-12443
    OLD: 
        You cannot change the type of an existing column to a map or collection, 
        Changing the type of a column
        Following are possible 
        ascii, bigint, boolean, decimal, double, float, inet, int, timestamp, timeuuid, 
        uuid, varchar, varint => blob
        int => varint
        text => varchar
        timeuuid => uuid
        varchar => text     
        The following datatype changes are not supported:
            Changing the type of a clustering column(except int=>varint, text <=>varchar)
            Changing the type of a column on which an index is defined

You cannot use the ADD command to add:
    A column with the same name as an existing column
    A static column if the table has no clustering columns or uses COMPACT STORAGE.

More tips about dropping columns:
    If you drop a column then re-add it, Cassandra does not restore the values written before the column was dropped. A subsequent SELECT on this column does not return the dropped data.
    You cannot drop columns from tables defined with the COMPACT STORAGE option.

The following restrictions apply to the RENAME operation:
    You can only rename clustering columns, which are part of the primary key.
    You cannot rename the partition key.
    You can index a renamed column.
    You cannot rename a column if an index has been created on it.
    You cannot rename a static column (since you cannot use a static column in the table's primary key).

###Altering columns in a table
The ALTER TABLE command can be used to add new columns to a table 
and to alter the column type of an existing column(above restrictions apply)

Add a age column of type int to the table cycling.cyclist_alt_stats.

cqlsh> ALTER TABLE cycling.cyclist_alt_stats ADD age int;

This creates the column metadata and adds the column to the table schema, 
and sets the value to NULL for all rows.

Add a column favorite_color of varchar, and then change the data type of the same column to text.

cqlsh> ALTER TABLE cycling.cyclist_alt_stats ADD favorite_color varchar;

#ALTER TYPE REMOVED - SEE above 
cqlsh> ALTER TABLE cycling.cyclist_alt_stats ALTER favorite_color TYPE text;

##Altering a table to add a collection

Alter the table cycling.upcoming_calendar to add a collection map description that can store a description 
for each race listed.

cqlsh> ALTER TABLE cycling.upcoming_calendar ADD description map<text,text>;

After updating cycling.upcoming_calendar table to insert some data, description can be displayed.

cqlsh> UPDATE cycling.upcoming_calendar 
SET description = description + {'Criterium du Dauphine' : 'Easy race', 'Tour du Suisse' : 'Hard uphill race'} WHERE year = 2015 AND month = 6;


##Altering the table properties
Alter a table to change the caching properties.

cqlsh> ALTER TABLE cycling.race_winners WITH caching = {'keys' : 'NONE', 'rows_per_partition' : '15' };

where caching is 
caching
    Caching optimizes the use of cache memory of a table without manual tuning. 
    Cassandra weighs the cached data by size and access frequency. 
    Coordinate this setting with the global caching properties in the cassandra.yaml file. 
    caching = {
     'keys' = 'ALL | NONE',
     'rows_per_partition' = 'ALL' | 'NONE' |N}
    Valid values:
        ALL– all primary keys or rows
        NONE– no primary keys or rows
        N: (rows per partition only) Number of rows; specify a whole number


###HANDSON  on Select 

Create table playlists with below 
  id uuid,
  song_order int,
  song_id uuid,
  title text,
  album text,
  artist text,
Compound primary key id, song_order 

Insert 
62c36092-82a1-3a00-93d1-46196ee77204, 4, 7db1a490-5878-11e2-bcfd-0800200c9a66,
'Ojo Rojo', 'Fu Manchu', 'No One Rides for Free';

62c36092-82a1-3a00-93d1-46196ee77204, 1,
  a3e64f8f-bd44-4f28-b8d9-6938726e34d4, 'La Grange', 'ZZ Top', 'Tres Hombres'

62c36092-82a1-3a00-93d1-46196ee77204, 2,
  8a172618-b121-4136-bb10-f665cfc469eb, 'Moving in Stereo', 'Fu Manchu', 'We Must Obey'

62c36092-82a1-3a00-93d1-46196ee77204, 3,
  2b09185b-fb5a-4734-9b56-49077de9edbf, 'Outside Woman Blues', 'Back Door Slam', 'Roll Away'

  
Select all from playlists

select album, title from playlists if artist = 'Fu Manchu'
( do we get error on above?, why?)

Solve the above error 

Now, select album, title from playlists if artist = 'Fu Manchu'

Select all from playlists if  id is 62c36092-82a1-3a00-93d1-46196ee77204
and oder should be desc by song_order and limit 5

Lets add tags set<text>  to the table 

Update the playlists table to insert the tags data
'2007' for id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 2;
'covers' for id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 2;
'1973' for id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 1;
'blues' for id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 1;
'rock' for id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 4;

Add reviews with datatype list<text> and venue with datatype map<timestamp, text> in the table 

Update the playlists table to insert the tags data
'punk rock' for  id = 62c36092-82a1-3a00-93d1-46196ee77204 AND song_order = 4;

Update reviews data 
'best lyrics'for id = 62c36092-82a1-3a00-93d1-46196ee77204 and song_order = 4;

Update venues data 
{ '2013-9-22 22:00'  : 'The Fillmore',
  '2013-10-1 21:00' : 'The Apple Barrel'} for id = 62c36092-82a1-3a00-93d1-46196ee77204, song_order =4,
{ '2014-1-22 22:00'  : 'Cactus Cafe',
  '2014-01-12 20:00' : 'Mohawk'}  for id = 62c36092-82a1-3a00-93d1-46196ee77204, song_order =3


Index collections on tags and values of   venue

Will you able to query on tags?
get album, tags when tags contains 'blues'
get all when venue contains 'The Fillmore'

drop values of   venue index and create on keys 

get album, venue FROM playlists when  venue CONTAINS KEY '2013-09-22 22:00:00-0700';

Create Indexes on the entries of venue 
Get all when  venue['2013-9-22 22:00'] = 'The Fillmore';




###Removing a keyspace, schema, or data


#Drop the cycling.last_3_days table.
cqlsh> DROP TABLE cycling.last_3_days;


#Deleting columns and rows
Delete the values of the column lastname from the table cyclist_name.

cqlsh> DELETE lastname FROM cycling.cyclist_name WHERE id = c7fceba0-c141-4207-9494-a29f9809de6f;

Delete entire row for a particular race from the table calendar.

cqlsh> DELETE FROM cycling.calendar WHERE race_id = 200;

#Delete an entire row using LWT (check first and then only deletes in isolated/atomic manner)
> DELETE FROM cycling.cyclist_name 
    WHERE id=e7ae5cf3-d358-4d99-b900-85902fda9bb0 IF EXISTS;

#Delete row based on  non-primary column condition
> DELETE FROM cycling.cyclist_name 
WHERE id =e7ae5cf3-d358-4d99-b900-85902fda9bb0 
if firstname='Alex' and lastname='Smith';


 [applied] | firstname | lastname
-----------+-----------+----------
     False |      Alex |    FRAME

#Deleting old data using TIMESTAMP,representing microseconds. 
You can identify the column for deletion using TIMESTAMP.

> DELETE firstname, lastname
  FROM cycling.cyclist_name
  USING TIMESTAMP 1318452291034
  WHERE lastname = 'VOS';

#Deleting more than one row
> DELETE FROM cycling.cyclist_name 
WHERE id = 6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47; //one row 

> DELETE FROM cycling.cyclist_name 
WHERE firstname IN ('Alex', 'Marianne');


##Dropping a user-defined function (UDF)
Drop the fLog() function. The conditional option IF EXISTS can be included.

cqlsh> DROP FUNCTION IF EXISTS cycling.fLog(double);

##Dropping a keyspace or table
Drop the test keyspace. 

#cqlsh> DROP KEYSPACE cycling ;


