Cassandra internals
    Rack and network topology
    Snitches
    Understanding read, write, update paths            
    Repairing Nodes 
Cassandra cluster
    Docker and cluster creation 
    Understanding Replication factor and Consistency 
    Understanding Tombstone 
Introduction to cassandra Adminstration 
-------------------------------------------------
### Creating Docker cluster (delete old cluster at first)
> docker image ls
#Create a network 
#Singel host - bridge, multiple host docker-overlay , check https://docs.docker.com/engine/reference/commandline/network_create/
> docker network rm CassandraNetwork
> docker network create -d bridge CassandraNetwork

> docker container stop cas1 cas2 cas3
> docker container rm cas1 cas2 cas3

#-m=1g, restrict memory of container , https://docs.docker.com/config/containers/resource_constraints/
#check for env var https://hub.docker.com/_/cassandra
#eg cassandra memory can be restricted as -e MAX_HEAP_SIZE=1G -e HEAP_NEWSIZE=100M , used for setting java memory 
> docker run --name cas1  -m=1g --network CassandraNetwork -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter1 -e CASSANDRA_RACK=rack1 -d cassandra:4.0.1
> docker container ls 
> docker logs cas1

#Ensure it is UN 
$ docker exec -ti cas1 nodetool status 

> docker stats --no-stream
> docker exec -it cas1 nodetool version

#get IP - Uses GO template 
#https://docs.docker.com/engine/reference/commandline/inspect/
#https://docs.gomplate.ca/syntax/

For default network 
> docker inspect --format='{{ .NetworkSettings.IPAddress}}' cas1

for custom network 
> docker inspect --format='{{ .NetworkSettings.Networks.CassandraNetwork.IPAddress}}' cas1
MAIN_IP=$(docker inspect --format='{{ .NetworkSettings.Networks.CassandraNetwork.IPAddress}}' cas1)
eg The main ip is 172.20.0.2


#Other nodes 
> docker container rm cas2 cas3 
> docker run --name cas2 -m=1g  --network CassandraNetwork  -e CASSANDRA_SEEDS=172.20.0.2 -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter1 -e CASSANDRA_RACK=rack1 -d cassandra:4.0.1
#Ensure both are visible 
$ docker exec -ti cas1 nodetool status 

> docker run --name cas3 -m=1g  --network CassandraNetwork -e CASSANDRA_SEEDS=172.20.0.2 -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter2 -e CASSANDRA_RACK=rack2 -d cassandra:4.0.1

> docker container ls --all

> docker logs cas2
> docker logs cas3 

#Ensure all are UN 
$ docker exec -ti cas1 nodetool status 

#Connect to Cassandra from cqlsh
> docker exec -ti cas1 nodetool status
The status column of each node should show UN (node is UP and its state is Normal). 
If you see 'UJ' that means your node is joining, just wait for a while and check it again. 
Tokens means no of vnodes and owns does not have much meaning in cluster, see it with keyspace 

#Container shell access 
> docker exec -it cas1 bash

#Stop 
> docker stop cas3 cas2 cas1
#Start 
> docker start cas3 cas2 cas1

#Stop docker VM 
$ docker-machine stop default

#start cqlsh 
> docker exec -ti cas1 cqlsh

#DC can have a different replication factor and 
#( RF in a DC must be less than no of nodes in a DC , different DC holds complete no of copies based on RF)
#All replicas are equally important; there is no primary or master replica

#RF with 1 for each DC ie 1 copy  and that copy is distributed between all nodes 
#(so each node in a DC gets some portion of data when RF < #nodes, owns = (100/#nodes) *  RF  %)
#and QUORUM is 2/2 + 1 = 2 , so no node can go down 
> CREATE KEYSPACE mykeyspace WITH replication = {'class':'NetworkTopologyStrategy','datacenter1': 1,'datacenter2': 1};

> CREATE TABLE mykeyspace.mytable (id int primary key,name text);

$ docker exec -ti cas1 nodetool status mykeyspace
Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load       Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.3  74.23 KiB  16      51.2%             f8205b13-de6b-4a9c-9c7a-ece9c4a0d27b  rack1
UN  172.20.0.2  96.61 KiB  16      48.8%             8be61111-b31b-45c9-ba59-fbac41d8eda2  rack1

Datacenter: datacenter2
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load       Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.4  91.57 KiB  16      100.0%            fe539440-58b3-4ed2-8254-8f5aeba7c289  rack1

##With RF of 2  at DC1 ie each node of DC1 gets one copy ,DC2's RF is 1 and node 1, so that gets copy 
#and QUORUM is 3/2 + 1 = 2 , so one node can go down in DC1, but no node at DC2 
> CREATE KEYSPACE mykeyspace2 WITH replication = {'class':'NetworkTopologyStrategy','datacenter1': 2,'datacenter2': 1};

> CREATE TABLE mykeyspace2.mytable (id int primary key,name text);

#now each is 100% means owns full copy of the data 
$ docker exec -ti cas1 nodetool status mykeyspace2
Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load        Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.3  91.56 KiB   16      100.0%            f8205b13-de6b-4a9c-9c7a-ece9c4a0d27b  rack1
UN  172.20.0.2  103.77 KiB  16      100.0%            8be61111-b31b-45c9-ba59-fbac41d8eda2  rack1

Datacenter: datacenter2
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load        Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.4  98.74 KiB   16      100.0%            fe539440-58b3-4ed2-8254-8f5aeba7c289  rack1

###Consistency Experimentation in cluster 
##Trace reads at different consistency levels
(windows)"C:\Program Files\Git\bin\bash.exe" --login -i "C:\Docker\start.sh"
> docker container start cas1 
> docker container start cas2 cas3 
> docker exec -ti cas1 nodetool status mykeyspace2
> docker exec -ti cas1 cqlsh

Create a table, and insert some values:

cqlsh> USE mykeyspace2;
cqlsh> CREATE TABLE IF NOT EXISTS mykeyspace2.tester ( id int PRIMARY KEY, col1 int, col2 int );
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (0, 0, 0);
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (1, 0, 0);

cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;
 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0

(2 rows)

The recommended partitioner takes your partition key values 
and then computes a 128 bit hash(murmur3) from them. 
The hash is called the token of the record, and it is that token value that determines where your record is stored. 

Each Cassandra node has a set of token ranges associated with it. 
If the token of a record falls with a range of a node, the record is stored on that node. 
(and then replicated based on ReplicationStrategy - for SimpleStrategy, next replica goes to next node in the rign
for NetworkTopologyStrategy, next replica goes to next Rack if available , never spans DC 
as each DC has own RF)

The number of partitions is not determined by your choice of partition key: 
it is the number of token ranges in your cluster. 
That is roughly equal to the total number of vnodes you selected when you configured 
your data store nodes(cassandra.yaml:num_tokens, here it is 16)

Who owns this token (first line is the last token, vnodes are 16 so, 16 token range/node, 
each vnode displays end token from its range, all vnodes from both nodes in DC1 form a ring 
where end token of one vnode becomes start token of next vnode .
each DC has own ring with similar  token range . PartitionKey -> token/hash -> goes to both DC)

> docker exec -ti cas1 nodetool ring
Datacenter: datacenter1
==========
Address          Rack        Status State   Load            Owns                Token
                                                                                8900047540065365356
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -8892077648528157142
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -8465791147247027752
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -7768062232820599131
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -7115589320672349868
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -6672020332585660842
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -6058212803743391651
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -5580723221893448582
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -4736346574402286825
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -3936517903741156541
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -3296078344499703585
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -2678097312597503507
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -2224577728159670773
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -1613756322824440111
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -1206726323417243757
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -389054390804892963
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   206247978155506286
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   686701490420686575
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   1422617183131580216
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   2083312307668492315
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   2501989990579181874
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   3252267230847506694
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   3745509996259773846
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   4301391031176697782
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   4712874239338309345
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   5237304203968213202
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   5652941863539853082
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   6302878791852207983
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   6864622210211834227
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   7261945062560547018
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   7921902087549251280
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   8520365778505990106
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   8900047540065365356
Datacenter: datacenter2
==========
Address          Rack        Status State   Load            Owns                Token
                                                                                8320052126484789930
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -9055191330884728872
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -8037339926142301856
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -7219667993529951062
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -6143912112304371522
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -5407996419593477881
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -4328623612145876224
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -3085103606465284250
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -2117739363386748752
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -527734810872850114
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   1091288484824193182
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   2069433937340307258
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   3848068238163894386
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   4944110138398832675
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   6035407249091044934
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   6879783896582206692
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   8320052126484789930

There is also the nodetool describering command which lists the start and end tokens of the ranges 
for each keyspace on the nodes. first endpoint in endpoints is the primary host holding data, others are replica , 
In our case, DC2:RF2+DC2:RF1 = means 3 copies of the same data , hence endpoints are also three 
and last two are highers nodes in the node ring where replica goes 

(below lists 48 vnodes from two DC2)

> docker exec -ti cas1 nodetool describering -- mykeyspace2
Schema Version:091b8f5b-d8bb-35a0-bff5-7e7b4671589b
TokenRange:
        TokenRange(start_token:-3085103606465284250, end_token:-2678097312597503507, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-389054390804892963, end_token:206247978155506286, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:8320052126484789930, end_token:8520365778505990106, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-8465791147247027752, end_token:-8037339926142301856, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-4736346574402286825, end_token:-4328623612145876224, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2117739363386748752, end_token:-1613756322824440111, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:6864622210211834227, end_token:6879783896582206692, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4712874239338309345, end_token:4944110138398832675, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:8520365778505990106, end_token:8900047540065365356, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6143912112304371522, end_token:-6058212803743391651, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-3296078344499703585, end_token:-3085103606465284250, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:3848068238163894386, end_token:4301391031176697782, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:5652941863539853082, end_token:6035407249091044934, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:8900047540065365356, end_token:-9055191330884728872, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-527734810872850114, end_token:-389054390804892963, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:3252267230847506694, end_token:3745509996259773846, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7768062232820599131, end_token:-7219667993529951062, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6672020332585660842, end_token:-6143912112304371522, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2224577728159670773, end_token:-2117739363386748752, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:2083312307668492315, end_token:2501989990579181874, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:7261945062560547018, end_token:7921902087549251280, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:6035407249091044934, end_token:6302878791852207983, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-8892077648528157142, end_token:-8465791147247027752, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:206247978155506286, end_token:686701490420686575, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:3745509996259773846, end_token:3848068238163894386, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7115589320672349868, end_token:-6672020332585660842, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-1206726323417243757, end_token:-527734810872850114, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-1613756322824440111, end_token:-1206726323417243757, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:1422617183131580216, end_token:2069433937340307258, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:6302878791852207983, end_token:6864622210211834227, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4301391031176697782, end_token:4712874239338309345, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-3936517903741156541, end_token:-3296078344499703585, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6058212803743391651, end_token:-5580723221893448582, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-5407996419593477881, end_token:-4736346574402286825, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:2501989990579181874, end_token:3252267230847506694, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:6879783896582206692, end_token:7261945062560547018, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-5580723221893448582, end_token:-5407996419593477881, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-9055191330884728872, end_token:-8892077648528157142, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:7921902087549251280, end_token:8320052126484789930, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7219667993529951062, end_token:-7115589320672349868, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:2069433937340307258, end_token:2083312307668492315, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:5237304203968213202, end_token:5652941863539853082, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:686701490420686575, end_token:1091288484824193182, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:1091288484824193182, end_token:1422617183131580216, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2678097312597503507, end_token:-2224577728159670773, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-8037339926142301856, end_token:-7768062232820599131, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4944110138398832675, end_token:5237304203968213202, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-4328623612145876224, end_token:-3936517903741156541, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])

#get all endponts for a partitionkey (3 as here total RFs is 2)
$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 tester 0
172.20.0.2
172.20.0.4
172.20.0.3

$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 tester 1
172.20.0.3
172.20.0.2
172.20.0.4

##Understanding - COnsistenacy 
Turn on tracing and use the CONSISTENCY command to check that the consistency level is ONE, the default.

cqlsh> TRACING on;
cqlsh> CONSISTENCY;
Current consistency level is ONE.

Coordinator node (in our case where cqlsh is running)
This node is called a "coordinator node" and is typically chosen based-on having the least (closest) "network distance." 
Client requests can really be sent to any node, and at first they will be sent to the nodes which your driver knows about. 
But once it connects and understands the topology of your cluster, it may change to a "closer" coordinator.


cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

The output includes tracing information:

  id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: cd542ba0-06dc-11ec-8f20-9bdae76af347

 activity                                                                                     | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                           Execute CQL3 query | 2021-08-27 02:16:34.911000 | 172.20.0.2 |              0 | 127.0.0.1
         Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:16:34.960000 | 172.20.0.2 |          50694 | 127.0.0.1
                                            Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:16:34.963000 | 172.20.0.2 |          51444 | 127.0.0.1
                             reading data from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:16:34.984000 | 172.20.0.2 |          74633 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.3:7000 message size 86 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:16:34.994000 | 172.20.0.2 |          84169 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:16:34.998000 | 172.20.0.3 |            738 | 127.0.0.1
                    READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:16:35.039000 | 172.20.0.2 |         129823 | 127.0.0.1
                           Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 02:16:35.041000 | 172.20.0.2 |         131237 | 127.0.0.1
                                                                             Request complete | 2021-08-27 02:16:35.046811 | 172.20.0.2 |         135811 | 127.0.0.1

(Coordinator node  = 172.20.0.2, others are 172.20.0.3 and 172.20.0.4)
The tracing results list all the actions taken to complete the SELECT statement.
(with ONE, only one node returns READ_RSP and query returns, check 'source' to know which source s writing msg) 

Change the consistency level to QUORUM to trace what happens during a read with a QUORUM consistency level.
(in our case , it is 2, check source, two sources return READ_RSP to cordinator
Note cordinator in general does not partcipate  )

#for both read and write 
cqlsh> CONSISTENCY quorum;
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

 id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: 265f6d90-06dd-11ec-8f20-9bdae76af347

                                                                                                      activity              | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                         Execute CQL3 query | 2021-08-27 02:19:04.297000 | 172.20.0.2 |              0 | 127.0.0.1
                                       Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:19:04.298000 | 172.20.0.2 |            663 | 127.0.0.1
                                                                          Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:19:04.307000 | 172.20.0.2 |           9495 | 127.0.0.1
                                                                   Executing single-partition query on tester[ReadStage-2]  | 2021-08-27 02:19:04.332000 | 172.20.0.2 |          34501 | 127.0.0.1
                                                                                 Acquiring sstable references[ReadStage-2]  | 2021-08-27 02:19:04.340000 | 172.20.0.2 |          42859 | 127.0.0.1
                                                                                    Merging memtable contents[ReadStage-2]  | 2021-08-27 02:19:04.341000 | 172.20.0.2 |          43130 | 127.0.0.1
                                                         reading digest from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:19:04.349000 | 172.20.0.2 |          51265 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 02:19:04.354000 | 172.20.0.2 |          46045 | 127.0.0.1
                               Sending READ_REQ message to /172.20.0.3:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.357000 | 172.20.0.2 |          55840 | 127.0.0.1
                                                  READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.363000 | 172.20.0.3 |             32 | 127.0.0.1
                                                                   Executing single-partition query on tester[ReadStage-1]  | 2021-08-27 02:19:04.366000 | 172.20.0.3 |           3494 | 127.0.0.1
                                                                                 Acquiring sstable references[ReadStage-1]  | 2021-08-27 02:19:04.367000 | 172.20.0.3 |           3819 | 127.0.0.1
                                                                                    Merging memtable contents[ReadStage-1]  | 2021-08-27 02:19:04.367000 | 172.20.0.3 |           4118 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-1]  | 2021-08-27 02:19:04.368000 | 172.20.0.3 |           4953 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-1]  | 2021-08-27 02:19:04.393000 | 172.20.0.3 |          30127 | 127.0.0.1
 speculating read retry on Full(/172.20.0.4:7000,(-3936517903741156541,-3296078344499703585]) [Native-Transport-Requests-1] | 2021-08-27 02:19:04.394000 | 172.20.0.2 |          96659 | 127.0.0.1
                               Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.395000 | 172.20.0.3 |          32145 | 127.0.0.1
                               Sending READ_REQ message to /172.20.0.4:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.400000 | 172.20.0.2 |         102204 | 127.0.0.1
                                                  READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.408000 | 172.20.0.2 |         110844 | 127.0.0.1
                                                         Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 02:19:04.413000 | 172.20.0.2 |         115296 | 127.0.0.1
                                                  READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.414000 | 172.20.0.4 |           3511 | 127.0.0.1
                                                  READ_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.531000 | 172.20.0.2 |             66 | 127.0.0.1
                                                         Processing response from /172.20.0.4:7000 [RequestResponseStage-3] | 2021-08-27 02:19:04.532000 | 172.20.0.2 |            999 | 127.0.0.1
                                                                                                           Request complete | 2021-08-27 02:19:04.418285 | 172.20.0.2 |         121285 | 127.0.0.1


Change the consistency level to ALL and run the SELECT statement again.
(In our case,  coordinator, 172.20.0.2 now participates "Read 1 live rows and 0 tombstone cells"
and there are processing three nodes)

#for both read and write 
cqlsh> CONSISTENCY ALL;
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

 id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: aa474b10-06e1-11ec-8f20-9bdae76af347

 activity                                                                                     | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                           Execute CQL3 query | 2021-08-27 02:51:23.585000 | 172.20.0.2 |              0 | 127.0.0.1
         Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:51:23.586000 | 172.20.0.2 |            581 | 127.0.0.1
                                            Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:51:23.586000 | 172.20.0.2 |            922 | 127.0.0.1
                           reading digest from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:51:23.604000 | 172.20.0.2 |          18188 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-3] | 2021-08-27 02:51:23.605000 | 172.20.0.2 |          20045 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-3] | 2021-08-27 02:51:23.606000 | 172.20.0.2 |          20235 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-3] | 2021-08-27 02:51:23.606000 | 172.20.0.2 |          20332 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-3] | 2021-08-27 02:51:23.608000 | 172.20.0.2 |          22383 | 127.0.0.1
                           reading digest from /172.20.0.4:7000 [Native-Transport-Requests-1] | 2021-08-27 02:51:23.615000 | 172.20.0.2 |          29415 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.3:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.615000 | 172.20.0.2 |          29831 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.617000 | 172.20.0.3 |             43 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.4:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.618000 | 172.20.0.2 |          33009 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.619000 | 172.20.0.4 |             45 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |            851 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |           1056 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |           1147 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6373 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.4 |           3400 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6666 | 127.0.0.1
                                         Enqueuing response to /172.20.0.2:7000 [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.4 |           3591 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6766 | 127.0.0.1
 Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.627000 | 172.20.0.4 |           8180 | 127.0.0.1
                    READ_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.630000 | 172.20.0.2 |          44720 | 127.0.0.1
                           Processing response from /172.20.0.4:7000 [RequestResponseStage-4] | 2021-08-27 02:51:23.632000 | 172.20.0.2 |          46635 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-1] | 2021-08-27 02:51:23.634000 | 172.20.0.3 |          17309 | 127.0.0.1
                                         Enqueuing response to /172.20.0.2:7000 [ReadStage-1] | 2021-08-27 02:51:23.641000 | 172.20.0.3 |          24193 | 127.0.0.1
 Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.647000 | 172.20.0.3 |          29921 | 127.0.0.1
                    READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.656000 | 172.20.0.2 |          70372 | 127.0.0.1
                           Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 02:51:23.659000 | 172.20.0.2 |          73188 | 127.0.0.1
                                                                             Request complete | 2021-08-27 02:51:23.659685 | 172.20.0.2 |          74685 | 127.0.0.1                                            


#for both read and write 
cqlsh> CONSISTENCY QUORUM;

#Down one eg cas3 from DC2 
> docker container stop cas3 

$ docker exec -ti cas1 nodetool status mykeyspace2
#Datacenter2 is down 

cqlsh> TRACING OFF;

cqlsh> CONSISTENCY;
Current consistency level is QUORUM.

#Successful because Quorum is 2 from any DC 
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (3, 0, 0);
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0


#start 
> docker container start cas3 
> docker exec -ti cas1 nodetool status mykeyspace2

#Set Quorum ALL such that from all must return consistent data (eventually it would)
cqlsh> CONSISTENCY ALL;

Hinting is a data repair technique applied during write operations. 
When replica nodes are unavailable to accept a mutation, either due to failure or more commonly routine maintenance, 
coordinators attempting to write to those replicas store temporary hints on their local filesystem for 
replying those later to unavailable replica when it comes up 

New hints will be retained for up to max_hint_window_in_ms of downtime (defaults to 3 hours)

#All return the consistent data as either because of Hints or when background read repair is done 
#if there is read inconsistencies
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 3;

 id | col1 | col2
----+------+------
  3 |    0 |    0

(1 rows)

#Now down two and check Quorum fails 
> docker container stop cas3 cas2 

$ docker exec -ti cas1 nodetool status mykeyspace2
#Datacenter2 is down 

cqlsh> CONSISTENCY QUORUM;

#Data is NOT inserted, as Consistency check fails 
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (4, 0, 0);
NoHostAvailable: ('Unable to complete the operation against any hosts', {<Host: 127.0.0.1:9042 datacenter1>: 
Unavailable('Error from server: code=1000 [Unavailable exception] message="Cannot achieve consistency level QUORUM" 
info={\'consistency\': \'QUORUM\', \'required_replicas\': 2, \'alive_replicas\': 1}')})

cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;
NoHostAvailable: ('Unable to complete the operation against any hosts', {<Host: 127.0.0.1:9042 datacenter1>: 
Unavailable('Error from server: code=1000 [Unavailable exception] message="Cannot achieve consistency level QUORUM" 
info={\'consistency\': \'QUORUM\', \'required_replicas\': 2, \'alive_replicas\': 1}')})

cqlsh> CONSISTENCY ONE;
Consistency level set to ONE.
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0

(3 rows)

#start one by one 
> docker container start cas2 
> docker exec -ti cas1 nodetool status mykeyspace2
#check 
> docker logs -f cas2 

> docker container start cas3  
> docker exec -ti cas1 nodetool status mykeyspace2

cqlsh> CONSISTENCY QUORUM;
Consistency level set to QUORUM.
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0
  
Once major shutdown is restored, it's good to do repair (also called anti-entropy repair)
where  inconsistencies are fixed with the repair process. 
Repair synchronizes the data between nodes by comparing their respective datasets for their common token ranges, 
and streaming the differences for any out of sync sections between the nodes. 
It compares the data with merkle trees, which are a hierarchy of hashes

This is must if node is started after max_hint_window_in_ms of downtime (defaults to 3 hours)

Do it in all nodes(for all keyspace it is really slow)
#so can be optimized by 
#nodetool repair [options] <keyspace_name>
#nodetool repair [options] <keyspace_name> <table1> <table2>

$ docker exec -ti cas1 nodetool repair --full
$ docker exec -ti cas2 nodetool repair --full
$ docker exec -ti cas3 nodetool repair --full



##Check trace of INSERT 
cqlsh> TRACING ON; 
cqlsh> CONSISTENCY QUORUM;

(Quorum =2 , so two MUTATION_RSP from two nodes)
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (5, 0, 0);
Tracing session: f519c230-06eb-11ec-8f20-9bdae76af347

 activity                                                                                                | timestamp                  | source     | source_elapsed | client
---------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                      Execute CQL3 query | 2021-08-27 04:05:04.083000 | 172.20.0.2 |              0 | 127.0.0.1
 Parsing INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (2, 0, 0); [Native-Transport-Requests-1] | 2021-08-27 04:05:04.084000 | 172.20.0.2 |            274 | 127.0.0.1
                                                       Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:05:04.089000 | 172.20.0.2 |           5815 | 127.0.0.1
                                         Determining replicas for mutation [Native-Transport-Requests-1] | 2021-08-27 04:05:04.098000 | 172.20.0.2 |          14771 | 127.0.0.1
        Sending MUTATION_REQ message to /172.20.0.3:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.107000 | 172.20.0.2 |          23905 | 127.0.0.1
                           MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.108000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-1] | 2021-08-27 04:05:04.109000 | 172.20.0.3 |           1457 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           1711 | 127.0.0.1
                                                Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           1973 | 127.0.0.1
        Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           2598 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-3] | 2021-08-27 04:05:04.113000 | 172.20.0.2 |          29899 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-3] | 2021-08-27 04:05:04.113000 | 172.20.0.2 |          30182 | 127.0.0.1
                           MUTATION_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.114000 | 172.20.0.2 |          31229 | 127.0.0.1
                                      Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:05:04.116000 | 172.20.0.2 |          32612 | 127.0.0.1
        Sending MUTATION_REQ message to /172.20.0.4:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.120000 | 172.20.0.2 |          36529 | 127.0.0.1
                           MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.127000 | 172.20.0.4 |             52 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-1] | 2021-08-27 04:05:04.141000 | 172.20.0.4 |          13860 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-1] | 2021-08-27 04:05:04.145000 | 172.20.0.4 |          17755 | 127.0.0.1
                                                Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:05:04.158000 | 172.20.0.4 |          30701 | 127.0.0.1
        Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.183000 | 172.20.0.4 |          56163 | 127.0.0.1
                           MUTATION_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.199000 | 172.20.0.2 |             38 | 127.0.0.1
                                      Processing response from /172.20.0.4:7000 [RequestResponseStage-2] | 2021-08-27 04:05:04.199000 | 172.20.0.2 |            795 | 127.0.0.1
                                                                                        Request complete | 2021-08-27 04:05:04.118207 | 172.20.0.2 |          35207 | 127.0.0.1
### LWT  Experimentation 
#Set both read and Write Consistency
cqlsh> CONSISTENCY QUORUM;

#Display current SERIAL CONSISTENCY status.
cqlsh> SERIAL CONSISTENCY;
Current serial consistency level is SERIAL.

#(in our case, cqlsh at datacenter1, so LOCAL_SERIAL=2)
cqlsh> SERIAL CONSISTENCY LOCAL_SERIAL

cqlsh> TRACING ON;
#Note: Trace transactions to compare the difference between INSERT statements with and without IF EXISTS.

cqlsh> USE mykeyspace2;
cqlsh> CREATE TABLE cyclist_name ( id UUID PRIMARY KEY, lastname text, firstname text );

(Quorum=2, 2 MUTATION_RSP from 2 nodes)
cqlsh:mykeyspace2> INSERT INTO cyclist_name (id, lastname, firstname) VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne');

Tracing session: be824660-06ec-11ec-8f20-9bdae76af347

                                                                                                      activity                                             | timestamp                  | source     | source_elapsed | client
-----------------------------------------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                                                        Execute CQL3 query | 2021-08-27 04:10:41.990000 | 172.20.0.2 |              0 | 127.0.0.1
 Parsing INSERT INTO cyclist_name (id, lastname, firstname) VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'); [Native-Transport-Requests-1] | 2021-08-27 04:10:41.991000 | 172.20.0.2 |            456 | 127.0.0.1
                                                                                                         Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:10:41.992000 | 172.20.0.2 |           1857 | 127.0.0.1
                                                                                           Determining replicas for mutation [Native-Transport-Requests-1] | 2021-08-27 04:10:42.007000 | 172.20.0.2 |          16810 | 127.0.0.1
                                                         Sending MUTATION_REQ message to /172.20.0.3:7000 message size 117 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.011000 | 172.20.0.2 |          20472 | 127.0.0.1
                                                                             MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.012000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-1] | 2021-08-27 04:10:42.012000 | 172.20.0.3 |            852 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-3] | 2021-08-27 04:10:42.015000 | 172.20.0.2 |          24415 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-3] | 2021-08-27 04:10:42.015000 | 172.20.0.2 |          24793 | 127.0.0.1
                                                         Sending MUTATION_REQ message to /172.20.0.4:7000 message size 117 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.031000 | 172.20.0.2 |          40751 | 127.0.0.1
                                                                             MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.037000 | 172.20.0.4 |             31 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-2] | 2021-08-27 04:10:42.044000 | 172.20.0.4 |           7089 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-2] | 2021-08-27 04:10:42.050000 | 172.20.0.4 |          12715 | 127.0.0.1
                                                                                                  Enqueuing response to /172.20.0.2:7000 [MutationStage-2] | 2021-08-27 04:10:42.060000 | 172.20.0.4 |          23230 | 127.0.0.1
                                                          Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.066000 | 172.20.0.4 |          29222 | 127.0.0.1
                                                                             MUTATION_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.067000 | 172.20.0.2 |          76777 | 127.0.0.1
                                                                                        Processing response from /172.20.0.4:7000 [RequestResponseStage-3] | 2021-08-27 04:10:42.068000 | 172.20.0.2 |          77946 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-1] | 2021-08-27 04:10:42.088000 | 172.20.0.3 |          76858 | 127.0.0.1
                                                                                                  Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:10:42.092000 | 172.20.0.3 |          80025 | 127.0.0.1
                                                          Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.092000 | 172.20.0.3 |          80402 | 127.0.0.1
                                                                             MUTATION_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.093000 | 172.20.0.2 |             26 | 127.0.0.1
                                                                                        Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:10:42.101000 | 172.20.0.2 |           6266 | 127.0.0.1
      
                                                                                                                                    Request complete | 2021-08-27 04:10:42.068286 | 172.20.0.2 |          78286 | 127.0.0.1

#Again Insert, basically it updates the same records which does not use LightWeight Transaction (ie not serialized)
cqlsh> INSERT INTO cyclist_name (id, lastname, firstname) VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne2');


#Example - this is not applied as id exists 
cqlsh> INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname )  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','MarianneNN')    IF NOT EXISTS ;

[applied] | id                                   | firstname | lastname
----------+--------------------------------------+-----------+----------
    False | 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 | Marianne2 |      VOS
     
Tracing session: 2166efa0-06ee-11ec-8f20-9bdae76af347

                                 Execute CQL3 query | 2021-08-27 04:20:37.402000 | 172.20.0.2 |              0 | 127.0.0.1
                                                                                       Parsing INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname )  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2,'Alex','FRAME' )    IF NOT EXISTS ; [Native-Transport-Requests-1] | 2021-08-27 04:20:37.402000 | 172.20.0.2 |            302 | 127.0.0.1
  Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:20:37.403000 | 172.20.0.2 |            773 | 127.0.0.1
                                                                                     Preparing 21743610-06ee-11ec-fa49-0cde6050197b [Native-Transport-Requests-1] | 2021-08-27 04:20:37.489000 | 172.20.0.2 |          87498 | 127.0.0.1
                                                            Sending PAXOS_PREPARE_REQ message to /172.20.0.3:7000 message size 84 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.508000 | 172.20.0.2 |         106058 | 127.0.0.1
                                                                               PAXOS_PREPARE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.511000 | 172.20.0.3 |             26 | 127.0.0.1
                                                                             Parsing SELECT * FROM system.paxos WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.519000 | 172.20.0.3 |           8863 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.522000 | 172.20.0.3 |          11321 | 127.0.0.1
                                                                             Parsing SELECT * FROM system.paxos WHERE row_key = ? AND cf_id = ? [MutationStage-2] | 2021-08-27 04:20:37.528000 | 172.20.0.2 |         125573 | 127.0.0.1
              Preparing statement [MutationStage-2] | 2021-08-27 04:20:37.535000 | 172.20.0.2 |         133367 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-1] | 2021-08-27 04:20:37.545000 | 172.20.0.3 |          34410 | 127.0.0.1
     Acquiring sstable references [MutationStage-1] | 2021-08-27 04:20:37.545000 | 172.20.0.3 |          34605 | 127.0.0.1
        Merging memtable contents [MutationStage-1] | 2021-08-27 04:20:37.555000 | 172.20.0.3 |          44299 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-2] | 2021-08-27 04:20:37.558000 | 172.20.0.2 |         155650 | 127.0.0.1
                                                                                                         Read 0 live rows and 0 tombstone cells [MutationStage-1] | 2021-08-27 04:20:37.560000 | 172.20.0.3 |          49156 | 127.0.0.1
                                                                                          Promising ballot 21743610-06ee-11ec-fa49-0cde6050197b [MutationStage-1] | 2021-08-27 04:20:37.560000 | 172.20.0.3 |          49498 | 127.0.0.1
                             Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET in_progress_ballot =? WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.566000 | 172.20.0.3 |          55801 | 127.0.0.1
     Acquiring sstable references [MutationStage-2] | 2021-08-27 04:20:37.567000 | 172.20.0.2 |         165038 | 127.0.0.1
        Merging memtable contents [MutationStage-2] | 2021-08-27 04:20:37.579000 | 172.20.0.2 |         177081 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.593000 | 172.20.0.3 |          82844 | 127.0.0.1
                                                                                                         Read 0 live rows and 0 tombstone cells [MutationStage-2] | 2021-08-27 04:20:37.597000 | 172.20.0.2 |         194894 | 127.0.0.1
                                                                                          Promising ballot 21743610-06ee-11ec-fa49-0cde6050197b [MutationStage-2] | 2021-08-27 04:20:37.603000 | 172.20.0.2 |         201125 | 127.0.0.1
                             Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET in_progress_ballot =? WHERE row_key = ? AND cf_id = ? [MutationStage-2] | 2021-08-27 04:20:37.615000 | 172.20.0.2 |         212657 | 127.0.0.1
           Appending to commitlog [MutationStage-1] | 2021-08-27 04:20:37.627000 | 172.20.0.3 |         116754 | 127.0.0.1
              Preparing statement [MutationStage-2] | 2021-08-27 04:20:37.634000 | 172.20.0.2 |         232491 | 127.0.0.1
         Adding to paxos memtable [MutationStage-1] | 2021-08-27 04:20:37.641000 | 172.20.0.3 |         129944 | 127.0.0.1
           Appending to commitlog [MutationStage-2] | 2021-08-27 04:20:37.652000 | 172.20.0.2 |         240753 | 127.0.0.1
         Adding to paxos memtable [MutationStage-2] | 2021-08-27 04:20:37.663000 | 172.20.0.2 |         260895 | 127.0.0.1
                                                           Sending PAXOS_PREPARE_RSP message to /172.20.0.2:7000 message size 135 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.675000 | 172.20.0.3 |         164082 | 127.0.0.1
                                                                               PAXOS_PREPARE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.684000 | 172.20.0.2 |         279269 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 04:20:37.694000 | 172.20.0.2 |         292515 | 127.0.0.1
                                                                                       Reading existing values for CAS precondition [Native-Transport-Requests-1] | 2021-08-27 04:20:37.712000 | 172.20.0.2 |         309900 | 127.0.0.1
                                                                                               reading digestfrom /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 04:20:37.720000 | 172.20.0.2 |         318229 | 127.0.0.1
                                                                                                   Executing single-partition query on cyclist_name [ReadStage-4] | 2021-08-27 04:20:37.722000 | 172.20.0.2 |         319996 | 127.0.0.1
         Acquiring sstable references [ReadStage-4] | 2021-08-27 04:20:37.722000 | 172.20.0.2 |         320208 | 127.0.0.1
            Merging memtable contents [ReadStage-4] | 2021-08-27 04:20:37.723000 | 172.20.0.2 |         320319 | 127.0.0.1
                                                                                                             Read 1 live rows and 0 tombstone cells [ReadStage-4] | 2021-08-27 04:20:37.726000 | 172.20.0.2 |         323734 | 127.0.0.1
                                                                    Sending READ_REQ message to /172.20.0.3:7000 message size 112 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.735000 | 172.20.0.2 |         332592 | 127.0.0.1
                                                                                        READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.738000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                                                   Executing single-partition query on cyclist_name [ReadStage-2] | 2021-08-27 04:20:37.740000 | 172.20.0.3 |           2299 | 127.0.0.1
         Acquiring sstable references [ReadStage-2] | 2021-08-27 04:20:37.740000 | 172.20.0.3 |           2503 | 127.0.0.1
            Merging memtable contents [ReadStage-2] | 2021-08-27 04:20:37.746000 | 172.20.0.3 |           8686 | 127.0.0.1
                                                                                                             Read 1 live rows and 0 tombstone cells [ReadStage-2] | 2021-08-27 04:20:37.747000 | 172.20.0.3 |           9350 | 127.0.0.1
                                                                                                             Enqueuing response to /172.20.0.2:7000 [ReadStage-2] | 2021-08-27 04:20:37.747000 | 172.20.0.3 |           9518 | 127.0.0.1
                                                                     Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.753000 | 172.20.0.3 |          14802 | 127.0.0.1
                                                                                        READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.756000 | 172.20.0.2 |         353796 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:20:37.756000 | 172.20.0.2 |         354288 | 127.0.0.1
 CAS precondition does not match current values [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | [firstname lastname]]\n    Row[info=[ts=1630037836498584] ]: EMPTY | [firstname=Marianne ts=1630037836498584], [lastname=VOS ts=1630037836498584] [Native-Transport-Requests-1] | 2021-08-27 04:20:37.775000 | 172.20.0.2 |         373234 | 127.0.0.1
                               CAS precondition is met; proposing client-requested updates for 21743610-06ee-11ec-fa49-0cde6050197b [Native-Transport-Requests-1] | 2021-08-27 04:20:37.826000 | 172.20.0.2 |         424163 | 127.0.0.1
                                                            Sending PAXOS_PROPOSE_REQ message to /172.20.0.3:7000 message size 84 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.842000 | 172.20.0.2 |         440044 | 127.0.0.1
                                                                               PAXOS_PROPOSE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.844000 | 172.20.0.3 |             26 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-1] | 2021-08-27 04:20:37.846000 | 172.20.0.3 |           1897 | 127.0.0.1
     Acquiring sstable references [MutationStage-1] | 2021-08-27 04:20:37.856000 | 172.20.0.3 |          11778 | 127.0.0.1
        Merging memtable contents [MutationStage-1] | 2021-08-27 04:20:37.856000 | 172.20.0.3 |          11993 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-3] | 2021-08-27 04:20:37.874000 | 172.20.0.2 |         472304 | 127.0.0.1
     Acquiring sstable references [MutationStage-3] | 2021-08-27 04:20:37.876000 | 172.20.0.2 |         474138 | 127.0.0.1
        Merging memtable contents [MutationStage-3] | 2021-08-27 04:20:37.876000 | 172.20.0.2 |         474312 | 127.0.0.1
                                                                                                         Read1 live rows and 0 tombstone cells [MutationStage-1] | 2021-08-27 04:20:37.877000 | 172.20.0.3 |          32378 | 127.0.0.1
                                                                                                         Read1 live rows and 0 tombstone cells [MutationStage-3] | 2021-08-27 04:20:37.879000 | 172.20.0.2 |         477372 | 127.0.0.1
                           Accepting proposal Commit(21743610-06ee-11ec-fa49-0cde6050197b, [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | []]) [MutationStage-3] | 2021-08-27 04:20:37.882000 | 172.20.0.2 |         480113 | 127.0.0.1
                                                                                                          Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET proposal_ballot = ?, proposal = ?, proposal_version =? WHERE row_key = ? AND cf_id = ? [MutationStage-3] | 2021-08-27 04:20:37.882000 | 172.20.0.2 |         480384 | 127.0.0.1
                           Accepting proposal Commit(21743610-06ee-11ec-fa49-0cde6050197b, [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | []]) [MutationStage-1] | 2021-08-27 04:20:37.895000 | 172.20.0.3 |          50348 | 127.0.0.1
              Preparing statement [MutationStage-3] | 2021-08-27 04:20:37.900000 | 172.20.0.2 |         497908 | 127.0.0.1
                                                                                                          Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET proposal_ballot = ?, proposal = ?, proposal_version =? WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.902000 | 172.20.0.3 |          57937 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.921000 | 172.20.0.3 |          76364 | 127.0.0.1
           Appending to commitlog [MutationStage-3] | 2021-08-27 04:20:37.928000 | 172.20.0.2 |         526347 | 127.0.0.1
           Appending to commitlog [MutationStage-1] | 2021-08-27 04:20:37.933000 | 172.20.0.3 |          89053 | 127.0.0.1
         Adding to paxos memtable [MutationStage-3] | 2021-08-27 04:20:37.945000 | 172.20.0.2 |         532473 | 127.0.0.1
         Adding to paxos memtable [MutationStage-1] | 2021-08-27 04:20:37.949000 | 172.20.0.3 |         104962 | 127.0.0.1
                                                            Sending PAXOS_PROPOSE_RSP message to /172.20.0.2:7000 message size 35 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.972000 | 172.20.0.3 |         127380 | 127.0.0.1
                                                                               PAXOS_PROPOSE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.980000 | 172.20.0.2 |         577782 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 04:20:37.991000 | 172.20.0.2 |         589068 | 127.0.0.1
    CAS did not apply [Native-Transport-Requests-1] | 2021-08-27 04:20:37.991000 | 172.20.0.2 |         589386 | 127.0.0.1
                                   Request complete | 2021-08-27 04:20:38.000018 | 172.20.0.2 |         598018 | 127.0.0.1


#Set level to serial for read requests: (note in this mode, write can not happen)
#
cqlsh> CONSISTENCY SERIAL

Consistency level set to SERIAL.

(Now READ request is different than normal)
cqlsh> SELECT * FROM mykeyspace2.cyclist_name ;


 id                                   | firstname | lastname
--------------------------------------+-----------+----------
 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 |  Marianne2 |      VOS

(1 rows)

Tracing session: 9658dfc0-06ef-11ec-8f20-9bdae76af347

                                                                                                      activity              | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                         Execute CQL3 query | 2021-08-27 04:31:03.100000 | 172.20.0.2 |              0 | 127.0.0.1
                                             Parsing SELECT * FROM mykeyspace2.cyclist_name ; [Native-Transport-Requests-1] | 2021-08-27 04:31:03.101000 | 172.20.0.2 |            550 | 127.0.0.1
                                                                          Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:31:03.101000 | 172.20.0.2 |            778 | 127.0.0.1
                                                                    Computing ranges to query [Native-Transport-Requests-1] | 2021-08-27 04:31:03.110000 | 172.20.0.2 |           9558 | 127.0.0.1
 Submitting range requests on 49 ranges with a concurrency of 1 (0.0 rows per range expected) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.114000 | 172.20.0.2 |          14307 | 127.0.0.1
       Enqueuing request to Full(/172.20.0.2:7000,(8900047540065365356,-9055191330884728872]) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.131000 | 172.20.0.2 |          30808 | 127.0.0.1
                             Sending RANGE_REQ message to /172.20.0.2:7000 message size 119 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.133000 | 172.20.0.2 |          33144 | 127.0.0.1
                                                 RANGE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.136000 | 172.20.0.2 |          36209 | 127.0.0.1
              Executing seq scan across 0 sstables for (min(-9223372036854775808), min(-9223372036854775808)][ReadStage-2]  | 2021-08-27 04:31:03.138000 | 172.20.0.2 |          37292 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 04:31:03.139000 | 172.20.0.2 |          38986 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-2]  | 2021-08-27 04:31:03.139000 | 172.20.0.2 |          39111 | 127.0.0.1
                              Sending RANGE_RSP message to /172.20.0.2:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.144000 | 172.20.0.2 |          44101 | 127.0.0.1
                                                 RANGE_RSP message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.148000 | 172.20.0.2 |          47368 | 127.0.0.1
                                                         Processing response from /172.20.0.2:7000 [RequestResponseStage-4] | 2021-08-27 04:31:03.149000 | 172.20.0.2 |          49010 | 127.0.0.1
       Enqueuing request to Full(/172.20.0.3:7000,(8900047540065365356,-9055191330884728872]) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.150000 | 172.20.0.2 |          49751 | 127.0.0.1
                                                        Submitted 1 concurrent range requests [Native-Transport-Requests-1] | 2021-08-27 04:31:03.150000 | 172.20.0.2 |          49937 | 127.0.0.1
                             Sending RANGE_REQ message to /172.20.0.3:7000 message size 119 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.151000 | 172.20.0.2 |          50807 | 127.0.0.1
                                                 RANGE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.154000 | 172.20.0.3 |             30 | 127.0.0.1
              Executing seq scan across 0 sstables for (min(-9223372036854775808), min(-9223372036854775808)][ReadStage-2]  | 2021-08-27 04:31:03.160000 | 172.20.0.3 |           6490 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 04:31:03.172000 | 172.20.0.3 |          18181 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-2]  | 2021-08-27 04:31:03.174000 | 172.20.0.3 |          20205 | 127.0.0.1
                              Sending RANGE_RSP message to /172.20.0.2:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.182000 | 172.20.0.3 |          27758 | 127.0.0.1
                                                 RANGE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.183000 | 172.20.0.2 |          82993 | 127.0.0.1
                                                         Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 04:31:03.185000 | 172.20.0.2 |          85152 | 127.0.0.1
                                                                                                           Request complete | 2021-08-27 04:31:03.188708 | 172.20.0.2 |          88708 | 127.0.0.1


#Inserts with CONSISTENCY SERIAL fail:

cqlsh> INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname ) 
   VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2,'Alex','FRAME' ) 
   IF NOT EXISTS ;

InvalidRequest: Error from server: code=2200 [Invalid query] message=
"SERIAL is not supported as conditional update commit consistency. Use ANY if you mean 
'make sure it is accepted but I donot care how many replicas commit it for non-SERIAL reads'"


Updates with CONSISTENCY SERIAL also fail:

cqlsh>  UPDATE mykeyspace2.cyclist_name SET 
    firstname = 'ALEX'
WHERE 
   id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 
IF EXISTS ;

InvalidRequest: Error from server: code=2200 [Invalid query] message="SERIAL is not supported as conditional update commit consistency. Use ANY if you mean "make sure it is accepted but I don't care how many replicas commit it for non-SERIAL reads""

#Reset to Quoram 
cqlsh> CONSISTENCY QUORUM;

cqlsh> UPDATE mykeyspace2.cyclist_name SET firstname = 'ALEX' WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2  
        IF EXISTS ;

 [applied]
-----------
      True



###Tombstones- Examples 
A tombstone is created when data is deleted. It's a marker which says that to delete after grace period

The following list of examples is not exhaustive, but illustrates some operations that generate tombstones:
    Using a CQL DELETE statement
    Expiring data with time-to-live (TTL)
    Using internal operations, such as Using materialized views
    INSERT or UPDATE operations with a null value
    UPDATE operations with a collection column

When a tombstone is created, it can be marked on different parts of a partition. 

Based on the location of the marker, tombstones can be categorized into one of the following groups. 
Each category typically corresponds to one unique type of data deletion operation.
    Partition tombstones
    Row tombstones
    Range tombstones
    ComplexColumn tombstones
    Cell tombstones
    TTL tombstones

The tombstones go through the write path, and are written to SSTables on one or more nodes. 

A key differentiator of a tombstone is a built-in expiration known as the grace period, 
set by gc_grace_seconds.(default=10day)

At the end of its expiration period, the tombstone is deleted as part of the normal compaction process.
https://docs.datastax.com/en/dse/5.1/cql/cql/cql_reference/cql_commands/cqlCreateTable.html#cqlTableProperties__Gc_grace_seconds

Note Compaction in Cassandra happens automatically, but the frequency of it depends on the selected compaction strategy 
https://docs.datastax.com/en/dse/5.1/dse-arch/datastax_enterprise/dbInternals/dbIntHowDataMaintain.html#dbIntHowDataMaintain__dml-compaction
(default is size tiered compaction, where you need to have at least 4 SSTable files of similar size to trigger the compaction).
Manual compaction is also supported via 'nodetool compact' 

Having an excessive number of tombstones in a table can negatively impact application performance. 
Many tombstones often indicate potential issues with either the data model or in the application.

> USE mykeyspace2;

> CREATE TABLE rank_by_year_and_name (
    race_year int,
    race_name text,
    rank int,
    cyclist_name text,
    PRIMARY KEY ((race_year, race_name), rank)
) WITH CLUSTERING ORDER BY (rank ASC);

> INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Benjamin PRADES', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Adam PHELAN', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Thomas LEBAS', 3);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Ilnur ZAKARIN', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Carlos BETANCUR', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Phillippe GILBERT', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Daniel MARTIN', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Johan Esteban CHAVES', 3);


##Flushing to SSTables
After each modification to a table, run the nodetool flush command on the keyspace 
to flush data from the memtable to the SSTables on disk. 

This step is necessary before running sstabledump to view the output.

> docker exec -ti cas1  nodetool flush mykeyspace2

After flushing the keyspace, run the sstabledump command on the SSTable, 
as shown in the following example.

> docker exec -it cas1 bash
$ ls /var/lib/cassandra/data/mykeyspace2/

$ cd /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

Note:For prior versions, use the sstable2json utility instead.
$ /opt/cassandra/tools/bin/sstabledump nb-1-big-Data.db
[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 43,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.185951Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Phillippe GILBERT" }
        ]
      },
      {
        "type" : "row",
        "position" : 73,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.212981Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Daniel MARTIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 99,
        "clustering" : [ 3 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.238272Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Johan Esteban CHAVES" }
        ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 133
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 197,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.102561Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Ilnur ZAKARIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 223,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.139937Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Carlos BETANCUR" }
        ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Tour of Japan - Stage 4 - Minami > Shinshu" ],
      "position" : 252
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 318,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:35.985026Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Benjamin PRADES" }
        ]
      },
      {
        "type" : "row",
        "position" : 344,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.027970Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Adam PHELAN" }
        ]
      },
      {
        "type" : "row",
        "position" : 368,
        "clustering" : [ 3 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.059791Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Thomas LEBAS" }
        ]
      }
    ]
  }

##Partition tombstones
Partition tombstones are generated when an entire partition is deleted explicitly. 
In the CQL DELETE statement, the WHERE clause is an equality condition against the partition key.
SELECT * from rank_by_year_and_name;

> DELETE from rank_by_year_and_name WHERE  race_year = 2014 AND race_name = '4th Tour of Beijing';

Check where this data exists 
$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 rank_by_year_and_name 2014

Flush memtables to sstable 
> docker exec -ti cas1  nodetool flush mykeyspace2


> docker exec -it cas1 bash

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

$ cd /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta is present in new file)
$ /opt/cassandra/tools/bin/sstabledump nb-2-big-Data.db
[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0,
      "deletion_info" : { "marked_deleted" : "2021-08-27T07:24:11.267271Z", "local_delete_time" : "2021-08-27T07:24:11Z" }
    },
    "rows" : [ ]
  }
]

##Row tombstones
Row tombstones are generated when a particular row within a partition is deleted explicitly. 

The schema has a composite primary key that includes both the partition key and the clustering key. 
In the CQL DELETE statement, the WHERE clause is an equality condition against 
both the partition key and the clustering key columns.

> DELETE from rank_by_year_and_name WHERE 
 race_year = 2015 AND race_name = 'Giro d''Italia - Stage 11 - Forli > Imola' AND rank = 2;

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta is present in new file)
$ /opt/cassandra/tools/bin/sstabledump nb-3-big-Data.db

Looking at the sstabledump output for this partition, the deletion_info tombstone marker is at the row level, 
[
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 2 ],
        "deletion_info" : { "marked_deleted" : "2021-08-27T07:40:30.976479Z", "local_delete_time" : "2021-08-27T07:40:30Z" },
        "cells" : [ ]
      }
    ]
  }
]


##Range tombstones
Range tombstones occur when several rows within a partition that can be expressed 
through a range search are deleted explicitly. 

The schema has a composite primary key that includes both a partition key and a clustering key. 

In the CQL DELETE statement, the WHERE clause is an equality condition against the partition key, 
plus an inequality condition against the clustering key.

> DELETE from rank_by_year_and_name WHERE 
 race_year = 2015 AND race_name = 'Tour of Japan - Stage 4 - Minami > Shinshu' AND rank >= 2;

Looking at the sstabledump output for this partition, 
the deletion_info tombstone marker is at the row level. 

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta or full merged file is present in new file)
$ /opt/cassandra/tools/bin/sstabledump nb-5-big-Data.db

A special boundary marker, range_tombstone_bound, marks the range scope 
(identified by the clustering key values) of the deleted rows.

[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0,
      "deletion_info" : { "marked_deleted" : "2021-08-27T07:24:11.267271Z", "local_delete_time" : "2021-08-27T07:24:11Z" }
    },
    "rows" : [ ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 44
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 108,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.102561Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Ilnur ZAKARIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 134,
        "clustering" : [ 2 ],
        "deletion_info" : { "marked_deleted" : "2021-08-27T07:40:30.976479Z", "local_delete_time" : "2021-08-27T07:40:30Z" },
        "cells" : [ ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Tour of Japan - Stage 4 - Minami > Shinshu" ],
      "position" : 151
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 217,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:35.985026Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Benjamin PRADES" }
        ]
      },
      {
        "type" : "range_tombstone_bound",
        "start" : {
          "type" : "inclusive",
          "clustering" : [ 2 ],
          "deletion_info" : { "marked_deleted" : "2021-08-27T07:43:16.391518Z", "local_delete_time" : "2021-08-27T07:43:16Z" }
        }
      },
      {
        "type" : "range_tombstone_bound",
        "end" : {
          "type" : "inclusive",
          "deletion_info" : { "marked_deleted" : "2021-08-27T07:43:16.391518Z", "local_delete_time" : "2021-08-27T07:43:16Z" }
        }
      }
    ]
  }
]

##ComplexColumn tombstones
ComplexColumn tombstones are generated when inserting or updating a collection type column, 
such as set, list, and map.

> CREATE TABLE cyclist_career_teams (
    id UUID PRIMARY KEY,
    lastname text,
    teams set<text>
);

> INSERT INTO cyclist_career_teams (
     id,
     lastname,
     teams)
     VALUES (cb07baad-eac8-4f65-b28a-bddc06a0de23, 'ARMITSTEAD', { 
     'Boels-Dolmans Cycling Team','AA Drink - Leontien.nl','Team Garmin - Cervelo' } );

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347

$ cd /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347

$ /opt/cassandra/tools/bin/sstabledump nb-1-big-Data.db

Looking at the sstabledump output for this partition, no explicit manual deletion occurs on the partition, 
but a deletion_info marker is listed at the cell level for the collection type column teams.

[
  {
    "partition" : {
      "key" : [ "cb07baad-eac8-4f65-b28a-bddc06a0de23" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 30,
        "liveness_info" : { "tstamp" : "2021-08-27T07:46:31.849728Z" },
        "cells" : [
          { "name" : "lastname", "value" : "ARMITSTEAD" },
          { "name" : "teams", "deletion_info" : { "marked_deleted" : "2021-08-27T07:46:31.849727Z", "local_delete_time" : "2021-08-27T07:46:31Z" } },
          { "name" : "teams", "path" : [ "AA Drink - Leontien.nl" ], "value" : "" },
          { "name" : "teams", "path" : [ "Boels-Dolmans Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Team Garmin - Cervelo" ], "value" : "" }
        ]
      }
    ]
  }
]

##Cell tombstones
Cell tombstones are generated when explicitly deleting a value from a cell, 
such as a column for a specific row of a partition, 
or when inserting or updating a cell with NULL values, 

> INSERT INTO rank_by_year_and_name (
     race_year,
     race_name,
     cyclist_name,
     rank)
     VALUES (2018, 'Giro d''Italia - Stage 11 - Osimo > Imola', null, 1);

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ cd ../rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-6-big-Data.db

Looking at the "sstabledump" output for this partition, deletion_info tombstone marker is associated 
with a particular cell.
[
  {
    "partition" : {
      "key" : [ "2018", "Giro d'Italia - Stage 11 - Osimo > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T07:58:05.949672Z" },
        "cells" : [
          { "name" : "cyclist_name", "deletion_info" : { "local_delete_time" : "2021-08-27T07:58:05Z" }
          }
        ]
      }
    ]
  }
]

##TTL tombstones
TTL tombstones are generated when the TTL (time-to-live) period expires. 
The TTL expiration marker can occur at either the row or cell level. 

The following statement sets TTL for an entire row.

> INSERT INTO cyclist_career_teams (
     id,
     lastname,
     teams)
     VALUES (e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN', { 
     'Rabobank-Liv Woman Cycling Team','Sengers Ladies Cycling Team','Team Flexpoint' }) USING TTL 10;
     
contains two rows 
> select * from cyclist_career_teams; 

After 10 sec, contains one row 
> select * from cyclist_career_teams;

The following statement sets TTL for a single cell.

> UPDATE rank_by_year_and_name USING TTL 10
  SET cyclist_name = 'Cloudy Archipelago' WHERE race_year = 2018 AND 
  race_name = 'Giro d''Italia - Stage 11 - Osimo > Imola' AND rank = 1;


After 10 sec, cyclist_name would become null 
> select * from cyclist_career_teams;

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347
$ cd ../cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-2-big-Data.db

the first CQL statement marks the row (partition key: e7cd5752-bc0d-4157-a80f-7523add8dbcd) 
with an "expired" : true TTL expiration marker in the liveness_info section.
[
  {
    "partition" : {
      "key" : [ "e7cd5752-bc0d-4157-a80f-7523add8dbcd" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 30,
        "liveness_info" : { "tstamp" : "2021-08-27T08:25:12.513792Z", "ttl" : 10, "expires_at" : "2021-08-27T08:25:13Z", "expired" : true },
        "cells" : [
          { "name" : "lastname", "value" : "VAN DER BREGGEN" },
          { "name" : "teams", "deletion_info" : { "marked_deleted" : "2021-08-27T08:25:12.513791Z", "local_delete_time" : "2021-08-27T08:25:12Z" } },
          { "name" : "teams", "path" : [ "Rabobank-Liv Woman Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Sengers Ladies Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Team Flexpoint" ], "value" : "" }
        ]
      }
    ]
  }
]
  
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ cd ../rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-7-big-Data.db

The second CQL statement marks the cell (partition key: 2018, clustering key: 1, 
column name: cyclist_name) with an "expired" : true TTL expiration marker for the specific cell.
[
  {
    "partition" : {
      "key" : [ "2018", "Giro d'Italia - Stage 11 - Osimo > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 1 ],
        "cells" : [
          { "name" : "cyclist_name", "value" : "Cloudy Archipelago", "tstamp" : "2021-08-27T08:25:19.336242Z", "ttl" : 10, "expires_at" : "2021-08-27T08:25:20Z", "expired" : true }
        ]
      }
    ]
  }
  
