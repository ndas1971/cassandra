###Developer metrics 
### Creating Docker cluster (delete old cluster at first)
###Consistency Experimentation in cluster 
2nd hour 
### LWT  Experimentation 
###Tombstones- Examples 
3rd hour 
    ### Java API Quick intro only 
    Might  ### SNAPSHOT -- ADVANCED 
    NO ###Incremental Backups -- ADVANCED  
    Might  ###Bulk loading  and Restoring from Incremental Backups and Snapshots  -- ADVANCED 
    ###Cassandra Performance Metrics using nodetool
    No ###Cassandra Performance Metrics using JConsole - ADVANCED,  
    Ony go through ###Cassandra Performance Tuning - Main Points  
    Go through all PPT eg administration 
-----------------------------------------
###Developer metrics 

#Throughput - key matrics            
Reads 	Read requests per second 	
Writes 	Write requests per second 	

#Latency - key matrics                         
Write latency 	Write response time, in microseconds 	
Read latency 	Read response time, in microseconds 	

#Disk usage - key matrics                         
Load 	                Disk space used on a node, in bytes 	
Total disk space used 	Disk space used by a column family, in bytes


##nodetool tablestats(old name: cfstats) 
provides statistics on each keyspace and tables
including READ LATENCY, WRITE LATENCY, AND TOTAL DISK SPACE USED. 

Include 'keyspace table' at the end else for all keyspaces and tables 
$ docker exec -it cass_cluster nodetool tablestats cycling

Keyspace: cycling
    Read Count: 4
    Read Latency: 1.386 ms.
    Write Count: 4
    Write Latency: 0.71675 ms.
    Pending Flushes: 0
        Table: users
        SSTable count: 3
        Space used (live), bytes: 16178
        Space used (total), bytes: 16261
        ...
        Local read count: 4
        Local read latency: 1.153 ms
        Local write count: 4
        Local write latency: 0.224 ms
        Pending flushes: 0
        
##Local Query Latency - nodetool tablehistograms (old name:cfhistograms)
To get a better idea of what is happening locally on a node, it shows 
    Read/Write Latency
    Partition Size
    Column Count
    Number of SSTable

Include  'keyspace tablename' at the end  else for all keyspaces and tables 
$ docker exec -ti cass_cluster nodetool tablehistograms   cycling
Percentile  SSTables     Write Latency      Read Latency    Partition Size        Cell Count
                              (micros)          (micros)           (bytes)
50%             0.00             73.46            182.79             17084               103
75%             1.00             88.15            315.85             17084               103
95%             2.00            126.93            545.79             17084               103
98%             2.00            152.32            654.95             17084               103
99%             2.00            182.79            785.94             17084               103
Min             0.00             42.51             24.60             14238                87
Max             2.00          12108.97          17436.92             17084               103

SSTables columns 
    how many sstables were read per logical read. 
    very High number - bad - wrong compaction strategy, 
    SizeTieredCompactionStrategy , used for generally write intensive workloads 
    so typically has many more reads per read 
    High number means Data supports LeveledCompactionStrategy 
    
Write Latency Column 
    latency breakdown of local write latency. 
    Theoratically, all should  converge to p50 (medium value)
    p50 is quite good at 73 microseconds, 
    Max is quite slow at 12 milliseconds- indicates 
    large writes occasionally-quickly saturating commitlog segments.
    
Read Latency Column 
    latency breakdown of local read latency. 
    Cassandra reads are (as expected) slower than local writes, 
    and the read speed correlates highly with the number of sstables read per read.
    
Partition Size and Cell Count
    Useful for determining if the table has on average skinny or wide partitions 
    and can help you isolate bad data patterns. 
    For example if you have a single cell that is 2 megabytes, 
    that is probably going to cause some heap pressure when it’s read

### Creating Docker cluster (delete old cluster at first)
> docker image ls
#Create a network 
#Singel host - bridge, multiple host docker-overlay , check https://docs.docker.com/engine/reference/commandline/network_create/
> docker network rm CassandraNetwork
> docker network create -d bridge CassandraNetwork

> docker container stop cas1 cas2 cas3
> docker container rm cas1 cas2 cas3

#-m=1g, restrict memory of container , https://docs.docker.com/config/containers/resource_constraints/
#check for env var https://hub.docker.com/_/cassandra
#eg cassandra memory can be restricted as -e MAX_HEAP_SIZE=1G -e HEAP_NEWSIZE=100M , used for setting java memory 
> docker run --name cas1  -m=1g --network CassandraNetwork -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter1 -e CASSANDRA_RACK=rack1 -d cassandra:4.0.1
> docker container ls 
> docker logs cas1

#Ensure it is UN 
$ docker exec -ti cas1 nodetool status 

> docker stats --no-stream
> docker exec -it cas1 nodetool version

#get IP - Uses GO template 
#https://docs.docker.com/engine/reference/commandline/inspect/
#https://docs.gomplate.ca/syntax/

For default network 
> docker inspect --format='{{ .NetworkSettings.IPAddress}}' cas1

for custom network 
> docker inspect --format='{{ .NetworkSettings.Networks.CassandraNetwork.IPAddress}}' cas1
MAIN_IP=$(docker inspect --format='{{ .NetworkSettings.Networks.CassandraNetwork.IPAddress}}' cas1)
eg The main ip is 172.20.0.2


#Other nodes 
> docker container rm cas2 cas3 
> docker run --name cas2 -m=1g  --network CassandraNetwork  -e CASSANDRA_SEEDS=172.20.0.2 -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter1 -e CASSANDRA_RACK=rack1 -d cassandra:4.0.1
#Ensure both are visible 
$ docker exec -ti cas1 nodetool status 

> docker run --name cas3 -m=1g  --network CassandraNetwork -e CASSANDRA_SEEDS=172.20.0.2 -e CASSANDRA_CLUSTER_NAME=MyCluster -e CASSANDRA_ENDPOINT_SNITCH=GossipingPropertyFileSnitch -e CASSANDRA_DC=datacenter2 -e CASSANDRA_RACK=rack2 -d cassandra:4.0.1

> docker container ls --all

> docker logs cas2
> docker logs cas3 

#Ensure all are UN 
$ docker exec -ti cas1 nodetool status 

#Connect to Cassandra from cqlsh
> docker exec -ti cas1 nodetool status
The status column of each node should show UN (node is UP and its state is Normal). 
If you see 'UJ' that means your node is joining, just wait for a while and check it again. 
Tokens means no of vnodes and owns does not have much meaning in cluster, see it with keyspace 

#Container shell access 
> docker exec -it cas1 bash

#Stop 
> docker stop cas3 cas2 cas1
#Start 
> docker start cas3 cas2 cas1

#Stop docker VM 
$ docker-machine stop default

#start cqlsh 
> docker exec -ti cas1 cqlsh

#DC can have a different replication factor and 
#( RF in a DC must be less than no of nodes in a DC , different DC holds complete no of copies based on RF)
#All replicas are equally important; there is no primary or master replica

#RF with 1 for each DC ie 1 copy  and that copy is distributed between all nodes 
#(so each node in a DC gets some portion of data when RF < #nodes, owns = (100/#nodes) *  RF  %)
#and QUORUM is 2/2 + 1 = 2 , so no node can go down 
> CREATE KEYSPACE mykeyspace WITH replication = {'class':'NetworkTopologyStrategy','datacenter1': 1,'datacenter2': 1};

> CREATE TABLE mykeyspace.mytable (id int primary key,name text);

$ docker exec -ti cas1 nodetool status mykeyspace
Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load       Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.3  74.23 KiB  16      51.2%             f8205b13-de6b-4a9c-9c7a-ece9c4a0d27b  rack1
UN  172.20.0.2  96.61 KiB  16      48.8%             8be61111-b31b-45c9-ba59-fbac41d8eda2  rack1

Datacenter: datacenter2
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load       Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.4  91.57 KiB  16      100.0%            fe539440-58b3-4ed2-8254-8f5aeba7c289  rack1

##With RF of 2  at DC1 ie each node of DC1 gets one copy ,DC2's RF is 1 and node 1, so that gets copy 
#and QUORUM is 3/2 + 1 = 2 , so one node can go down in DC1, but no node at DC2 
> CREATE KEYSPACE mykeyspace2 WITH replication = {'class':'NetworkTopologyStrategy','datacenter1': 2,'datacenter2': 1};

> CREATE TABLE mykeyspace2.mytable (id int primary key,name text);

#now each is 100% means owns full copy of the data 
$ docker exec -ti cas1 nodetool status mykeyspace2
Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load        Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.3  91.56 KiB   16      100.0%            f8205b13-de6b-4a9c-9c7a-ece9c4a0d27b  rack1
UN  172.20.0.2  103.77 KiB  16      100.0%            8be61111-b31b-45c9-ba59-fbac41d8eda2  rack1

Datacenter: datacenter2
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address     Load        Tokens  Owns (effective)  Host ID                               Rack
UN  172.20.0.4  98.74 KiB   16      100.0%            fe539440-58b3-4ed2-8254-8f5aeba7c289  rack1

###Consistency Experimentation in cluster 
##Trace reads at different consistency levels
(windows)"C:\Program Files\Git\bin\bash.exe" --login -i "C:\Docker\start.sh"
> docker container start cas1 
> docker container start cas2 cas3 
> docker exec -ti cas1 nodetool status mykeyspace2
> docker exec -ti cas1 cqlsh

Create a table, and insert some values:

cqlsh> USE mykeyspace2;
cqlsh> CREATE TABLE IF NOT EXISTS mykeyspace2.tester ( id int PRIMARY KEY, col1 int, col2 int );
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (0, 0, 0);
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (1, 0, 0);

cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;
 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0

(2 rows)

The recommended partitioner takes your partition key values 
and then computes a 128 bit hash(default: murmur3) from them. 
The hash is called the token of the record, 
and it is that token value that determines where your record is stored. 

Each Cassandra node has a set of token ranges associated with it. 
If the token of a record falls with a range of a node, the record is 
stored on that node. 
(and then replicated based on ReplicationStrategy - for SimpleStrategy, 
next replica goes to next node in the ring,for NetworkTopologyStrategy, 
next replica goes to next Rack if available , never spans DC 
as each DC has own RF)

The number of partitions is not determined by your choice of partition key
it is the number of token ranges in your cluster. 
That is roughly equal to the total number of vnodes you selected 
when you configured 
your data store nodes(cassandra.yaml:num_tokens, here it is 16)

This is called Consistent hashing
Consistent hashing allows distribution of data across a cluster 
to minimize reorganization when nodes are added or removed. 
For example on how the the actual assignement takes place, check 
https://docs.datastax.com/en/cassandra-oss/3.0/cassandra/architecture/archDataDistributeHashing.html

Who owns this token?
(first line is the last token, vnodes are 16 so, 16 token range/node) 
each vnode displays end token from its range, 
all vnodes from both nodes in DC1 form a ring 
where end token of one vnode becomes start token of next vnode .
each DC has own ring with similar  token range . 
PartitionKey -> token/hash -> goes to all DCs

> docker exec -ti cas1 nodetool ring
Datacenter: datacenter1
==========
Address          Rack        Status State   Load            Owns                Token
                                                                                8900047540065365356
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -8892077648528157142
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -8465791147247027752
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -7768062232820599131
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -7115589320672349868
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -6672020332585660842
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -6058212803743391651
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -5580723221893448582
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -4736346574402286825
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -3936517903741156541
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -3296078344499703585
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -2678097312597503507
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -2224577728159670773
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   -1613756322824440111
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -1206726323417243757
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   -389054390804892963
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   206247978155506286
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   686701490420686575
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   1422617183131580216
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   2083312307668492315
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   2501989990579181874
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   3252267230847506694
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   3745509996259773846
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   4301391031176697782
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   4712874239338309345
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   5237304203968213202
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   5652941863539853082
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   6302878791852207983
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   6864622210211834227
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   7261945062560547018
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   7921902087549251280
172.20.0.3       rack1       Up     Normal  241.85 KiB      ?                   8520365778505990106
172.20.0.2       rack1       Up     Normal  240.62 KiB      ?                   8900047540065365356
Datacenter: datacenter2
==========
Address          Rack        Status State   Load            Owns                Token
                                                                                8320052126484789930
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -9055191330884728872
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -8037339926142301856
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -7219667993529951062
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -6143912112304371522
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -5407996419593477881
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -4328623612145876224
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -3085103606465284250
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -2117739363386748752
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   -527734810872850114
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   1091288484824193182
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   2069433937340307258
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   3848068238163894386
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   4944110138398832675
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   6035407249091044934
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   6879783896582206692
172.20.0.4       rack1       Down   Normal  242.94 KiB      ?                   8320052126484789930

There is also the nodetool describering command 
which lists the start and end tokens of the ranges for each keyspace on the nodes. 

first endpoint in endpoints is the primary host holding data, others are replica , 
In our case, DC2:RF2+DC2:RF1 = means 3 copies of the same data , 
hence endpoints are also three and last two are highers nodes 
in the node ring where replica goes 

(below lists 48 vnodes from two DC2)

> docker exec -ti cas1 nodetool describering -- mykeyspace2
Schema Version:091b8f5b-d8bb-35a0-bff5-7e7b4671589b
TokenRange:
        TokenRange(start_token:-3085103606465284250, end_token:-2678097312597503507, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-389054390804892963, end_token:206247978155506286, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:8320052126484789930, end_token:8520365778505990106, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-8465791147247027752, end_token:-8037339926142301856, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-4736346574402286825, end_token:-4328623612145876224, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2117739363386748752, end_token:-1613756322824440111, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:6864622210211834227, end_token:6879783896582206692, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4712874239338309345, end_token:4944110138398832675, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:8520365778505990106, end_token:8900047540065365356, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6143912112304371522, end_token:-6058212803743391651, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-3296078344499703585, end_token:-3085103606465284250, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:3848068238163894386, end_token:4301391031176697782, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:5652941863539853082, end_token:6035407249091044934, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:8900047540065365356, end_token:-9055191330884728872, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-527734810872850114, end_token:-389054390804892963, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:3252267230847506694, end_token:3745509996259773846, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7768062232820599131, end_token:-7219667993529951062, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6672020332585660842, end_token:-6143912112304371522, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2224577728159670773, end_token:-2117739363386748752, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:2083312307668492315, end_token:2501989990579181874, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:7261945062560547018, end_token:7921902087549251280, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:6035407249091044934, end_token:6302878791852207983, endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], rpc_endpoints:[172.20.0.2, 172.20.0.3, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-8892077648528157142, end_token:-8465791147247027752, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:206247978155506286, end_token:686701490420686575, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:3745509996259773846, end_token:3848068238163894386, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7115589320672349868, end_token:-6672020332585660842, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-1206726323417243757, end_token:-527734810872850114, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-1613756322824440111, end_token:-1206726323417243757, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:1422617183131580216, end_token:2069433937340307258, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:6302878791852207983, end_token:6864622210211834227, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4301391031176697782, end_token:4712874239338309345, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-3936517903741156541, end_token:-3296078344499703585, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-6058212803743391651, end_token:-5580723221893448582, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-5407996419593477881, end_token:-4736346574402286825, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:2501989990579181874, end_token:3252267230847506694, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:6879783896582206692, end_token:7261945062560547018, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:-5580723221893448582, end_token:-5407996419593477881, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-9055191330884728872, end_token:-8892077648528157142, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:7921902087549251280, end_token:8320052126484789930, endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], rpc_endpoints:[172.20.0.4, 172.20.0.3, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-7219667993529951062, end_token:-7115589320672349868, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:2069433937340307258, end_token:2083312307668492315, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])
        TokenRange(start_token:5237304203968213202, end_token:5652941863539853082, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:686701490420686575, end_token:1091288484824193182, endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], rpc_endpoints:[172.20.0.4, 172.20.0.2, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:1091288484824193182, end_token:1422617183131580216, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-2678097312597503507, end_token:-2224577728159670773, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-8037339926142301856, end_token:-7768062232820599131, endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], rpc_endpoints:[172.20.0.2, 172.20.0.4, 172.20.0.3], endpoint_details:[EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2,rack:rack1), EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:4944110138398832675, end_token:5237304203968213202, endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], rpc_endpoints:[172.20.0.3, 172.20.0.4, 172.20.0.2], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1, rack:rack1)])
        TokenRange(start_token:-4328623612145876224, end_token:-3936517903741156541, endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], rpc_endpoints:[172.20.0.3, 172.20.0.2, 172.20.0.4], endpoint_details:[EndpointDetails(host:172.20.0.3, datacenter:datacenter1, rack:rack1), EndpointDetails(host:172.20.0.2, datacenter:datacenter1,rack:rack1), EndpointDetails(host:172.20.0.4, datacenter:datacenter2, rack:rack1)])

#get all endponts for a partitionkey (3 as here total RFs is 2)
$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 tester 0
172.20.0.2
172.20.0.4
172.20.0.3

$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 tester 1
172.20.0.3
172.20.0.2
172.20.0.4

##Understanding - Consistency 
Turn on tracing and use the CONSISTENCY command to check 
that the consistency level is ONE, the default.

cqlsh> TRACING on;
cqlsh> CONSISTENCY;
Current consistency level is ONE.

Coordinator node (in our case where cqlsh is running)
This node is called a "coordinator node" and is typically chosen based-on 
having the least (closest) "network distance." 

Client requests can really be sent to any node, 
and at first they will be sent to the nodes which your driver knows about. 
But once it connects and understands the topology of your cluster, 
it may change to a "closer" coordinator.


cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

The output includes tracing information:

  id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: cd542ba0-06dc-11ec-8f20-9bdae76af347

 activity                                                                                     | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                           Execute CQL3 query | 2021-08-27 02:16:34.911000 | 172.20.0.2 |              0 | 127.0.0.1
         Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:16:34.960000 | 172.20.0.2 |          50694 | 127.0.0.1
                                            Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:16:34.963000 | 172.20.0.2 |          51444 | 127.0.0.1
                             reading data from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:16:34.984000 | 172.20.0.2 |          74633 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.3:7000 message size 86 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:16:34.994000 | 172.20.0.2 |          84169 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:16:34.998000 | 172.20.0.3 |            738 | 127.0.0.1
                    READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:16:35.039000 | 172.20.0.2 |         129823 | 127.0.0.1
                           Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 02:16:35.041000 | 172.20.0.2 |         131237 | 127.0.0.1
                                                                             Request complete | 2021-08-27 02:16:35.046811 | 172.20.0.2 |         135811 | 127.0.0.1

(Coordinator node  = 172.20.0.2, others are 172.20.0.3 and 172.20.0.4)
The tracing results list all the actions taken to complete the SELECT statement.
(with ONE, only one node returns READ_RSP and query returns, 
check 'source' to know which source is writing msg) 

Change the consistency level to QUORUM to trace what happens during a read 
with a QUORUM consistency level.
(in our case , it is QUORUM=2, check source, two sources return READ_RSP to cordinator
Note cordinator in general does not partcipate  )

#for both read and write 
cqlsh> CONSISTENCY quorum;
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

 id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: 265f6d90-06dd-11ec-8f20-9bdae76af347

                                                                                                      activity              | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                         Execute CQL3 query | 2021-08-27 02:19:04.297000 | 172.20.0.2 |              0 | 127.0.0.1
                                       Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:19:04.298000 | 172.20.0.2 |            663 | 127.0.0.1
                                                                          Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:19:04.307000 | 172.20.0.2 |           9495 | 127.0.0.1
                                                                   Executing single-partition query on tester[ReadStage-2]  | 2021-08-27 02:19:04.332000 | 172.20.0.2 |          34501 | 127.0.0.1
                                                                                 Acquiring sstable references[ReadStage-2]  | 2021-08-27 02:19:04.340000 | 172.20.0.2 |          42859 | 127.0.0.1
                                                                                    Merging memtable contents[ReadStage-2]  | 2021-08-27 02:19:04.341000 | 172.20.0.2 |          43130 | 127.0.0.1
                                                         reading digest from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:19:04.349000 | 172.20.0.2 |          51265 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 02:19:04.354000 | 172.20.0.2 |          46045 | 127.0.0.1
                               Sending READ_REQ message to /172.20.0.3:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.357000 | 172.20.0.2 |          55840 | 127.0.0.1
                                                  READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.363000 | 172.20.0.3 |             32 | 127.0.0.1
                                                                   Executing single-partition query on tester[ReadStage-1]  | 2021-08-27 02:19:04.366000 | 172.20.0.3 |           3494 | 127.0.0.1
                                                                                 Acquiring sstable references[ReadStage-1]  | 2021-08-27 02:19:04.367000 | 172.20.0.3 |           3819 | 127.0.0.1
                                                                                    Merging memtable contents[ReadStage-1]  | 2021-08-27 02:19:04.367000 | 172.20.0.3 |           4118 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-1]  | 2021-08-27 02:19:04.368000 | 172.20.0.3 |           4953 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-1]  | 2021-08-27 02:19:04.393000 | 172.20.0.3 |          30127 | 127.0.0.1
 speculating read retry on Full(/172.20.0.4:7000,(-3936517903741156541,-3296078344499703585]) [Native-Transport-Requests-1] | 2021-08-27 02:19:04.394000 | 172.20.0.2 |          96659 | 127.0.0.1
                               Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.395000 | 172.20.0.3 |          32145 | 127.0.0.1
                               Sending READ_REQ message to /172.20.0.4:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.400000 | 172.20.0.2 |         102204 | 127.0.0.1
                                                  READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.408000 | 172.20.0.2 |         110844 | 127.0.0.1
                                                         Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 02:19:04.413000 | 172.20.0.2 |         115296 | 127.0.0.1
                                                  READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.414000 | 172.20.0.4 |           3511 | 127.0.0.1
                                                  READ_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:19:04.531000 | 172.20.0.2 |             66 | 127.0.0.1
                                                         Processing response from /172.20.0.4:7000 [RequestResponseStage-3] | 2021-08-27 02:19:04.532000 | 172.20.0.2 |            999 | 127.0.0.1
                                                                                                           Request complete | 2021-08-27 02:19:04.418285 | 172.20.0.2 |         121285 | 127.0.0.1


Change the consistency level to ALL and run the SELECT statement again.
(In our case,  coordinator, 172.20.0.2 now participates 
"Read 1 live rows and 0 tombstone cells"
and there are processing three nodes)

#for both read and write 
cqlsh> CONSISTENCY ALL;
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 0;

 id | col1 | col2
----+------+------
  0 |    0 |    0

(1 rows)

Tracing session: aa474b10-06e1-11ec-8f20-9bdae76af347

 activity                                                                                     | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                           Execute CQL3 query | 2021-08-27 02:51:23.585000 | 172.20.0.2 |              0 | 127.0.0.1
         Parsing SELECT * FROM mykeyspace2.tester WHERE id = 0; [Native-Transport-Requests-1] | 2021-08-27 02:51:23.586000 | 172.20.0.2 |            581 | 127.0.0.1
                                            Preparing statement [Native-Transport-Requests-1] | 2021-08-27 02:51:23.586000 | 172.20.0.2 |            922 | 127.0.0.1
                           reading digest from /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 02:51:23.604000 | 172.20.0.2 |          18188 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-3] | 2021-08-27 02:51:23.605000 | 172.20.0.2 |          20045 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-3] | 2021-08-27 02:51:23.606000 | 172.20.0.2 |          20235 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-3] | 2021-08-27 02:51:23.606000 | 172.20.0.2 |          20332 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-3] | 2021-08-27 02:51:23.608000 | 172.20.0.2 |          22383 | 127.0.0.1
                           reading digest from /172.20.0.4:7000 [Native-Transport-Requests-1] | 2021-08-27 02:51:23.615000 | 172.20.0.2 |          29415 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.3:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.615000 | 172.20.0.2 |          29831 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.617000 | 172.20.0.3 |             43 | 127.0.0.1
 Sending READ_REQ message to /172.20.0.4:7000 message size 87 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.618000 | 172.20.0.2 |          33009 | 127.0.0.1
                    READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.619000 | 172.20.0.4 |             45 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |            851 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |           1056 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-1] | 2021-08-27 02:51:23.620000 | 172.20.0.4 |           1147 | 127.0.0.1
                                     Executing single-partition query on tester [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6373 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.4 |           3400 | 127.0.0.1
                                                   Acquiring sstable references [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6666 | 127.0.0.1
                                         Enqueuing response to /172.20.0.2:7000 [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.4 |           3591 | 127.0.0.1
                                                      Merging memtable contents [ReadStage-1] | 2021-08-27 02:51:23.623000 | 172.20.0.3 |           6766 | 127.0.0.1
 Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.627000 | 172.20.0.4 |           8180 | 127.0.0.1
                    READ_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.630000 | 172.20.0.2 |          44720 | 127.0.0.1
                           Processing response from /172.20.0.4:7000 [RequestResponseStage-4] | 2021-08-27 02:51:23.632000 | 172.20.0.2 |          46635 | 127.0.0.1
                                         Read 1 live rows and 0 tombstone cells [ReadStage-1] | 2021-08-27 02:51:23.634000 | 172.20.0.3 |          17309 | 127.0.0.1
                                         Enqueuing response to /172.20.0.2:7000 [ReadStage-1] | 2021-08-27 02:51:23.641000 | 172.20.0.3 |          24193 | 127.0.0.1
 Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.647000 | 172.20.0.3 |          29921 | 127.0.0.1
                    READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 02:51:23.656000 | 172.20.0.2 |          70372 | 127.0.0.1
                           Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 02:51:23.659000 | 172.20.0.2 |          73188 | 127.0.0.1
                                                                             Request complete | 2021-08-27 02:51:23.659685 | 172.20.0.2 |          74685 | 127.0.0.1                                            


#for both read and write 
cqlsh> CONSISTENCY QUORUM;

#Down one eg cas3 from DC2 
> docker container stop cas3 

$ docker exec -ti cas1 nodetool status mykeyspace2
#Datacenter2 is down 

cqlsh> TRACING OFF;

cqlsh> CONSISTENCY;
Current consistency level is QUORUM.

#Successful because Quorum is 2 from any DC 
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (3, 0, 0);
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0


#start 
> docker container start cas3 
> docker exec -ti cas1 nodetool status mykeyspace2

#Set Quorum ALL such that from all must return consistent data (eventually it would)
cqlsh> CONSISTENCY ALL;

Hinting is a data repair technique applied during write operations. 
When replica nodes are unavailable to accept a mutation, 
either due to failure or more commonly routine maintenance, 
coordinators attempting to write to those replicas store temporary hints 
on their local filesystem for replying those later to unavailable replica 
when it comes up 

New hints will be retained for up to max_hint_window_in_ms of downtime 
(defaults to 3 hours)

#All return the consistent data as either because of Hints 
#or when background read repair is done 
#if there is read inconsistencies
cqlsh> SELECT * FROM mykeyspace2.tester WHERE id = 3;

 id | col1 | col2
----+------+------
  3 |    0 |    0

(1 rows)

#Now down two and check Quorum fails 
> docker container stop cas3 cas2 

$ docker exec -ti cas1 nodetool status mykeyspace2
#Datacenter2 is down 

cqlsh> CONSISTENCY QUORUM;

#Data is NOT inserted, as Consistency check fails 
cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (4, 0, 0);
NoHostAvailable: ('Unable to complete the operation against any hosts', {<Host: 127.0.0.1:9042 datacenter1>: 
Unavailable('Error from server: code=1000 [Unavailable exception] message="Cannot achieve consistency level QUORUM" 
info={\'consistency\': \'QUORUM\', \'required_replicas\': 2, \'alive_replicas\': 1}')})

cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;
NoHostAvailable: ('Unable to complete the operation against any hosts', {<Host: 127.0.0.1:9042 datacenter1>: 
Unavailable('Error from server: code=1000 [Unavailable exception] message="Cannot achieve consistency level QUORUM" 
info={\'consistency\': \'QUORUM\', \'required_replicas\': 2, \'alive_replicas\': 1}')})

cqlsh> CONSISTENCY ONE;
Consistency level set to ONE.
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0

(3 rows)

#start one by one 
> docker container start cas2 
> docker exec -ti cas1 nodetool status mykeyspace2
#check 
> docker logs -f cas2 

> docker container start cas3  
> docker exec -ti cas1 nodetool status mykeyspace2

cqlsh> CONSISTENCY QUORUM;
Consistency level set to QUORUM.
cqlsh> SELECT token(id),id, col1, col2 FROM mykeyspace2.tester ;

 system.token(id)     | id | col1 | col2
----------------------+----+------+------
 -4069959284402364209 |  1 |    0 |    0
 -3485513579396041028 |  0 |    0 |    0
  9010454139840013625 |  3 |    0 |    0
  
Once major shutdown is restored, it's good to do manual repair 
(also called anti-entropy repair)
where  inconsistencies are fixed with the repair process. 

Repair synchronizes the data between nodes by comparing their respective datasets
for their common token ranges, and streaming the differences 
for any out of sync sections between the nodes. 
It compares the data with merkle trees, which are a hierarchy of hashes

This is must if node is started after max_hint_window_in_ms of downtime 
(defaults to 3 hours)

Do it in all nodes(for all keyspace it is really slow)
#so can be optimized by 
#nodetool repair [options] <keyspace_name>
#nodetool repair [options] <keyspace_name> <table1> <table2>

$ docker exec -ti cas1 nodetool repair --full
$ docker exec -ti cas2 nodetool repair --full
$ docker exec -ti cas3 nodetool repair --full



##Check trace of INSERT 
cqlsh> TRACING ON; 
cqlsh> CONSISTENCY QUORUM;

(Quorum =2 , so two MUTATION_RSP from two nodes)

cqlsh> INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (5, 0, 0);
Tracing session: f519c230-06eb-11ec-8f20-9bdae76af347

 activity                                                                                                | timestamp                  | source     | source_elapsed | client
---------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                      Execute CQL3 query | 2021-08-27 04:05:04.083000 | 172.20.0.2 |              0 | 127.0.0.1
 Parsing INSERT INTO mykeyspace2.tester (id, col1, col2) VALUES (2, 0, 0); [Native-Transport-Requests-1] | 2021-08-27 04:05:04.084000 | 172.20.0.2 |            274 | 127.0.0.1
                                                       Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:05:04.089000 | 172.20.0.2 |           5815 | 127.0.0.1
                                         Determining replicas for mutation [Native-Transport-Requests-1] | 2021-08-27 04:05:04.098000 | 172.20.0.2 |          14771 | 127.0.0.1
        Sending MUTATION_REQ message to /172.20.0.3:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.107000 | 172.20.0.2 |          23905 | 127.0.0.1
                           MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.108000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-1] | 2021-08-27 04:05:04.109000 | 172.20.0.3 |           1457 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           1711 | 127.0.0.1
                                                Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           1973 | 127.0.0.1
        Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.110000 | 172.20.0.3 |           2598 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-3] | 2021-08-27 04:05:04.113000 | 172.20.0.2 |          29899 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-3] | 2021-08-27 04:05:04.113000 | 172.20.0.2 |          30182 | 127.0.0.1
                           MUTATION_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.114000 | 172.20.0.2 |          31229 | 127.0.0.1
                                      Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:05:04.116000 | 172.20.0.2 |          32612 | 127.0.0.1
        Sending MUTATION_REQ message to /172.20.0.4:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.120000 | 172.20.0.2 |          36529 | 127.0.0.1
                           MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.127000 | 172.20.0.4 |             52 | 127.0.0.1
                                                                Appending to commitlog [MutationStage-1] | 2021-08-27 04:05:04.141000 | 172.20.0.4 |          13860 | 127.0.0.1
                                                             Adding to tester memtable [MutationStage-1] | 2021-08-27 04:05:04.145000 | 172.20.0.4 |          17755 | 127.0.0.1
                                                Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:05:04.158000 | 172.20.0.4 |          30701 | 127.0.0.1
        Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.183000 | 172.20.0.4 |          56163 | 127.0.0.1
                           MUTATION_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:05:04.199000 | 172.20.0.2 |             38 | 127.0.0.1
                                      Processing response from /172.20.0.4:7000 [RequestResponseStage-2] | 2021-08-27 04:05:04.199000 | 172.20.0.2 |            795 | 127.0.0.1
         
         Request complete | 2021-08-27 04:05:04.118207 | 172.20.0.2 |          35207 | 127.0.0.1
### LWT  Experimentation 
SERIAL Sets consistency for lightweight transaction. 
LWT use IF EXISTS /IF/ IF NOT EXISTS in INSERT/UPDATE/DELETE 

#Set both read and Write Consistency
cqlsh> CONSISTENCY QUORUM;

#Display current SERIAL CONSISTENCY status.
cqlsh> SERIAL CONSISTENCY;
Current serial consistency level is SERIAL.

SERIAL Equivalent to QUORUM.
LOCAL_SERIAL Equivalent to LOCAL_QUORUM.

#(in our case, cqlsh at datacenter1, so LOCAL_SERIAL=2)
cqlsh> SERIAL CONSISTENCY LOCAL_SERIAL

cqlsh> TRACING ON;
#Note: Trace transactions to compare the difference 
#between INSERT statements with and without IF EXISTS.

cqlsh> USE mykeyspace2;
cqlsh> CREATE TABLE cyclist_name ( id UUID PRIMARY KEY, lastname text, firstname text );

(Quorum=2, 2 MUTATION_RSP from 2 nodes)
cqlsh:mykeyspace2> INSERT INTO cyclist_name (id, lastname, firstname) 
    VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne');

Tracing session: be824660-06ec-11ec-8f20-9bdae76af347

                                                                                                      activity                                             | timestamp                  | source     | source_elapsed | client
-----------------------------------------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                                                        Execute CQL3 query | 2021-08-27 04:10:41.990000 | 172.20.0.2 |              0 | 127.0.0.1
 Parsing INSERT INTO cyclist_name (id, lastname, firstname) VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'); [Native-Transport-Requests-1] | 2021-08-27 04:10:41.991000 | 172.20.0.2 |            456 | 127.0.0.1
                                                                                                         Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:10:41.992000 | 172.20.0.2 |           1857 | 127.0.0.1
                                                                                           Determining replicas for mutation [Native-Transport-Requests-1] | 2021-08-27 04:10:42.007000 | 172.20.0.2 |          16810 | 127.0.0.1
                                                         Sending MUTATION_REQ message to /172.20.0.3:7000 message size 117 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.011000 | 172.20.0.2 |          20472 | 127.0.0.1
                                                                             MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.012000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-1] | 2021-08-27 04:10:42.012000 | 172.20.0.3 |            852 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-3] | 2021-08-27 04:10:42.015000 | 172.20.0.2 |          24415 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-3] | 2021-08-27 04:10:42.015000 | 172.20.0.2 |          24793 | 127.0.0.1
                                                         Sending MUTATION_REQ message to /172.20.0.4:7000 message size 117 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.031000 | 172.20.0.2 |          40751 | 127.0.0.1
                                                                             MUTATION_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.037000 | 172.20.0.4 |             31 | 127.0.0.1
                                                                                                                  Appending to commitlog [MutationStage-2] | 2021-08-27 04:10:42.044000 | 172.20.0.4 |           7089 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-2] | 2021-08-27 04:10:42.050000 | 172.20.0.4 |          12715 | 127.0.0.1
                                                                                                  Enqueuing response to /172.20.0.2:7000 [MutationStage-2] | 2021-08-27 04:10:42.060000 | 172.20.0.4 |          23230 | 127.0.0.1
                                                          Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.066000 | 172.20.0.4 |          29222 | 127.0.0.1
                                                                             MUTATION_RSP message received from /172.20.0.4:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.067000 | 172.20.0.2 |          76777 | 127.0.0.1
                                                                                        Processing response from /172.20.0.4:7000 [RequestResponseStage-3] | 2021-08-27 04:10:42.068000 | 172.20.0.2 |          77946 | 127.0.0.1
                                                                                                         Adding to cyclist_name memtable [MutationStage-1] | 2021-08-27 04:10:42.088000 | 172.20.0.3 |          76858 | 127.0.0.1
                                                                                                  Enqueuing response to /172.20.0.2:7000 [MutationStage-1] | 2021-08-27 04:10:42.092000 | 172.20.0.3 |          80025 | 127.0.0.1
                                                          Sending MUTATION_RSP message to /172.20.0.2:7000 message size 34 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.092000 | 172.20.0.3 |          80402 | 127.0.0.1
                                                                             MUTATION_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:10:42.093000 | 172.20.0.2 |             26 | 127.0.0.1
                                                                                        Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:10:42.101000 | 172.20.0.2 |           6266 | 127.0.0.1
      
                                                                                                                                    Request complete | 2021-08-27 04:10:42.068286 | 172.20.0.2 |          78286 | 127.0.0.1

#Again Insert, basically it updates the same records 
#which does not use LightWeight Transaction (ie not serialized)
cqlsh> INSERT INTO cyclist_name (id, lastname, firstname) 
    VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne2');


#Example - this is not applied as id exists 
cqlsh> INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname )  
    VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','MarianneNN')    
    IF NOT EXISTS ;

[applied] | id                                   | firstname | lastname
----------+--------------------------------------+-----------+----------
    False | 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 | Marianne2 |      VOS
     
Tracing session: 2166efa0-06ee-11ec-8f20-9bdae76af347

                                 Execute CQL3 query | 2021-08-27 04:20:37.402000 | 172.20.0.2 |              0 | 127.0.0.1
                                                                                       Parsing INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname )  VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2,'Alex','FRAME' )    IF NOT EXISTS ; [Native-Transport-Requests-1] | 2021-08-27 04:20:37.402000 | 172.20.0.2 |            302 | 127.0.0.1
  Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:20:37.403000 | 172.20.0.2 |            773 | 127.0.0.1
                                                                                     Preparing 21743610-06ee-11ec-fa49-0cde6050197b [Native-Transport-Requests-1] | 2021-08-27 04:20:37.489000 | 172.20.0.2 |          87498 | 127.0.0.1
                                                            Sending PAXOS_PREPARE_REQ message to /172.20.0.3:7000 message size 84 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.508000 | 172.20.0.2 |         106058 | 127.0.0.1
                                                                               PAXOS_PREPARE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.511000 | 172.20.0.3 |             26 | 127.0.0.1
                                                                             Parsing SELECT * FROM system.paxos WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.519000 | 172.20.0.3 |           8863 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.522000 | 172.20.0.3 |          11321 | 127.0.0.1
                                                                             Parsing SELECT * FROM system.paxos WHERE row_key = ? AND cf_id = ? [MutationStage-2] | 2021-08-27 04:20:37.528000 | 172.20.0.2 |         125573 | 127.0.0.1
              Preparing statement [MutationStage-2] | 2021-08-27 04:20:37.535000 | 172.20.0.2 |         133367 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-1] | 2021-08-27 04:20:37.545000 | 172.20.0.3 |          34410 | 127.0.0.1
     Acquiring sstable references [MutationStage-1] | 2021-08-27 04:20:37.545000 | 172.20.0.3 |          34605 | 127.0.0.1
        Merging memtable contents [MutationStage-1] | 2021-08-27 04:20:37.555000 | 172.20.0.3 |          44299 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-2] | 2021-08-27 04:20:37.558000 | 172.20.0.2 |         155650 | 127.0.0.1
                                                                                                         Read 0 live rows and 0 tombstone cells [MutationStage-1] | 2021-08-27 04:20:37.560000 | 172.20.0.3 |          49156 | 127.0.0.1
                                                                                          Promising ballot 21743610-06ee-11ec-fa49-0cde6050197b [MutationStage-1] | 2021-08-27 04:20:37.560000 | 172.20.0.3 |          49498 | 127.0.0.1
                             Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET in_progress_ballot =? WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.566000 | 172.20.0.3 |          55801 | 127.0.0.1
     Acquiring sstable references [MutationStage-2] | 2021-08-27 04:20:37.567000 | 172.20.0.2 |         165038 | 127.0.0.1
        Merging memtable contents [MutationStage-2] | 2021-08-27 04:20:37.579000 | 172.20.0.2 |         177081 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.593000 | 172.20.0.3 |          82844 | 127.0.0.1
                                                                                                         Read 0 live rows and 0 tombstone cells [MutationStage-2] | 2021-08-27 04:20:37.597000 | 172.20.0.2 |         194894 | 127.0.0.1
                                                                                          Promising ballot 21743610-06ee-11ec-fa49-0cde6050197b [MutationStage-2] | 2021-08-27 04:20:37.603000 | 172.20.0.2 |         201125 | 127.0.0.1
                             Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET in_progress_ballot =? WHERE row_key = ? AND cf_id = ? [MutationStage-2] | 2021-08-27 04:20:37.615000 | 172.20.0.2 |         212657 | 127.0.0.1
           Appending to commitlog [MutationStage-1] | 2021-08-27 04:20:37.627000 | 172.20.0.3 |         116754 | 127.0.0.1
              Preparing statement [MutationStage-2] | 2021-08-27 04:20:37.634000 | 172.20.0.2 |         232491 | 127.0.0.1
         Adding to paxos memtable [MutationStage-1] | 2021-08-27 04:20:37.641000 | 172.20.0.3 |         129944 | 127.0.0.1
           Appending to commitlog [MutationStage-2] | 2021-08-27 04:20:37.652000 | 172.20.0.2 |         240753 | 127.0.0.1
         Adding to paxos memtable [MutationStage-2] | 2021-08-27 04:20:37.663000 | 172.20.0.2 |         260895 | 127.0.0.1
                                                           Sending PAXOS_PREPARE_RSP message to /172.20.0.2:7000 message size 135 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.675000 | 172.20.0.3 |         164082 | 127.0.0.1
                                                                               PAXOS_PREPARE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.684000 | 172.20.0.2 |         279269 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 04:20:37.694000 | 172.20.0.2 |         292515 | 127.0.0.1
                                                                                       Reading existing values for CAS precondition [Native-Transport-Requests-1] | 2021-08-27 04:20:37.712000 | 172.20.0.2 |         309900 | 127.0.0.1
                                                                                               reading digestfrom /172.20.0.3:7000 [Native-Transport-Requests-1] | 2021-08-27 04:20:37.720000 | 172.20.0.2 |         318229 | 127.0.0.1
                                                                                                   Executing single-partition query on cyclist_name [ReadStage-4] | 2021-08-27 04:20:37.722000 | 172.20.0.2 |         319996 | 127.0.0.1
         Acquiring sstable references [ReadStage-4] | 2021-08-27 04:20:37.722000 | 172.20.0.2 |         320208 | 127.0.0.1
            Merging memtable contents [ReadStage-4] | 2021-08-27 04:20:37.723000 | 172.20.0.2 |         320319 | 127.0.0.1
                                                                                                             Read 1 live rows and 0 tombstone cells [ReadStage-4] | 2021-08-27 04:20:37.726000 | 172.20.0.2 |         323734 | 127.0.0.1
                                                                    Sending READ_REQ message to /172.20.0.3:7000 message size 112 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.735000 | 172.20.0.2 |         332592 | 127.0.0.1
                                                                                        READ_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.738000 | 172.20.0.3 |             25 | 127.0.0.1
                                                                                                   Executing single-partition query on cyclist_name [ReadStage-2] | 2021-08-27 04:20:37.740000 | 172.20.0.3 |           2299 | 127.0.0.1
         Acquiring sstable references [ReadStage-2] | 2021-08-27 04:20:37.740000 | 172.20.0.3 |           2503 | 127.0.0.1
            Merging memtable contents [ReadStage-2] | 2021-08-27 04:20:37.746000 | 172.20.0.3 |           8686 | 127.0.0.1
                                                                                                             Read 1 live rows and 0 tombstone cells [ReadStage-2] | 2021-08-27 04:20:37.747000 | 172.20.0.3 |           9350 | 127.0.0.1
                                                                                                             Enqueuing response to /172.20.0.2:7000 [ReadStage-2] | 2021-08-27 04:20:37.747000 | 172.20.0.3 |           9518 | 127.0.0.1
                                                                     Sending READ_RSP message to /172.20.0.2:7000 message size 51 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.753000 | 172.20.0.3 |          14802 | 127.0.0.1
                                                                                        READ_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.756000 | 172.20.0.2 |         353796 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-3] | 2021-08-27 04:20:37.756000 | 172.20.0.2 |         354288 | 127.0.0.1
 CAS precondition does not match current values [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | [firstname lastname]]\n    Row[info=[ts=1630037836498584] ]: EMPTY | [firstname=Marianne ts=1630037836498584], [lastname=VOS ts=1630037836498584] [Native-Transport-Requests-1] | 2021-08-27 04:20:37.775000 | 172.20.0.2 |         373234 | 127.0.0.1
                               CAS precondition is met; proposing client-requested updates for 21743610-06ee-11ec-fa49-0cde6050197b [Native-Transport-Requests-1] | 2021-08-27 04:20:37.826000 | 172.20.0.2 |         424163 | 127.0.0.1
                                                            Sending PAXOS_PROPOSE_REQ message to /172.20.0.3:7000 message size 84 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.842000 | 172.20.0.2 |         440044 | 127.0.0.1
                                                                               PAXOS_PROPOSE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.844000 | 172.20.0.3 |             26 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-1] | 2021-08-27 04:20:37.846000 | 172.20.0.3 |           1897 | 127.0.0.1
     Acquiring sstable references [MutationStage-1] | 2021-08-27 04:20:37.856000 | 172.20.0.3 |          11778 | 127.0.0.1
        Merging memtable contents [MutationStage-1] | 2021-08-27 04:20:37.856000 | 172.20.0.3 |          11993 | 127.0.0.1
                                                                                                      Executing single-partition query on paxos [MutationStage-3] | 2021-08-27 04:20:37.874000 | 172.20.0.2 |         472304 | 127.0.0.1
     Acquiring sstable references [MutationStage-3] | 2021-08-27 04:20:37.876000 | 172.20.0.2 |         474138 | 127.0.0.1
        Merging memtable contents [MutationStage-3] | 2021-08-27 04:20:37.876000 | 172.20.0.2 |         474312 | 127.0.0.1
                                                                                                         Read1 live rows and 0 tombstone cells [MutationStage-1] | 2021-08-27 04:20:37.877000 | 172.20.0.3 |          32378 | 127.0.0.1
                                                                                                         Read1 live rows and 0 tombstone cells [MutationStage-3] | 2021-08-27 04:20:37.879000 | 172.20.0.2 |         477372 | 127.0.0.1
                           Accepting proposal Commit(21743610-06ee-11ec-fa49-0cde6050197b, [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | []]) [MutationStage-3] | 2021-08-27 04:20:37.882000 | 172.20.0.2 |         480113 | 127.0.0.1
                                                                                                          Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET proposal_ballot = ?, proposal = ?, proposal_version =? WHERE row_key = ? AND cf_id = ? [MutationStage-3] | 2021-08-27 04:20:37.882000 | 172.20.0.2 |         480384 | 127.0.0.1
                           Accepting proposal Commit(21743610-06ee-11ec-fa49-0cde6050197b, [mykeyspace2.cyclist_name] key=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 partition_deletion=deletedAt=-9223372036854775808, localDeletion=2147483647 columns=[[] | []]) [MutationStage-1] | 2021-08-27 04:20:37.895000 | 172.20.0.3 |          50348 | 127.0.0.1
              Preparing statement [MutationStage-3] | 2021-08-27 04:20:37.900000 | 172.20.0.2 |         497908 | 127.0.0.1
                                                                                                          Parsing UPDATE system.paxos USING TIMESTAMP ? AND TTL ? SET proposal_ballot = ?, proposal = ?, proposal_version =? WHERE row_key = ? AND cf_id = ? [MutationStage-1] | 2021-08-27 04:20:37.902000 | 172.20.0.3 |          57937 | 127.0.0.1
              Preparing statement [MutationStage-1] | 2021-08-27 04:20:37.921000 | 172.20.0.3 |          76364 | 127.0.0.1
           Appending to commitlog [MutationStage-3] | 2021-08-27 04:20:37.928000 | 172.20.0.2 |         526347 | 127.0.0.1
           Appending to commitlog [MutationStage-1] | 2021-08-27 04:20:37.933000 | 172.20.0.3 |          89053 | 127.0.0.1
         Adding to paxos memtable [MutationStage-3] | 2021-08-27 04:20:37.945000 | 172.20.0.2 |         532473 | 127.0.0.1
         Adding to paxos memtable [MutationStage-1] | 2021-08-27 04:20:37.949000 | 172.20.0.3 |         104962 | 127.0.0.1
                                                            Sending PAXOS_PROPOSE_RSP message to /172.20.0.2:7000 message size 35 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.972000 | 172.20.0.3 |         127380 | 127.0.0.1
                                                                               PAXOS_PROPOSE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:20:37.980000 | 172.20.0.2 |         577782 | 127.0.0.1
                                                                                               Processing response from /172.20.0.3:7000 [RequestResponseStage-2] | 2021-08-27 04:20:37.991000 | 172.20.0.2 |         589068 | 127.0.0.1
    CAS did not apply [Native-Transport-Requests-1] | 2021-08-27 04:20:37.991000 | 172.20.0.2 |         589386 | 127.0.0.1
                                   Request complete | 2021-08-27 04:20:38.000018 | 172.20.0.2 |         598018 | 127.0.0.1


#Set level to serial for read requests: 
#(note in this mode, write can not happen)
#
cqlsh> CONSISTENCY SERIAL

Consistency level set to SERIAL.

(Now READ request is different than normal)
cqlsh> SELECT * FROM mykeyspace2.cyclist_name ;


 id                                   | firstname | lastname
--------------------------------------+-----------+----------
 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 |  Marianne2 |      VOS

(1 rows)

Tracing session: 9658dfc0-06ef-11ec-8f20-9bdae76af347

                                                                                                      activity              | timestamp                  | source     | source_elapsed | client
----------------------------------------------------------------------------------------------------------------------------+----------------------------+------------+----------------+-----------
                                                                                                         Execute CQL3 query | 2021-08-27 04:31:03.100000 | 172.20.0.2 |              0 | 127.0.0.1
                                             Parsing SELECT * FROM mykeyspace2.cyclist_name ; [Native-Transport-Requests-1] | 2021-08-27 04:31:03.101000 | 172.20.0.2 |            550 | 127.0.0.1
                                                                          Preparing statement [Native-Transport-Requests-1] | 2021-08-27 04:31:03.101000 | 172.20.0.2 |            778 | 127.0.0.1
                                                                    Computing ranges to query [Native-Transport-Requests-1] | 2021-08-27 04:31:03.110000 | 172.20.0.2 |           9558 | 127.0.0.1
 Submitting range requests on 49 ranges with a concurrency of 1 (0.0 rows per range expected) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.114000 | 172.20.0.2 |          14307 | 127.0.0.1
       Enqueuing request to Full(/172.20.0.2:7000,(8900047540065365356,-9055191330884728872]) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.131000 | 172.20.0.2 |          30808 | 127.0.0.1
                             Sending RANGE_REQ message to /172.20.0.2:7000 message size 119 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.133000 | 172.20.0.2 |          33144 | 127.0.0.1
                                                 RANGE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.136000 | 172.20.0.2 |          36209 | 127.0.0.1
              Executing seq scan across 0 sstables for (min(-9223372036854775808), min(-9223372036854775808)][ReadStage-2]  | 2021-08-27 04:31:03.138000 | 172.20.0.2 |          37292 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 04:31:03.139000 | 172.20.0.2 |          38986 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-2]  | 2021-08-27 04:31:03.139000 | 172.20.0.2 |          39111 | 127.0.0.1
                              Sending RANGE_RSP message to /172.20.0.2:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.144000 | 172.20.0.2 |          44101 | 127.0.0.1
                                                 RANGE_RSP message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.148000 | 172.20.0.2 |          47368 | 127.0.0.1
                                                         Processing response from /172.20.0.2:7000 [RequestResponseStage-4] | 2021-08-27 04:31:03.149000 | 172.20.0.2 |          49010 | 127.0.0.1
       Enqueuing request to Full(/172.20.0.3:7000,(8900047540065365356,-9055191330884728872]) [Native-Transport-Requests-1] | 2021-08-27 04:31:03.150000 | 172.20.0.2 |          49751 | 127.0.0.1
                                                        Submitted 1 concurrent range requests [Native-Transport-Requests-1] | 2021-08-27 04:31:03.150000 | 172.20.0.2 |          49937 | 127.0.0.1
                             Sending RANGE_REQ message to /172.20.0.3:7000 message size 119 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.151000 | 172.20.0.2 |          50807 | 127.0.0.1
                                                 RANGE_REQ message received from /172.20.0.2:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.154000 | 172.20.0.3 |             30 | 127.0.0.1
              Executing seq scan across 0 sstables for (min(-9223372036854775808), min(-9223372036854775808)][ReadStage-2]  | 2021-08-27 04:31:03.160000 | 172.20.0.3 |           6490 | 127.0.0.1
                                                                       Read 1 live rows and 0 tombstone cells[ReadStage-2]  | 2021-08-27 04:31:03.172000 | 172.20.0.3 |          18181 | 127.0.0.1
                                                                       Enqueuing response to /172.20.0.2:7000[ReadStage-2]  | 2021-08-27 04:31:03.174000 | 172.20.0.3 |          20205 | 127.0.0.1
                              Sending RANGE_RSP message to /172.20.0.2:7000 message size 91 bytes [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.182000 | 172.20.0.3 |          27758 | 127.0.0.1
                                                 RANGE_RSP message received from /172.20.0.3:7000 [Messaging-EventLoop-3-1] | 2021-08-27 04:31:03.183000 | 172.20.0.2 |          82993 | 127.0.0.1
                                                         Processing response from /172.20.0.3:7000 [RequestResponseStage-4] | 2021-08-27 04:31:03.185000 | 172.20.0.2 |          85152 | 127.0.0.1
                                                                                                           Request complete | 2021-08-27 04:31:03.188708 | 172.20.0.2 |          88708 | 127.0.0.1


#Inserts with CONSISTENCY SERIAL fail:

cqlsh> INSERT INTO mykeyspace2.cyclist_name (id, firstname , lastname ) 
   VALUES (5b6962dd-3f90-4c93-8f61-eabfa4a803e2,'Alex','FRAME' ) 
   IF NOT EXISTS ;

InvalidRequest: Error from server: code=2200 [Invalid query] message=
"SERIAL is not supported as conditional update commit consistency. Use ANY if you mean 
'make sure it is accepted but I donot care how many replicas commit it for non-SERIAL reads'"


Updates with CONSISTENCY SERIAL also fail:

cqlsh>  UPDATE mykeyspace2.cyclist_name SET 
    firstname = 'ALEX'
WHERE 
   id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2 
IF EXISTS ;

InvalidRequest: Error from server: code=2200 [Invalid query] message="SERIAL is not supported as conditional update commit consistency. Use ANY if you mean "make sure it is accepted but I don't care how many replicas commit it for non-SERIAL reads""

#Reset to Quoram 
cqlsh> CONSISTENCY QUORUM;

cqlsh> UPDATE mykeyspace2.cyclist_name SET firstname = 'ALEX' 
        WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2  
        IF EXISTS ;

 [applied]
-----------
      True



###Tombstones- Examples 
A tombstone is created when data is deleted. 
It's a marker which says that to delete after grace period

Having an excessive number of tombstones in a table can negatively impact read performance. 
as all those need to be collated 

> USE mykeyspace2;

> CREATE TABLE rank_by_year_and_name (
    race_year int,
    race_name text,
    rank int,
    cyclist_name text,
    PRIMARY KEY ((race_year, race_name), rank)
) WITH CLUSTERING ORDER BY (rank ASC);

> 
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Benjamin PRADES', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Adam PHELAN', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Tour of Japan - Stage 4 - Minami > Shinshu', 'Thomas LEBAS', 3);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Ilnur ZAKARIN', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2015, 'Giro d''Italia - Stage 11 - Forli > Imola', 'Carlos BETANCUR', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Phillippe GILBERT', 1);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Daniel MARTIN', 2);
INSERT INTO rank_by_year_and_name (race_year, race_name, cyclist_name, rank) VALUES (2014, '4th Tour of Beijing', 'Johan Esteban CHAVES', 3);


##Flushing to SSTables
This step is necessary before running sstabledump to view the output.

> docker exec -ti cas1  nodetool flush mykeyspace2


> docker exec -it cas1 bash
$ ls /var/lib/cassandra/data/mykeyspace2/

$ cd /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

Note:For prior versions, use the sstable2json utility instead.
$ /opt/cassandra/tools/bin/sstabledump nb-1-big-Data.db
[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 43,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.185951Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Phillippe GILBERT" }
        ]
      },
      {
        "type" : "row",
        "position" : 73,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.212981Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Daniel MARTIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 99,
        "clustering" : [ 3 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.238272Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Johan Esteban CHAVES" }
        ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 133
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 197,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.102561Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Ilnur ZAKARIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 223,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.139937Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Carlos BETANCUR" }
        ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Tour of Japan - Stage 4 - Minami > Shinshu" ],
      "position" : 252
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 318,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:35.985026Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Benjamin PRADES" }
        ]
      },
      {
        "type" : "row",
        "position" : 344,
        "clustering" : [ 2 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.027970Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Adam PHELAN" }
        ]
      },
      {
        "type" : "row",
        "position" : 368,
        "clustering" : [ 3 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.059791Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Thomas LEBAS" }
        ]
      }
    ]
  }

##Partition tombstones
Partition tombstones are generated when an entire partition is deleted explicitly. 

> SELECT * from rank_by_year_and_name;

> DELETE from rank_by_year_and_name WHERE  
    race_year = 2014 AND race_name = '4th Tour of Beijing';

Check where this data exists 
$ docker exec -ti cas1 nodetool getendpoints mykeyspace2 rank_by_year_and_name 2014

Flush memtables to sstable 
> docker exec -ti cas1  nodetool flush mykeyspace2


> docker exec -it cas1 bash

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

$ cd /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta is present in new file with marked_deleted for partition )
$ /opt/cassandra/tools/bin/sstabledump nb-2-big-Data.db
[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0,
      "deletion_info" : { "marked_deleted" : "2021-08-27T07:24:11.267271Z", "local_delete_time" : "2021-08-27T07:24:11Z" }
    },
    "rows" : [ ]
  }
]

##Row tombstones
Row tombstones are generated when a particular row within a partition 
is deleted explicitly. 

> DELETE from rank_by_year_and_name WHERE 
 race_year = 2015 
 AND race_name = 'Giro d''Italia - Stage 11 - Forli > Imola' 
 AND rank = 2;

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta is present in new file with marked_deleted for rows )
$ /opt/cassandra/tools/bin/sstabledump nb-3-big-Data.db

Looking at the sstabledump output for this partition, the deletion_info tombstone marker is at the row level, 
[
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 2 ],
        "deletion_info" : { "marked_deleted" : "2021-08-27T07:40:30.976479Z", "local_delete_time" : "2021-08-27T07:40:30Z" },
        "cells" : [ ]
      }
    ]
  }
]


##Range tombstones
Range tombstones occur when several rows within a partition that can be expressed 
through a range search are deleted explicitly. 

> DELETE from rank_by_year_and_name WHERE 
 race_year = 2015 
 AND race_name = 'Tour of Japan - Stage 4 - Minami > Shinshu' 
 AND rank >= 2;

Looking at the sstabledump output for this partition, 
the deletion_info tombstone marker is at the row level. 

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347

(Only delta or full merged file is present in new file)
$ /opt/cassandra/tools/bin/sstabledump nb-5-big-Data.db

A special boundary marker, range_tombstone_bound, marks the range scope 
(identified by the clustering key values) of the deleted rows.

[
  {
    "partition" : {
      "key" : [ "2014", "4th Tour of Beijing" ],
      "position" : 0,
      "deletion_info" : { "marked_deleted" : "2021-08-27T07:24:11.267271Z", "local_delete_time" : "2021-08-27T07:24:11Z" }
    },
    "rows" : [ ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Giro d'Italia - Stage 11 - Forli > Imola" ],
      "position" : 44
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 108,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:36.102561Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Ilnur ZAKARIN" }
        ]
      },
      {
        "type" : "row",
        "position" : 134,
        "clustering" : [ 2 ],
        "deletion_info" : { "marked_deleted" : "2021-08-27T07:40:30.976479Z", "local_delete_time" : "2021-08-27T07:40:30Z" },
        "cells" : [ ]
      }
    ]
  },
  {
    "partition" : {
      "key" : [ "2015", "Tour of Japan - Stage 4 - Minami > Shinshu" ],
      "position" : 151
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 217,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T06:06:35.985026Z" },
        "cells" : [
          { "name" : "cyclist_name", "value" : "Benjamin PRADES" }
        ]
      },
      {
        "type" : "range_tombstone_bound",
        "start" : {
          "type" : "inclusive",
          "clustering" : [ 2 ],
          "deletion_info" : { "marked_deleted" : "2021-08-27T07:43:16.391518Z", "local_delete_time" : "2021-08-27T07:43:16Z" }
        }
      },
      {
        "type" : "range_tombstone_bound",
        "end" : {
          "type" : "inclusive",
          "deletion_info" : { "marked_deleted" : "2021-08-27T07:43:16.391518Z", "local_delete_time" : "2021-08-27T07:43:16Z" }
        }
      }
    ]
  }
]

##ComplexColumn tombstones
ComplexColumn tombstones are generated when inserting or updating 
a collection type column, such as set, list, and map.

> CREATE TABLE cyclist_career_teams (
    id UUID PRIMARY KEY,
    lastname text,
    teams set<text>
);

> INSERT INTO cyclist_career_teams (
     id,
     lastname,
     teams)
     VALUES (cb07baad-eac8-4f65-b28a-bddc06a0de23, 'ARMITSTEAD', { 
     'Boels-Dolmans Cycling Team','AA Drink - Leontien.nl','Team Garmin - Cervelo' } );

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347

$ cd /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347

$ /opt/cassandra/tools/bin/sstabledump nb-1-big-Data.db

Looking at the sstabledump output for this partition, 
no explicit manual deletion occurs on the partition, 
but a deletion_info marker is listed at the cell level 
for the collection type column teams.

[
  {
    "partition" : {
      "key" : [ "cb07baad-eac8-4f65-b28a-bddc06a0de23" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 30,
        "liveness_info" : { "tstamp" : "2021-08-27T07:46:31.849728Z" },
        "cells" : [
          { "name" : "lastname", "value" : "ARMITSTEAD" },
          { "name" : "teams", "deletion_info" : { "marked_deleted" : "2021-08-27T07:46:31.849727Z", "local_delete_time" : "2021-08-27T07:46:31Z" } },
          { "name" : "teams", "path" : [ "AA Drink - Leontien.nl" ], "value" : "" },
          { "name" : "teams", "path" : [ "Boels-Dolmans Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Team Garmin - Cervelo" ], "value" : "" }
        ]
      }
    ]
  }
]

##Cell tombstones
Cell tombstones are generated when explicitly deleting a value from a cell, 
such as a column for a specific row of a partition, 
or when inserting or updating a cell with NULL values, 

> INSERT INTO rank_by_year_and_name (
     race_year,
     race_name,
     cyclist_name,
     rank)
     VALUES (2018, 'Giro d''Italia - Stage 11 - Osimo > Imola', null, 1);

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ cd ../rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-6-big-Data.db

Looking at the "sstabledump" output for this partition, 
deletion_info tombstone marker is associated with a particular cell.
[
  {
    "partition" : {
      "key" : [ "2018", "Giro d'Italia - Stage 11 - Osimo > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 1 ],
        "liveness_info" : { "tstamp" : "2021-08-27T07:58:05.949672Z" },
        "cells" : [
          { "name" : "cyclist_name", "deletion_info" : { "local_delete_time" : "2021-08-27T07:58:05Z" }
          }
        ]
      }
    ]
  }
]

##TTL tombstones
TTL tombstones are generated when the TTL (time-to-live) period expires. 
The TTL expiration marker can occur at either the row or cell level. 

The following statement sets TTL for an entire row.

> INSERT INTO cyclist_career_teams (
     id,
     lastname,
     teams)
     VALUES (e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN', { 
     'Rabobank-Liv Woman Cycling Team','Sengers Ladies Cycling Team','Team Flexpoint' }) USING TTL 10;
     
contains two rows 
> select * from cyclist_career_teams; 

After 10 sec, contains one row 
> select * from cyclist_career_teams;

The following statement sets TTL for a single cell.

> UPDATE rank_by_year_and_name USING TTL 10
  SET cyclist_name = 'Cloudy Archipelago' WHERE race_year = 2018 AND 
  race_name = 'Giro d''Italia - Stage 11 - Osimo > Imola' AND rank = 1;


After 10 sec, cyclist_name would become null 
> select * from cyclist_career_teams;

(Flush)
> docker exec -ti cas1  nodetool flush mykeyspace2

(another file is created after flush)
$ ls /var/lib/cassandra/data/mykeyspace2/cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347
$ cd ../cyclist_career_teams-fc1b100006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-2-big-Data.db

the first CQL statement marks the row 
(partition key: e7cd5752-bc0d-4157-a80f-7523add8dbcd) with an "expired" : true 
TTL expiration marker in the liveness_info section.
[
  {
    "partition" : {
      "key" : [ "e7cd5752-bc0d-4157-a80f-7523add8dbcd" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 30,
        "liveness_info" : { "tstamp" : "2021-08-27T08:25:12.513792Z", "ttl" : 10, "expires_at" : "2021-08-27T08:25:13Z", "expired" : true },
        "cells" : [
          { "name" : "lastname", "value" : "VAN DER BREGGEN" },
          { "name" : "teams", "deletion_info" : { "marked_deleted" : "2021-08-27T08:25:12.513791Z", "local_delete_time" : "2021-08-27T08:25:12Z" } },
          { "name" : "teams", "path" : [ "Rabobank-Liv Woman Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Sengers Ladies Cycling Team" ], "value" : "" },
          { "name" : "teams", "path" : [ "Team Flexpoint" ], "value" : "" }
        ]
      }
    ]
  }
]
  
$ ls /var/lib/cassandra/data/mykeyspace2/rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ cd ../rank_by_year_and_name-e48290d006fc11ec8f209bdae76af347
$ /opt/cassandra/tools/bin/sstabledump nb-7-big-Data.db

The second CQL statement marks the cell 
(partition key: 2018, clustering key: 1, column name: cyclist_name) 
with an "expired" : true TTL expiration marker for the specific cell.
[
  {
    "partition" : {
      "key" : [ "2018", "Giro d'Italia - Stage 11 - Osimo > Imola" ],
      "position" : 0
    },
    "rows" : [
      {
        "type" : "row",
        "position" : 64,
        "clustering" : [ 1 ],
        "cells" : [
          { "name" : "cyclist_name", "value" : "Cloudy Archipelago", "tstamp" : "2021-08-27T08:25:19.336242Z", "ttl" : 10, "expires_at" : "2021-08-27T08:25:20Z", "expired" : true }
        ]
      }
    ]
  }
  


###*** Java API 

##Create gradle project 
https://docs.gradle.org/current/samples/sample_building_java_applications.html
$ gradle init   (select java application )

Note 
driver.version = 4.13.0

##build.gradle
plugins {
    // Apply the java plugin to add support for Java
    id 'java'

    // Apply the application plugin to add support for building a CLI application.
    id 'application'
    
    id 'groovy'
    
    id 'scala'
    
    //https://github.com/johnrengelman/shadow
    //for generating fatjar , use gradle shadowJar
    id 'com.github.johnrengelman.shadow' version '6.1.0'
}
compileJava {
    sourceCompatibility = '1.8'
}
repositories {
    // Use jcenter for resolving dependencies.
    // You can declare any Maven/Ivy/file repository here.
    mavenCentral()
    jcenter()
    
    maven { 
        url 'https://packages.confluent.io/maven/'
    }
}

dependencies {
    implementation group: 'com.datastax.oss', name: 'java-driver-core', version: '4.13.0'
    implementation group: 'ch.qos.logback', name: 'logback-classic', version: '1.2.3'
}
mainClassName = "examples.Main2"
//gradle build and gradle -PmainClass=examples.Main2 runApp
task runApp(type:JavaExec) {
    classpath = sourceSets.main.runtimeClasspath
    main = project.hasProperty("mainClass") ? project.getProperty("mainClass") : "examples.Main2"
}




##src/main/java/Main.java - with local cassandra but having authenticator 
package examples;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;


public class Main {
  public static void main(String[] args) {
    try (CqlSession session = CqlSession.builder().withAuthCredentials("cassandra", "cassandra").build()) {
      ResultSet rs = session.execute("SELECT release_version FROM system.local");
      System.out.println(rs.one().getString(0));
      //OR 
      //System.out.println(rs.one().getString("release_version"));  
    }
  }
}
##src/main/java/Main2.java - with docker, 
#find out docker machine ip (for docker desktop-localhost)
package examples;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;
import java.net.InetSocketAddress;


public class Main2 {
  public static void main(String[] args) {
    String ip = "192.168.99.100";
    if (args.length > 0) {
        ip = args[0];
    }
    try (CqlSession session = CqlSession.builder().
        addContactPoint(new InetSocketAddress(ip, 9042)).
        withLocalDatacenter("datacenter1").build()) {
      ResultSet rs = session.execute("SELECT release_version FROM system.local");
      System.out.println(rs.one().getString(0));
      //OR 
      //System.out.println(rs.one().getString("release_version"));  
    }
  }
}


##OPTIONAL-src/main/resources/application.conf
#https://github.com/datastax/java-driver/tree/4.x/manual/core/configuration
datastax-java-driver {
    basic.session-name = poc
}

In this case, we just specify a custom name for our session, 
it will appear in the logs.

##OPTIONAL-src/main/resources/logback.xml
<configuration>
  <appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>
  <root level="WARN">
    <appender-ref ref="STDOUT"/>
  </root>
  <logger name="com.datastax.oss.driver" level= "INFO"/>
</configuration>



$ ./gradlew execute
:compileJava
:processResources
:classes
:execute
13:32:25.339 [main] INFO  c.d.o.d.i.c.DefaultMavenCoordinates - DataStax Java driver for Apache Cassandra(R) (com.datastax.oss:java-driver-core) version 4.0.1-alpha4-SNAPSHOT
13:32:25.682 [poc-admin-0] INFO  c.d.o.d.internal.core.time.Clock - Using native clock for microsecond precision
13:32:25.683 [poc-admin-0] INFO  c.d.o.d.i.c.metadata.MetadataManager - [poc] No contact points provided, defaulting to /127.0.0.1:9042
3.11.2



### SNAPSHOT -- ADVANCED 

Apache Cassandra supports two kinds of backup strategies.
    Snapshots
        copys  table SSTable files via hard links in Snapshots/
        Automatic or manual 
        Automatic 
            cassandra.yaml:snapshot_before_compaction(default:false)
                creates snapshot before compaction
            cassandra.yaml:auto_snapshot to true (default true)
                creates snapshot before keyspace/table dropping/truncation
    Incremental Backups
        By default disabled ,enable it with cassandra.yaml:incremental_backups
        Then it creates a hard link of each SSTable+system table 
        when flushed in a backups/ 

#Data Directory Structure
data 
    /Keyspace_name 
        /Table_name 
            /Backups/SStable files 
            /Snapshots/SStable files 
            SStablefiles 
#Example  
> CREATE KEYSPACE cqlkeyspace
   WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1};

>  USE cqlkeyspace;
CREATE TABLE t (
   id int,
   k int,
   v text,
   PRIMARY KEY (id)
);
CREATE TABLE t2 (
   id int,
   k int,
   v text,
   PRIMARY KEY (id)
);

#Add data to the tables:

> INSERT INTO t (id, k, v) VALUES (0, 0, 'val0');
INSERT INTO t (id, k, v) VALUES (1, 1, 'val1');

INSERT INTO t2 (id, k, v) VALUES (0, 0, 'val0');
INSERT INTO t2 (id, k, v) VALUES (1, 1, 'val1');
INSERT INTO t2 (id, k, v) VALUES (2, 2, 'val2');

#Query the table to list the data:

> SELECT * FROM t;
SELECT * FROM t2;

id | k | v
----+---+------
 1 | 1 | val1
 0 | 0 | val0

 (2 rows)


id | k | v
----+---+------
 1 | 1 | val1
 0 | 0 | val0
 2 | 2 | val2

 (3 rows)

#Create a second keyspace catalogkeyspace:

> CREATE KEYSPACE catalogkeyspace
   WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1};


> USE catalogkeyspace;
CREATE TABLE journal (
   id int,
   name text,
   publisher text,
   PRIMARY KEY (id)
);

CREATE TABLE magazine (
   id int,
   name text,
   publisher text,
   PRIMARY KEY (id)
);

#Add data to the tables:

> INSERT INTO journal (id, name, publisher) VALUES (0, 'Apache Cassandra Magazine', 'Apache Cassandra');
INSERT INTO journal (id, name, publisher) VALUES (1, 'Couchbase Magazine', 'Couchbase');

INSERT INTO magazine (id, name, publisher) VALUES (0, 'Apache Cassandra Magazine', 'Apache Cassandra');
INSERT INTO magazine (id, name, publisher) VALUES (1, 'Couchbase Magazine', 'Couchbase');

#Query the tables to list the data:

> SELECT * FROM catalogkeyspace.journal;
SELECT * FROM catalogkeyspace.magazine;

id | name                      | publisher
----+---------------------------+------------------
 1 |        Couchbase Magazine |        Couchbase
 0 | Apache Cassandra Magazine | Apache Cassandra

 (2 rows)

id | name                      | publisher
----+---------------------------+------------------
 1 |        Couchbase Magazine |        Couchbase
 0 | Apache Cassandra Magazine | Apache Cassandra

 (2 rows)


##Snapshots

$ nodetool help snapshot

[(-cf <table> | --column-family <table> | --table <table>)]
[(-kt <ktlist> | --kt-list <ktlist> | -kc <ktlist> | --kc.list <ktlist>)]
[(-sf | --skip-flush)] [(-t <tag> | --tag <tag>)] [--] [<keyspaces...>]

OPTIONS
       -cf <table>, --column-family <table>, --table <table>
           The table name (you must specify one and only one keyspace for using
           this option)

       -kt <ktlist>, --kt-list <ktlist>, -kc <ktlist>, --kc.list <ktlist>
           The list of Keyspace.table to take snapshot.(you must not specify
           only keyspace)

        ...

       --
           This option can be used to separate command-line options from the
           list of argument, (useful when arguments might be mistaken for
           command-line options

       [<keyspaces...>]
           List of keyspaces. By default, all keyspaces


##Configuring for Snapshots (OPTIONAL)
For experimentation, Set  
#cassandra.yaml
auto_snapshot: false
snapshot_before_compaction: false

Restart Cassandra in all nodes 

##Creating Snapshots
$ cd /var/lib/
$ find ./cassandra/data/ -name snapshots

#Taking Snapshots of all Tables in a Keyspace
$ nodetool snapshot --tag catalog-ks catalogkeyspace

$ find ./cassandra/data/ -name snapshots
./cassandra/data/data/catalogkeyspace/journal-296a2d30c22a11e9b1350d927649052c/snapshots
./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/snapshots

#Snapshots of all tables in multiple keyspaces may be created similarly:
$ nodetool snapshot --tag catalog-cql-ks catalogkeyspace, cqlkeyspace

#To take a snapshot of a single table the nodetool snapshot command syntax becomes as follows:
$ nodetool snapshot --tag magazine --table magazine  catalogkeyspace

#Taking Snapshot of Multiple Tables from same Keyspace
$ nodetool snapshot --kt-list cqlkeyspace.t,cqlkeyspace.t2 --tag multi-table

$ nodetool snapshot --kt-list cqlkeyspace.t, cqlkeyspace.t2 --tag multi-table-2

#Taking Snapshot of Multiple Tables from Different Keyspaces
$ nodetool snapshot --kt-list catalogkeyspace.journal,cqlkeyspace.t --tag multi-ks

#Listing Snapshots
$ nodetool listsnapshots

Snapshot Details:
Snapshot name Keyspace name   Column family name True size Size on disk
multi-table   cqlkeyspace     t2                 4.86 KiB  5.67 KiB
multi-table   cqlkeyspace     t                  4.89 KiB  5.7 KiB
multi-ks      cqlkeyspace     t                  4.89 KiB  5.7 KiB
multi-ks      catalogkeyspace journal            4.9 KiB   5.73 KiB
magazine      catalogkeyspace magazine           4.9 KiB   5.73 KiB
multi-table-2 cqlkeyspace     t2                 4.86 KiB  5.67 KiB
multi-table-2 cqlkeyspace     t                  4.89 KiB  5.7 KiB
catalog-ks    catalogkeyspace journal            4.9 KiB   5.73 KiB
catalog-ks    catalogkeyspace magazine           4.9 KiB   5.73 KiB

Total TrueDiskSpaceUsed: 44.02 KiB

##Finding Snapshots Directories

$ find ./cassandra/data/ -name snapshots

./cassandra/data/data/cqlkeyspace/t-d132e240c21711e9bbee19821dcea330/snapshots
./cassandra/data/data/cqlkeyspace/t2-d993a390c22911e9b1350d927649052c/snapshots
./cassandra/data/data/catalogkeyspace/journal-296a2d30c22a11e9b1350d927649052c/snapshots
./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/snapshots

To list the snapshots for a particular table first change 
to the snapshots directory for that table. 
For example, list the snapshots for the catalogkeyspace/journal table:

$ cd ./cassandra/data/data/catalogkeyspace/journal-296a2d30c22a11e9b1350d927649052c/snapshots && ls -l

total 0
drwxrwxr-x. 2 ec2-user ec2-user 265 Aug 19 02:44 catalog-ks
drwxrwxr-x. 2 ec2-user ec2-user 265 Aug 19 02:52 multi-ks

A snapshots directory lists the SSTable files in the snapshot. 
A schema.cql file is also created in each snapshot that defines schema 
that can recreate the table with CQL when restoring from a snapshot:

$ cd catalog-ks && ls -l
total 44
-rw-rw-r--. 1 ec2-user ec2-user   31 Aug 19 02:44 manifest.jsonZ
-rw-rw-r--. 4 ec2-user ec2-user   47 Aug 19 02:38 na-1-big-CompressionInfo.db
-rw-rw-r--. 4 ec2-user ec2-user   97 Aug 19 02:38 na-1-big-Data.db
-rw-rw-r--. 4 ec2-user ec2-user   10 Aug 19 02:38 na-1-big-Digest.crc32
-rw-rw-r--. 4 ec2-user ec2-user   16 Aug 19 02:38 na-1-big-Filter.db
-rw-rw-r--. 4 ec2-user ec2-user   16 Aug 19 02:38 na-1-big-Index.db
-rw-rw-r--. 4 ec2-user ec2-user 4687 Aug 19 02:38 na-1-big-Statistics.db
-rw-rw-r--. 4 ec2-user ec2-user   56 Aug 19 02:38 na-1-big-Summary.db
-rw-rw-r--. 4 ec2-user ec2-user   92 Aug 19 02:38 na-1-big-TOC.txt
-rw-rw-r--. 1 ec2-user ec2-user  814 Aug 19 02:44 schema.cql

#Clearing Snapshots

$ nodetool clearsnapshot -t magazine cqlkeyspace

# delete all snapshots from cqlkeyspace with the –all option:

$ nodetool clearsnapshot -all cqlkeyspace

###Incremental Backups -- ADVANCED  

##Configuring for Incremental Backups
#cassandra.yaml.
incremental_backups: true

By default incremental_backups setting is set to false 

Incremental backups may also be enabled on the command line with the 
$ nodetool command nodetool enablebackup. 

Incremental backups may be disabled with 
$ nodetool disablebackup 

Status of incremental backups, whether they are enabled may be checked with 
$ nodetool statusbackup.


##Creating Incremental Backups
After each table is created flush the table data with nodetool flush command.
Incremental backups get created.

$ nodetool flush cqlkeyspace t
$ nodetool flush cqlkeyspace t2
$ nodetool flush catalogkeyspace journal magazine

##Finding Incremental Backups
$ find ./cassandra/data/ -name snapshots
./cassandra/data/data/cqlkeyspace/t-d132e240c21711e9bbee19821dcea330/backups
./cassandra/data/data/cqlkeyspace/t2-d993a390c22911e9b1350d927649052c/backups
./cassandra/data/data/catalogkeyspace/journal-296a2d30c22a11e9b1350d927649052c/backups
./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/backups

###Bulk loading  and Restoring from Incremental Backups and Snapshots  -- ADVANCED 
The two main tools/commands for restoring a table 
after it has been dropped are:
    /opt/cassandra/bin/sstableloader
    nodetool import

A snapshot contains essentially the same set of SSTable files 
as an incremental backup does with a few additional files. 

A snapshot includes a schema.cql file for the schema DDL 
to create a table in CQL. 

A table backup does not include DDL which must be obtained 
from a snapshot when restoring from an incremental backup.

##Using sstableloader
The only requirements to run sstableloader are:
    One or more comma separated initial hosts to connect to 
    A directory path for the SSTables to load

$ /opt/cassandra/bin/sstableloader [options] <dir_path>

Sstableloader bulk loads the SSTables found in the directory <dir_path> 
to the configured cluster. 
The <dir_path> is used as the target keyspace/table name. 

For example, to load an SSTable named Standard1-g-1-Data.db into 
Keyspace1/Standard1, 

Create a directory  /path/to/Keyspace1/Standard1/
having Standard1-g-1-Data.db and Standard1-g-1-Index.db files 

Some other requirements of sstableloader that should be kept 
into consideration are:
    The SSTables loaded must be compatible with the Cassandra version 
        being loaded into.
    Repairing tables that have been loaded into a different cluster 
        does not repair the source tables.
    Sstableloader makes use of port 7000 for internode communication.
    Before restoring incremental backups, run nodetool flush 
        to backup any data in memtables.


##A sstableloader Demo
The backups and snapshots for the catalogkeyspace.magazine table 
are listed as follows:

$ cd ./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c && ls -l

total 0
drwxrwxr-x. 2 ec2-user ec2-user 226 Aug 19 02:38 backups
drwxrwxr-x. 4 ec2-user ec2-user  40 Aug 19 02:45 snapshots

The directory path structure of SSTables to be uploaded 
using sstableloader is used as the target 'keyspace/table'. 

The directory path of backups and snapshots for SSTables :
/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/backups 
/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/snapshots 

and cannot be used to upload SSTables to catalogkeyspace.magazine table
as  sstableloader requires the directory path as /catalogkeyspace/magazine

So to load to catalogkeyspace.magazine, create below 

$ sudo mkdir -p /catalogkeyspace/magazine
$ sudo chmod -R 777 /catalogkeyspace/magazine
$ sudo cp ./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/backups/* /catalogkeyspace/magazine/

#For snapshots 
$ sudo mkdir -p /catalogkeyspace/magazine2
$ sudo chmod -R 777 /catalogkeyspace/magazine2
$ sudo cp ./cassandra/data/data/catalogkeyspace/magazine-446eae30c22a11e9b1350d927649052c/snapshots/magazine/* /catalogkeyspace/magazine2


##Bulk Loading from an Incremental Backup
> TRUNCATE TABLE catalogkeyspace.magazine;

> SELECT * FROM catalogkeyspace.magazine;

id | name | publisher
----+------+-----------

(0 rows)


Run the sstableloader to upload SSTables 
from the /catalogkeyspace/magazine/ directory.

$ sstableloader --nodes 172.20.0.2  /catalogkeyspace/magazine/
#output 
Opening SSTables and calculating sections to stream
Streaming relevant part of /catalogkeyspace/magazine/na-1-big-Data.db
/catalogkeyspace/magazine/na-2-big-Data.db  to [35.173.233.153:7000, 10.0.2.238:7000,
54.158.45.75:7000]
progress: [35.173.233.153:7000]0:1/2 88 % total: 88% 0.018KiB/s (avg: 0.018KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% total: 176% 33.807KiB/s (avg: 0.036KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% total: 176% 0.000KiB/s (avg: 0.029KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:1/2 39 % total: 81% 0.115KiB/s
(avg: 0.024KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:2/2 78 % total: 108%
97.683KiB/s (avg: 0.033KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:2/2 78 %
[54.158.45.75:7000]0:1/2 39 % total: 80% 0.233KiB/s (avg: 0.040KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:2/2 78 %
[54.158.45.75:7000]0:2/2 78 % total: 96% 88.522KiB/s (avg: 0.049KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:2/2 78 %
[54.158.45.75:7000]0:2/2 78 % total: 96% 0.000KiB/s (avg: 0.045KiB/s)
progress: [35.173.233.153:7000]0:2/2 176% [10.0.2.238:7000]0:2/2 78 %
[54.158.45.75:7000]0:2/2 78 % total: 96% 0.000KiB/s (avg: 0.044KiB/s)


After the sstableloader has finished loading the data, 
run a query the magazine table to check:

> SELECT * FROM magazine;

id | name                      | publisher
----+---------------------------+------------------
 1 |        Couchbase Magazine |        Couchbase
 0 | Apache Cassandra Magazine | Apache Cassandra

(2 rows)

##Bulk Loading from a Snapshot

If required , do below 
$ sudo mkdir -p /catalogkeyspace/magazine
$ sudo chmod -R 777 /catalogkeyspace/magazine

Remove any files from the directory, 
so that the snapshot files can be copied without interference:

$ sudo rm /catalogkeyspace/magazine/*
$ cd /catalogkeyspace/magazine/
$ cp -R /catalogkeyspace/magazine2/* . 

$ ls -l
total 44
-rw-r--r--. 1 root root   31 Aug 19 04:13 manifest.json
-rw-r--r--. 1 root root   47 Aug 19 04:13 na-1-big-CompressionInfo.db
-rw-r--r--. 1 root root   97 Aug 19 04:13 na-1-big-Data.db
-rw-r--r--. 1 root root   10 Aug 19 04:13 na-1-big-Digest.crc32
-rw-r--r--. 1 root root   16 Aug 19 04:13 na-1-big-Filter.db
-rw-r--r--. 1 root root   16 Aug 19 04:13 na-1-big-Index.db
-rw-r--r--. 1 root root 4687 Aug 19 04:13 na-1-big-Statistics.db
-rw-r--r--. 1 root root   56 Aug 19 04:13 na-1-big-Summary.db
-rw-r--r--. 1 root root   92 Aug 19 04:13 na-1-big-TOC.txt
-rw-r--r--. 1 root root  815 Aug 19 04:13 schema.cql


$ sstableloader --nodes 172.20.0.2  /catalogkeyspace/magazine/
#Output 
Established connection to initial hosts
Opening SSTables and calculating sections to stream
Streaming relevant part of /catalogkeyspace/magazine/na-1-big-Data.db  to
[35.173.233.153:7000, 10.0.2.238:7000, 54.158.45.75:7000]
progress: [35.173.233.153:7000]0:1/1 176% total: 176% 0.017KiB/s (avg: 0.017KiB/s)
progress: [35.173.233.153:7000]0:1/1 176% total: 176% 0.000KiB/s (avg: 0.014KiB/s)
progress: [35.173.233.153:7000]0:1/1 176% [10.0.2.238:7000]0:1/1 78 % total: 108% 0.115KiB/s
(avg: 0.017KiB/s)
progress: [35.173.233.153:7000]0:1/1 176% [10.0.2.238:7000]0:1/1 78 %
[54.158.45.75:7000]0:1/1 78 % total: 96% 0.232KiB/s (avg: 0.024KiB/s)
progress: [35.173.233.153:7000]0:1/1 176% [10.0.2.238:7000]0:1/1 78 %
[54.158.45.75:7000]0:1/1 78 % total: 96% 0.000KiB/s (avg: 0.022KiB/s)
progress: [35.173.233.153:7000]0:1/1 176% [10.0.2.238:7000]0:1/1 78 %
[54.158.45.75:7000]0:1/1 78 % total: 96% 0.000KiB/s (avg: 0.021KiB/s)


##Using nodetool import
Importing SSTables into a table using the nodetool import command 
is recommended instead of the deprecated nodetool refresh command. 

The nodetool import command has an option to load new SSTables 
from a separate directory.

nodetool [(-h <host> | --host <host>)] [(-p <port> | --port <port>)]
       [(-pp | --print-port)] [(-pw <password> | --password <password>)]
       [(-pwf <passwordFilePath> | --password-file <passwordFilePath>)]
       [(-u <username> | --username <username>)] import
       [(-c | --no-invalidate-caches)] [(-e | --extended-verify)]
       [(-l | --keep-level)] [(-q | --quick)] [(-r | --keep-repaired)]
       [(-t | --no-tokens)] [(-v | --no-verify)] [--] <keyspace> <table>
       <directory> ...

##Importing Data from an Incremental Backup

> DROP table t;

An incremental backup for a table does not include the schema definition 
for the table. 
If the schema definition is not kept as a separate backup, 
the schema.cql from a backup of the table 
may be used to create the table as follows:

> CREATE TABLE IF NOT EXISTS cqlkeyspace.t (
   id int PRIMARY KEY,
   k int,
   v text)
   WITH ID = d132e240-c217-11e9-bbee-19821dcea330
   AND bloom_filter_fp_chance = 0.01
   AND crc_check_chance = 1.0
   AND default_time_to_live = 0
   AND gc_grace_seconds = 864000
   AND min_index_interval = 128
   AND max_index_interval = 2048
   AND memtable_flush_period_in_ms = 0
   AND speculative_retry = '99p'
   AND additional_write_policy = '99p'
   AND comment = ''
   AND caching = { 'keys': 'ALL', 'rows_per_partition': 'NONE' }
   AND compaction = { 'max_threshold': '32', 'min_threshold': '4',
   'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy' }
   AND compression = { 'chunk_length_in_kb': '16', 'class':
   'org.apache.cassandra.io.compress.LZ4Compressor' }
   AND cdc = false
   AND extensions = {  }
;

Initially the table could be empty, but does not have to be.

> SELECT * FROM t;

id | k | v
----+---+---

(0 rows)

Run the nodetool import command, providing the keyspace, table 
and the backups directory.

Don’t copy the table backups to another directory, 
as with sstableloader.

$ nodetool import -- cqlkeyspace t ./cassandra/data/data/cqlkeyspace/t-d132e240c21711e9bbee19821dcea330/backups

The SSTables are imported into the table. Run a query in cqlsh to check:

> SELECT * FROM t;

id | k | v
----+---+------
 1 | 1 | val1
 0 | 0 | val0

(2 rows)

##Importing Data from a Snapshot

> USE CATALOGKEYSPACE;
DROP TABLE journal;

Use the catalog-ks snapshot for the journal table. 
Check the files in the snapshot, and note the existence of the schema.cql file.

$ ls -l

total 44
-rw-rw-r--. 1 ec2-user ec2-user   31 Aug 19 02:44 manifest.json
-rw-rw-r--. 3 ec2-user ec2-user   47 Aug 19 02:38 na-1-big-CompressionInfo.db
-rw-rw-r--. 3 ec2-user ec2-user   97 Aug 19 02:38 na-1-big-Data.db
-rw-rw-r--. 3 ec2-user ec2-user   10 Aug 19 02:38 na-1-big-Digest.crc32
-rw-rw-r--. 3 ec2-user ec2-user   16 Aug 19 02:38 na-1-big-Filter.db
-rw-rw-r--. 3 ec2-user ec2-user   16 Aug 19 02:38 na-1-big-Index.db
-rw-rw-r--. 3 ec2-user ec2-user 4687 Aug 19 02:38 na-1-big-Statistics.db
-rw-rw-r--. 3 ec2-user ec2-user   56 Aug 19 02:38 na-1-big-Summary.db
-rw-rw-r--. 3 ec2-user ec2-user   92 Aug 19 02:38 na-1-big-TOC.txt
-rw-rw-r--. 1 ec2-user ec2-user  814 Aug 19 02:44 schema.cql

Copy the DDL from the schema.cql and run in cqlsh 
to create the catalogkeyspace.journal table:

> CREATE TABLE IF NOT EXISTS catalogkeyspace.journal (
   id int PRIMARY KEY,
   name text,
   publisher text)
   WITH ID = 296a2d30-c22a-11e9-b135-0d927649052c
   AND bloom_filter_fp_chance = 0.01
   AND crc_check_chance = 1.0
   AND default_time_to_live = 0
   AND gc_grace_seconds = 864000
   AND min_index_interval = 128
   AND max_index_interval = 2048
   AND memtable_flush_period_in_ms = 0
   AND speculative_retry = '99p'
   AND additional_write_policy = '99p'
   AND comment = ''
   AND caching = { 'keys': 'ALL', 'rows_per_partition': 'NONE' }
   AND compaction = { 'min_threshold': '4', 'max_threshold':
   '32', 'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy' }
   AND compression = { 'chunk_length_in_kb': '16', 'class':
   'org.apache.cassandra.io.compress.LZ4Compressor' }
   AND cdc = false
   AND extensions = {  }
;

Run the nodetool import command to import the SSTables for the snapshot:

$ nodetool import -- catalogkeyspace journal ./cassandra/data/data/catalogkeyspace/journal-296a2d30c22a11e9b1350d927649052c/snapshots/catalog-ks/

Subsequently run a CQL query on the journal table to check the imported data:

> SELECT * FROM journal;

id | name                      | publisher
----+---------------------------+------------------
 1 |        Couchbase Magazine |        Couchbase
 0 | Apache Cassandra Magazine | Apache Cassandra

(2 rows)

###Cassandra Performance Metrics using nodetool


$ docker exec -it cas1 nodetool status

Datacenter: datacenter1
=======================
Status=Up/Down
|/ State=Normal/Leaving/Joining/Moving
--  Address    Load       Owns    Host ID   Token                  Rack
UN  127.0.0.1  14.76 MB   100%    9e524995  -9223372036854775808   rack1

nodetool info outputs slightly more detailed statistics 
for an individual node in the cluster, including uptime, load, KEY CACHE HIT RATE, 
and a total count of all exceptions. 
You can specify which node you’d like to inspect by using the --host argument 
with an IP address or hostname

$ docker exec -it cas1 nodetool  info

ID                     : 9aa4fe41-c9a8-43bb-990a-4a6192b3b46d
Gossip active          : true
Thrift active          : false
Native Transport active: true
Load                   : 14.76 MB
Generation No          : 1449113333
Uptime (seconds)       : 527
Heap Memory (MB)       : 158.50 / 495.00
Off Heap Memory (MB)   : 0.07
Data Center            : datacenter1
Rack                   : rack1
Exceptions             : 0
Key Cache              : entries 26, size 2.08 KB, capacity 24 MB, 87 hits, 122 requests, 0.713 recent hit rate, 14400 save period in seconds
Row Cache              : entries 0, size 0 bytes, capacity 0 bytes, 0 hits, 0 requests, NaN recent hit rate, 0 save period in seconds
Counter Cache          : entries 0, size 0 bytes, capacity 12 MB, 0 hits, 0 requests, NaN recent hit rate, 7200 save period in seconds
Token                  : -9223372036854775808

nodetool cfstats(new name:tablestats) provides statistics on each keyspace 
and column family including READ LATENCY, WRITE LATENCY, AND TOTAL DISK SPACE USED. 

By default nodetool prints statistics on all keyspaces and column families, 
but you can limit the query to a single keyspace by appending 
the name of the keyspace to the command:

Include 'keyspace table' at the end 
$ docker exec -it cas1 nodetool tablestats 
(Many outputs, for example for Demo)
Keyspace: demo
    Read Count: 4
    Read Latency: 1.386 ms.
    Write Count: 4
    Write Latency: 0.71675 ms.
    Pending Flushes: 0
        Table: users
        SSTable count: 3
        Space used (live), bytes: 16178
        Space used (total), bytes: 16261
        ...
        Local read count: 4
        Local read latency: 1.153 ms
        Local write count: 4
        Local write latency: 0.224 ms
        Pending flushes: 0
        ...

nodetool compactionstats shows the compactions in progess 
as well as a count of pending compaction tasks.

Compaction is crucial to ensuring good read performance 
so having the right balance of concurrent 
compactions such that compactions complete quickly 
but don’t take too many resources away 
from query threads is very important for performance

$ docker exec -it cas1 nodetool compactionstats

pending tasks: 5
          compaction type        keyspace           table       completed           total      unit  progress
               Compaction       Keyspace1       Standard1       282310680       302170540     bytes    93.43%
               Compaction       Keyspace1       Standard1        58457931       307520780     bytes    19.01%
Active compaction remaining time :   0h00m16s

nodetool gcstats returns statistics on garbage collections, 
including total number of collections and elapsed time 
(both the total and the max elapsed time). 
The counters are reset each time the command is issued, 
so the statistics correspond only to the interval between gcstats commands.

$ docker exec -it cas1 nodetool gcstats

Interval (ms)  Max GC Elapsed (ms)  Total GC Elapsed (ms)  Stdev GC Elapsed (ms)  GC Reclaimed (MB)  Collections  Direct Memory Bytes
     73540574                   64                    595                      7         3467143560           83             67661338

nodetool tpstats provides usage statistics on Cassandra’s thread pool, 
including pending tasks as well as current and historical blocked tasks.

$ docker exec -it cas1 nodetool tpstats

Pool Name                    Active   Pending      Completed   Blocked  All time blocked
ReadStage                         0         0          11801         0                 0
MutationStage                     0         0         125405         0                 0
CounterMutationStage              0         0              0         0                 0
GossipStage                       0         0              0         0                 0
RequestResponseStage              0         0              0         0                 0
AntiEntropyStage                  0         0              0         0                 0
MigrationStage                    0         0             10         0                 0
MiscStage                         0         0              0         0                 0
InternalResponseStage             0         0              0         0                 0
ReadRepairStage                   0         0              0         0                 0

The first section shows a detailed breakdown of threadpools 
for each Cassandra stage, 
including how many threads are current executing (Active) 
and how many are waiting to run (Pending). 

Typically if you see pending executions in a particular threadpool that indicates 
a problem localized to that type of operation. 

For example if the RequestResponseState queue is backing up, 
that means that the coordinators are waiting on a lot of downstream 
replica requests and may indicate a lack of token awareness, 
or very high consistency levels being used on read requests 
(for example reading at ALL ties up RF RequestResponseState threads whereas LOCAL_ONE only 
uses a single thread in the ReadStage threadpool). 

On the other hand if you see a lot of pending compactions that may indicate 
that your compaction threads cannot keep up with the volume of writes 
and you may need to tune either the compaction strategy or the concurrent_compactors 
or compaction_throughput options.

The second section shows drops (errors) and latency distributions 
for all the major request types. 
Drops are cumulative since process start, but if you have any that indicate 
a serious problem as the default timeouts to qualify as a drop are quite high 
(~5-10 seconds). 
Dropped messages often warrants further investigation


##Coordinator Query Latency
You can view latency distributions of coordinator read and write latency 
to help narrow down latency issues , use proxyhistograms, It shows 
latency distribution of reads, writes, range requests 
(e.g. select * from keyspace.table), 
CAS read (compare phase of CAS) and CAS write (set phase of compare and set). 

This is for cordinator, so, there is no 'keyspace tablename' at the end 

$ nodetool proxyhistograms

proxy histograms
Percentile      Read Latency     Write Latency     Range Latency
                  (micros)          (micros)             (micros)
50%                  1502.50            375.00               446.00
75%                  1714.75            420.00               498.00
95%                 31210.25            507.00              800.20
98%                 36365.00            577.36              948.40
99%                 36365.00            740.60             1024.39
Min                   616.00            230.00                 311.00
Max                 36365.00          55726.00          59247.00

These can be useful for narrowing down high level latency problems, 
for example in this case if a client had a 20 millisecond timeout 
on their reads they might experience the occasional 
timeout from this node but less than 1% 
(since the 99% read latency is 3.3 milliseconds < 20 milliseconds)


If you know which table is having latency/error issues, 
you can use nodetool tablehistograms (old name:cfhistograms)
to get a better idea of what is happening locally on a node, it shows 
    Read/Write Latency
    Partition Size
    Column Count
    Number of SSTable
    
Include  'keyspace tablename' at the end 

$ docker exec -ti cas1 nodetool tablehistograms 

###Cassandra Performance Metrics using JConsole -- ADVANCED 
Open Jconsole by 
$ your_JDK_install_dir/bin/jconsole

To pull up metrics in JConsole, you can select the relevant local process 
or monitor a remote process using the node’s IP address (requires JMX enabling)
(Cassandra uses port 7199 for JMX by default):

cassandra docker does not have Jconsole, hence enable JMX authentication 
(Note, any command requiring JMX is possible in local host of cassandra server 
as JMX is disabled by default for remote as this a security risk )


##Configuration for docker based cassandra 
Note:
For docker desktop, use -Djava.rmi.server.hostname=localhost
or get ip from ipconfig 
docker toolbox: Get ip for dockertoolbox eg   
from 'docker-machine ip' ie 192.168.99.100 

#file:jmxremote.password
cassandra cassandra

#file:Dockerfile  
FROM cassandra:3.11.4
ENV LOCAL_JMX no
COPY jmxremote.password /etc/cassandra/jmxremote.password
RUN chown cassandra:cassandra /etc/cassandra/jmxremote.password
RUN chmod 400 /etc/cassandra/jmxremote.password
RUN sed -i '/monitorRole   readonly/a cassandra readwrite' /etc/java-8-openjdk/management/jmxremote.access
RUN sed -i '/JVM_OPTS="$JVM_OPTS -Dcom.sun.management.jmxremote.port=$JMX_PORT/a\
\ \ JVM_OPTS="$JVM_OPTS -Djava.rmi.server.hostname=192.168.99.100"\
' /etc/cassandra/cassandra-env.sh
CMD ["cassandra", "-f"]

#Then create docker 
$ docker stop cass_cluster 
$ docker build -t cass_jmx_b .
$ docker run --name cass_jmx -p 7199:7199  -td cass_jmx_b
$ docker exec -it cass_jmx nodetool -u cassandra -pw cassandra status 

#JMX end point is 
service:jmx:rmi://192.168.99.100/jndi/rmi://192.168.99.100:7199/jmxrmi
OR 192.168.99.100:7199 with user and password 
cassandra cassandra 
(one JMX is enabled, we can also execute local nodetool 
nodetool -h 192.168.99.100 -u cassandra -pw cassandra status)


##JConsole MBeans tabs 
Opens up all the JMX paths available:

Out of the box, org.apache.cassandra.metrics 
(based on the Metrics library, https://github.com/dropwizard/metrics) 
provides almost all of the metrics that you need to monitor a Cassandra cluster. 

Prior to Cassandra 2.2, many identical or similar metrics 
were also available via alternate JMX paths 
(org.apache.cassandra.db, org.apache.cassandra.internal, etc.), 
which, while still usable in some versions, reflect an older structure 
that has been deprecated. 

Below are modern JMX paths, which mirror the JConsole interface’s 
folder structure for the key metrics described in this article:

Throughput (writes|reads) 	
    org.apache.cassandra.metrics:
    type=ClientRequest,scope=(Write|Read),name=Latency
    Attribute: OneMinuteRate
    
Latency (writes|reads)* 	
    org.apache.cassandra.metrics:
    type=ClientRequest,scope=(Write|Read),name=TotalLatency
    Attribute: Count

    org.apache.cassandra.metrics:
    type=ClientRequest,scope=(Write|Read),name=Latency
    Attribute: Count
    
Key cache hit rate* 	
    org.apache.cassandra.metrics:
    type=Cache,scope=KeyCache,name=Hits
    Attribute: Count

    org.apache.cassandra.metrics:
    type=Cache,scope=KeyCache,name=Requests
    Attribute: Count
    
Load 	
    org.apache.cassandra.metrics:
    type=Storage,name=Load
    Attribute: Count
    
Total disk space used 	
    org.apache.cassandra.metrics:
    type=ColumnFamily,keyspace=(KeyspaceName),scope=(ColumnFamilyName),name=TotalDiskSpaceUsed
    Attribute: Count
    
Completed compaction tasks 	
    org.apache.cassandra.metrics:
    type=Compaction,name=CompletedTasks
    Attribute: Value
    
Pending compaction tasks 	
    org.apache.cassandra.metrics:
    type=Compaction,name=PendingTasks
    Attribute: Value
    
ParNew garbage collections (count|time) 	
    java.lang:
    type=GarbageCollector,name=ParNew
    Attribute: (CollectionCount|CollectionTime)
    
CMS garbage collections (count|time) 	
    java.lang:
    type=GarbageCollector,name=ConcurrentMarkSweep
    Attribute: (CollectionCount|CollectionTime)
    
Exceptions 	
    org.apache.cassandra.metrics:
    type=Storage,name=Exceptions
    Attribute: Count
    
Timeout exceptions (writes|reads) 	
    org.apache.cassandra.metrics:
    type=ClientRequest,scope=(Write|Read),name=Timeouts
    Attribute: Count
    
Unavailable exceptions (writes|reads) 	
    org.apache.cassandra.metrics:
    type=ClientRequest,scope=(Write|Read),name=Unavailables
    Attribute: Count
    
Pending tasks (per stage)** 	
    org.apache.cassandra.metrics:
    type=ThreadPools,path=request,scope=(CounterMutationStage|MutationStage|ReadRepairStage|ReadStage|RequestResponseStage), name=PendingTasks
    Attribute: Value
Currently blocked tasks** 	
    org.apache.cassandra.metrics:
    type=ThreadPools,path=request,scope=(CounterMutationStage|MutationStage|ReadRepairStage|ReadStage|RequestResponseStage), name=CurrentlyBlockedTasks
    Attribute name: Count

* The metrics needed to monitor recent latency 
and key cache hit rate are available in JConsole, 
but must be calculated from two separate metrics. 

For read latency, to give an example, the relevant metrics are 
ReadTotalLatency (cumulative read latency total, in microseconds) 
and the 'Count' attribute of ReadLatency (the number of read events). 

For two readings at times 0 and 1, the recent read latency would be calculated 
from the deltas of those two metrics:

(ReadTotalLatency1−ReadTotalLatency0)/(ReadLatency1−ReadLatency0)

For key cache hit rate is simply Hits/Requests

** There are five different request stages in Cassandra, 
plus roughly a dozen internal stages, each with its own thread pool metrics


###Cassandra Performance Tuning - Main Points  
Write Operations:
    Commit log and data dirs (sstables) should be on different disks. 
    Commit log uses sequential write however, 
    if SSTables share the same drive with commit log , 
    I/O contention between commit log & SSTables may deteriorate commit log writes 
    and SSTable reads.

    # Directories where Cassandra should store data on disk.  Cassandra
    # will spread data evenly across them, subject to the granularity of
    # the configured compaction strategy.
    # If not set, the default directory is $CASSANDRA_HOME/data/data.
    # data_file_directories:
    #     - /var/lib/cassandra/data

    # commit log.  when running on magnetic HDD, this should be a
    # separate spindle than the data directories.
    # If not set, the default directory is $CASSANDRA_HOME/data/commitlog.
    # commitlog_directory: /var/lib/cassandra/commitlog

Read Operations:
    A good rule of thumb is 32 or more  concurrent_reads per processor core. 
    May increase the value for systems with fast I/O storage.
    
    # For workloads with more data than can fit in memory, Cassandra's
    # bottleneck will be reads that need to fetch data from
    # disk. "concurrent_reads" should be set to (16 * number_of_drives) in
    # order to allow the operations to enqueue low enough in the stack
    # that the OS and drives can reorder them. Same applies to
    # "concurrent_counter_writes", since counter writes read the current
    # values before incrementing and writing them back.
    #
    # On the other hand, since writes are almost never IO bound, the ideal
    # number of "concurrent_writes" is dependent on the number of cores in
    # your system; (8 * number_of_cores) is a good rule of thumb.
    concurrent_reads: 32
    concurrent_writes: 32
    concurrent_counter_writes: 32
    
Cassandra Compaction Contention:
    Reduce the frequency of memtable flush by increasing the memtable size 
    or preventing too pre-mature flushing. 
    Less frequent memtable flush results in fewer SSTables files and less compaction. 
    Fewer compaction reduces SSTables I/O contention, and therefore improves read operations. 
    Bigger memtables absorb more overwrites for updates to the same keys, 
    and therefore accommodating more read/write operations between each flushes.
    
    # Total permitted memory to use for memtables. Cassandra will stop
    # accepting writes when the limit is exceeded until a flush completes,
    # and will trigger a flush based on memtable_cleanup_threshold
    # If omitted, Cassandra will set both to 1/4 the size of the heap.
    # memtable_heap_space_in_mb: 2048
    # memtable_offheap_space_in_mb: 2048

    # memtable_cleanup_threshold is deprecated. The default calculation
    # is the only reasonable choice. See the comments on  memtable_flush_writers
    # for more information.
    #
    # Ratio of occupied non-flushing memtable size to total permitted size
    # that will trigger a flush of the largest memtable. Larger mct will
    # mean larger flushes and hence less compaction, but also less concurrent
    # flush activity which can make it difficult to keep your disks fed
    # under heavy write load.
    #
    # memtable_cleanup_threshold defaults to 1 / (memtable_flush_writers + 1)
    # memtable_cleanup_threshold: 0.11
    # This sets the number of memtable flush writer threads per disk
    # as well as the total number of memtables that can be flushed concurrently.
    # These are generally a combination of compute and IO bound.
    #
    # Memtable flushing is more CPU efficient than memtable ingest and a single thread
    # can keep up with the ingest rate of a whole server on a single fast disk
    # until it temporarily becomes IO bound under contention typically with compaction.
    # At that point you need multiple flush threads. At some point in the future
    # it may become CPU bound all the time.
    #
    # You can tell if flushing is falling behind using the MemtablePool.BlockedOnAllocation
    # metric which should be 0, but will be non-zero if threads are blocked waiting on flushing
    # to free memory.
    #
    # memtable_flush_writers defaults to two for a single data directory.
    # This means that two  memtables can be flushed concurrently to the single data directory.
    # If you have multiple data directories the default is one memtable flushing at a time
    # but the flush will use a thread per data directory so you will get two or more writers.
    #
    # Two is generally enough to flush on a fast disk [array] mounted as a single data directory.
    # Adding more flush writers will result in smaller more frequent flushes that introduce more
    # compaction overhead.
    #
    # There is a direct tradeoff between number of memtables that can be flushed concurrently
    # and flush size and frequency. More is not better you just need enough flush writers
    # to never stall waiting for flushing to free memory.
    #
    #memtable_flush_writers: 2
    
    
Memory Cache:
    Do not increase Cassandra cache size unless there is enough physical memory (RAM). 
    Avoid memory swapping at any cost.

Row Cache:
    The row cache holds the entire content of a row in memory. 
    It provides data caching instead of reading data from the disk. 
    good if column's data is small so the cache is big enough to hold most of the hotspot data. 
    Bad if column's data is too large so the cache is not big enough to hold most of the hotspot data. 
    It's bad for high write/read ratios. By default, it is off. 
    If hit ratio is below 30%, row cache should be disabled.
    
    # Maximum size of the row cache in memory.
    # Please note that OHC cache implementation requires some additional off-heap memory to manage
    # the map structures and some in-flight memory during operations before/after cache entries can be
    # accounted against the cache capacity. This overhead is usually small compared to the whole capacity.
    # Do not specify more memory that the system can afford in the worst usual situation and leave some
    # headroom for OS block level cache. Do never allow your system to swap.
    #
    # Default value is 0, to disable row caching.
    row_cache_size_in_mb: 0

    # Duration in seconds after which Cassandra should save the row cache.
    # Caches are saved to saved_caches_directory as specified in this configuration file.
    #
    # Saved caches greatly improve cold-start speeds, and is relatively cheap in
    # terms of I/O for the key cache. Row cache saving is much more expensive and
    # has limited use.
    #
    # Default is 0 to disable saving the row cache.
    row_cache_save_period: 0

    # Number of keys from the row cache to save.
    # Specify 0 (which is the default), meaning all keys are going to be saved
    # row_cache_keys_to_save: 100

Key Cache Tuning:
    The key cache holds the location of data in memory for each column family. 
    Its Effective if there are hot data spot & cannot use row cache effectively 
    because of the large column size. 
    By default, Cassandra caches 200000 keys per column family. 
    Use absolute number for keys_cached instead of percentage.

    # Maximum size of the key cache in memory.
    #
    # Each key cache hit saves 1 seek and each row cache hit saves 2 seeks at the
    # minimum, sometimes more. The key cache is fairly tiny for the amount of
    # time it saves, so it's worthwhile to use it at large numbers.
    # The row cache saves even more time, but must contain the entire row,
    # so it is extremely space-intensive. It's best to only use the
    # row cache if you have hot rows or static rows.
    #
    # NOTE: if you reduce the size, you may not get you hottest keys loaded on startup.
    #
    # Default value is empty to make it "auto" (min(5% of Heap (in MB), 100MB)). Set to 0 to disable key cache.
    key_cache_size_in_mb:

    # Duration in seconds after which Cassandra should
    # save the key cache. Caches are saved to saved_caches_directory as
    # specified in this configuration file.
    #
    # Saved caches greatly improve cold-start speeds, and is relatively cheap in
    # terms of I/O for the key cache. Row cache saving is much more expensive and
    # has limited use.
    #
    # Default is 14400 or 4 hours.
    key_cache_save_period: 14400

    # Number of keys from the key cache to save
    # Disabled by default, meaning all keys are going to be saved
    # key_cache_keys_to_save: 100

JVM:
    https://docs.datastax.com/en/cassandra-oss/3.0/cassandra/operations/opsTuneJVM.html
    Minimum and Maximum Java Heap Size should be half of available physical memory. 
    Size of young generation heap should be 1/4 of Java Heap.
     Do NOT increase the size without confirming there are enough available physical memory- 
     Always reserves memory for OS File cache.
    For example, in  jvm.options file 
    Older computers 	                                        Typically 8 GB.
    CMS for newer computers (8+ cores) with up to 256 GB RAM 	No more 16 GB.
    G1 for newer computers (8+ cores) with up to 256 GB RAM 	16 GB to 64 GB enable is by -XX:+UseG1GC
    Set the min (-Xms) and max (-Xmx) heap sizes to the same value to avoid stop-the-world GC pauses 
    -Xms48G
    -Xmx48G
    For CMS, you may also need to adjust HEAP_NEWSIZE. 
    As a starting point, set HEAP_NEWSIZE to 100 MB per physical CPU core. 
    For example, for a modern 8-core+ machine: -Xmn800M

