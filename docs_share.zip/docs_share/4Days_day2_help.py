DAY-1
    Cassandra Introduction 
        Architecture requirements 
        CQL Quick Concepts
        CQL vs SQL
        Introducing Replication in Cassandra
        Replication strategy
    Understanding CQL  
    Creating and updating a keyspace
    Creating a table
        Various type of Partition key
    Creating advanced data types in tables
        set, list, map - when to use 
        tuple and UDT 
    Creating functions
    Inserting and updating data
    Querying tables
    Setting TTL for a table and columns 
----------------------------------------------
###Creating the tuple  type
Tuples are a data type that allow two or more values to be stored together in a column. 
A user-defined type can be used, but for simple groupings, a tuple is a good choice.

Create a table cycling.route using a tuple to store each waypoint location name, latitude, and longitude.
(netsed tuple does not require to be frozen, but can not be partially updated ) 

cqlsh> CREATE TABLE IF NOT EXISTS cycling.route (race_id int, race_name text, point_id int, lat_long tuple<text, tuple<float,float>>, PRIMARY KEY (race_id, point_id));

Create a table cycling.nation_rank using a tuple to store the rank, cyclist name, 
and points total for a cyclist and the country name as the primary key.

> CREATE TABLE cycling.nation_rank ( nation text PRIMARY KEY, info tuple<int,text,int> );

The table cycling.nation_rank is keyed to the country as the primary key. 

It is possible to store the same data keyed to the rank. (RECOMMENDED as duplicates simulates join in cassandra)
Create a table cycling.popular using a tuple to store the country name, cyclist name and points total 
for a cyclist and the rank as the primary key.

> CREATE TABLE cycling.popular (rank int PRIMARY KEY, cinfo tuple<text,text,int> );

##Inserting tuple data into a table
Tuples are used to group small amounts of data together that are then stored in a column.

> INSERT INTO cycling.route (race_id, race_name, point_id, lat_long) VALUES (500, '47th Tour du Pays de Vaud', 2, ('Champagne', (46.833, 6.65)));

Insert data into the table cycling.nation_rank which has tuple data. 
The tuple is enclosed in parentheses. The tuple called info stores the rank, name, 
and point total of each cyclist.

cqlsh> INSERT INTO cycling.nation_rank (nation, info) VALUES ('Spain', (1,'Alejandro VALVERDE' , 9054));

Insert data into the table popular which has tuple data. 
The tuple called cinfo stores the country name, cyclist name, and points total.

cqlsh> INSERT INTO cycling.popular (rank, cinfo) VALUES (4, ('Italy', 'Fabio ARU', 163));

Tuples are retrieved in their entirety. This example uses AS to change the header of the tuple name.

cqlsh> SELECT race_name, point_id, lat_long AS CITY_LATITUDE_LONGITUDE FROM cycling.route;

Since cycling.popular.cinfo is not in clustering or pertion column, this can not be used for query
so create index 
> CREATE INDEX on cycling.popular (cinfo); 
> select * from cycling.popular where rank=4 AND cinfo=('Italy', 'Fabio ARU', 163);


###Creating a user-defined type (UDT)
User-defined types (UDTs) can attach multiple data fields, each named and typed, to a single column. 
The fields used to create a UDT may be any valid data type, including collections and other existing UDTs. 

Once created, UDTs may be used to define a column in a table.

cqlsh> USE cycling;

Create a user-defined type named basic_info.

cqlsh> CREATE TYPE cycling.basic_info (
  birthday timestamp,
  nationality text,
  weight text,
  height text
);

Create a table for storing cyclist data in columns of type basic_info. 

cqlsh> CREATE TABLE cycling.cyclist_stats ( id uuid PRIMARY KEY, lastname text, basics basic_info);  


##insert 
cqlsh> INSERT INTO cycling.cyclist_stats (id, lastname, basics) VALUES (
  e7ae5cf3-d358-4d99-b900-85902fda9bb0, 
  'FRAME', 
  { birthday : '1993-06-18', nationality : 'New Zealand', weight : null, height : null }
);

Note: Note the inclusion of null values for UDT elements that have no value. 
A value, whether null or otherwise, must be included for each element of the UDT.

#Updating individual field data in a UDT
In Cassandra 3.6 and later, user-defined types that include only non-collection fields can update 
individual field values. 

Update an individual field in user-defined type data using the UPDATE command. 
The desired key-value pair are defined in the command. 
In order to update, the UDT must be defined in the CREATE TABLE command as an unfrozen data type.

> INSERT INTO cycling.cyclist_stats (id, lastname, basics) 
    VALUES (220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO', { birthday:'1977-07-08',nationality:'Italy',weight:'63 kg',height:'1.78 m' });
> UPDATE cyclist_stats SET basics.birthday = '2000-12-12' WHERE id = 220844bf-4860-49d6-9a4b-6b5d3a79cbfb;

> SELECT * FROM cycling.cyclist_stats WHERE id = 220844bf-4860-49d6-9a4b-6b5d3a79cbfb;

 id                                   | basics                                                                                                 | lastname
--------------------------------------+--------------------------------------------------------------------------------------------------------+-----------
 220844bf-4860-49d6-9a4b-6b5d3a79cbfb | {birthday: '2000-12-12 08:00:00.000000+0000', nationality: 'Italy', weight: '63 kg', height: '1.78 m'} | TIRALONGO

The resulting change is evident, as is the unchanged values for nationality, weight, and height.

Note: UDTs with collection fields must be frozen in table creation, and individual field values cannot be updated.
The frozen keyword is not required for UDTs that contain only non-collection fields.

When using the frozen keyword, you cannot update parts of a user-defined type value. 
The entire value must be overwritten. Cassandra treats the value of a frozen, user-defined type like a blob.

cqlsh> CREATE TABLE cycling.cyclist_stats_f ( id uuid PRIMARY KEY, lastname text, basics FROZEN<basic_info>);  

A user-defined type can be nested in another column type(here frozen is must).
 This example nests a UDT in a list.

cqlsh> CREATE TYPE cycling.race (race_title text, race_date timestamp, race_time text);
cqlsh> CREATE TABLE cycling.cyclist_races ( id UUID PRIMARY KEY, lastname text, firstname text, races list<FROZEN <race>> );

Data can be inserted into a UDT that is nested in another column type. 
For example, a list of races, where the race name, date, and time are defined in a UDT has elements 
enclosed in curly brackets that are in turn enclosed in square brackets.

cqlsh> INSERT INTO cycling.cyclist_races (id, lastname, firstname, races) VALUES (
  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,
  'VOS',
  'Marianne',
  [{ race_title : 'Rabobank 7-Dorpenomloop Aalburg',race_date : '2015-05-09',race_time : '02:58:33' },
  { race_title : 'Ronde van Gelderland',race_date : '2015-04-19',race_time : '03:22:23' }]
);

Note: The UDT nested in the list is frozen, so the entire list will be read when querying the table.

cqlsh> select * from  cycling.cyclist_races;

##Altering a user-defined type

cqlsh> CREATE TYPE cycling.fullname (firstname text, lastname text);

cqlsh> CREATE TABLE cycling.new_names ( id UUID PRIMARY KEY, name cycling.fullname );

> INSERT INTO cycling.new_names (id, name) VALUES (
  e7ae5cf3-d358-4d99-b900-85902fda9bb0, 
  { firstname : 'many', lastname : 'names' }
);

Add a middlename column of type text to the user-defined type cycling.fullname.

cqlsh> ALTER TYPE cycling.fullname ADD middlename text;

This creates the column metadata and adds the column to the type schema. 

> select * from system_schema.types;

A column can be renamed in either ALTER TABLE or ALTER TYPE. 
In ALTER TABLE, only primary key columns may be renamed.

cqlsh> ALTER TYPE cycling.fullname RENAME middlename TO middleinitial;

#check 
> select * from cycling.new_names;

 id                                   | name
--------------------------------------+-------------------------------------------------------------
 e7ae5cf3-d358-4d99-b900-85902fda9bb0 | {firstname: 'many', lastname: 'names', middleinitial: null}
 
#Cassandra 3.6 
> UPDATE  cycling.new_names SET name.middleinitial='empty' where id = e7ae5cf3-d358-4d99-b900-85902fda9bb0;




###Understanding CQL functions  
https://cassandra.apache.org/doc/latest/cassandra/cql/functions.html

Note: 
Timestamp also supports upserting the value as an integer. 
The integer is the number of milliseconds after the Unix epoch (January 1, 1970).

Use them formats in INSERT and UPDATE statements. 
Example 
time eg '13:30:54.234', HH:MM:SS[.fff]
timestamp  eg '2015-05-03 13:30:54.234' , '2011-02-03' , 'yyyy-mm-dd'T'HH:mm:ssZ'
date eg '2011-12-25'  , yyyy-mm-dd
Check for detail 
https://docs.datastax.com/en/dse/5.1/cql/cql/cql_reference/refDateTimeFormats.html
Driver client would convert them to appropriate eg java.sql
For cqlsh uses ~/.cassandra/cqlshrc and the default format 
;; Used for displaying timestamps (and reading them with COPY)
; datetimeformat = %Y-%m-%d %H:%M:%S%z




uuid() 
    generates a random type 4 uuid
now()
    includes the time of its generation and are sorted by timestamp, 
    making them ideal for use in applications requiring conflict-free timestamps
    
    
#Function name 	        Output type
currentTimestamp        timestamp
currentDate             date
currentTime             time
currentTimeUUID/now     timeUUID

#Function name 	Input type 	Description
toDate          timeuuid    Converts the timeuuid argument into a date type
toDate          timestamp   Converts the timestamp argument into a date type
toTimestamp     timeuuid    Converts the timeuuid argument into a timestamp type
toTimestamp     date        Converts the date argument into a timestamp type
toUnixTimestamp timeuuid    Converts the timeuuid argument into a bigInt raw value
toUnixTimestamp timestamp   Converts the timestamp argument into a bigInt raw value
toUnixTimestamp date        Converts the date argument into a bigInt raw value
dateOf          timeuuid    Similar to toTimestamp(timeuuid) (DEPRECATED)
unixTimestampOf timeuuid    Similar to toUnixTimestamp(timeuuid) (DEPRECATED)

#Example 
CREATE TABLE cycling.myTable (
    userid text PRIMARY KEY,
    username text,
    mydate date,  
    mytimestamp timestamp,
    mytime time, 
    myuuid  uuid ,
    mytimeuuid timeuuid,    
    count int
);
INSERT INTO myTable (userid, username, mydate, mytimestamp, mytime, myuuid, mytimeuuid, count) 
    VALUES ( 'abc-123', 'dummy user', currentDate(), currentTimestamp(), currentTime(), uuid(), now(), 2);

INSERT INTO myTable (userid, username, mydate, mytimestamp, mytime, myuuid, mytimeuuid, count) 
    VALUES ( 'xyz-123', 'dummy user2', '2011-02-03', '2015-05-03 13:30:54.234', '13:30:54.234', 5b6962dd-3f90-4c93-8f61-eabfa4a803e2, now(), 2);
    
#others are null
INSERT INTO myTable (userid, username, count) 
    VALUES ( 'xyz-1234', 'dummy user3', 2);
       
cqlsh> SELECT * FROM myTable;
 userid   | count | mydate     | mytime             | mytimestamp                     | mytimeuuid                           | myuuid                               | username
----------+-------+------------+--------------------+---------------------------------+--------------------------------------+--------------------------------------+-------------
  abc-123 |     2 | 2021-08-30 | 10:12:31.447377000 | 2021-08-30 10:12:31.446000+0000 | c997c670-097a-11ec-97f1-3b0edd44b0ae | 64d58408-545c-425d-93c5-43d4f53c6a8b |  dummy user
 xyz-1234 |     2 |       null |               null |                            null |          null                        |                                 null | dummy user3
  xyz-123 |     2 | 2011-02-03 | 13:30:54.234000000 | 2015-05-03 13:30:54.234000+0000 | db6210e0-097a-11ec-97f1-3b0edd44b0ae | 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 | dummy user2
   
cqlsh> select toDate(mytimeuuid), toTimestamp(mytimeuuid) from myTable where userid='abc-123';

 system.todate(mytimeuuid) | system.totimestamp(mytimeuuid)
---------------------------+---------------------------------
                2021-08-30 | 2021-08-30 10:12:31.447000+0000

##Understanding cast 
https://cassandra.apache.org/doc/latest/cassandra/cql/functions.html#cast
cqlsh> SELECT avg(cast(count as double)) FROM myTable;

 system.avg(cast(count as double))
-----------------------------------
                                 2

#datetime function 
For example the last two days of data can be retrieved using:
create index on myTable (mydate);
#Ny/mo/w/d/h/m/s - If h/m/s included , use currentTimestamp/currentTime
SELECT * FROM myTable WHERE mydate >= currentDate() - 2d allow filtering;
SELECT * FROM myTable WHERE mytimestamp >= currentTimestamp() - 1s allow filtering;





###Inserting JSON data into a table
For JSON data all values will be inserted as a string if they are not a number, 
but will be stored using the column data type. 

For example, the id below is inserted as a string, but is stored as a UUID. 

To insert JSON data, add JSON to the INSERT command.. Note the absence of the keyword VALUES 
and the list of columns that is present in other INSERT commands.

cqlsh> INSERT INTO cycling.cyclist_category JSON '{
  "category" : "GC", 
  "points" : 780, 
  "id" : "829aa84a-4bba-411f-a4fb-38167a987cda",
  "lastname" : "SUTHERLAND" }';
  

A null value will be entered if a defined column like lastname, is not inserted into a table using JSON format.

cqlsh> INSERT INTO cycling.cyclist_category JSON '{
  "category" : "Sprint", 
  "points" : 700, 
  "id" : "829aa84a-4bba-411f-a4fb-38167a987cda"
}';

Check cassandra datatype vs json format below 
(eg most of CQL data type accept string json value and list/tuple/set accept json list)
https://cassandra.apache.org/doc/latest/cassandra/cql/json.html

To get json 
> SELECT JSON * FROM cycling.cyclist_category ;



###Using lightweight transactions
INSERT and UPDATE statements using the IF clause support lightweight transactions, 
also known as Compare and Set (CAS). (ie check exists and then update- atomic)

A common use for lightweight transactions is an insertion operation that must be unique, 
such as a cyclist's identification. 

Lightweight transactions should not be used casually, as the latency of operations increases fourfold 
due to the due to the round-trips necessary between the CAS coordinators.

Cassandra supports non-equal conditions for lightweight transactions. 
You can use <, <=, >, >=, != and IN operators in WHERE clauses to query lightweight tables.

It is important to note that using IF NOT EXISTS on an INSERT, the timestamp will be designated 
by the lightweight transaction, and USING TIMESTAMP is prohibited.

Insert a new cyclist with their id.

cqlsh> INSERT INTO cycling.cyclist_name (id, lastname, firstname)
  VALUES (4647f6d3-7bd2-4085-8d6c-1229351b5498, 'KNETEMANN', 'Roxxane')
  IF NOT EXISTS;

Perform a CAS operation against a row that does exist by adding the predicate for the operation 
at the end of the query. For example, reset Roxane Knetemann's firstname because of a spelling error.

cqlsh> UPDATE cycling.cyclist_name
  SET firstname = 'Roxane'
  WHERE id = 4647f6d3-7bd2-4085-8d6c-1229351b5498
  IF firstname = 'Roxxane'; //can Use <, <=, >, >=, != and IN



###Expiring data with time-to-live
Columns and tables support an optional expiration period called TTL (time-to-live); 
TTL is not supported on counter columns. 

##Define the TTL value in seconds. 
Data expires once it exceeds the TTL period and is then marked with a tombstone. 
Expired data continues to be available for read requests during the grace period, see conf:gc_grace_seconds. 

Normal compaction and repair processes automatically remove the tombstone data.

TTL precision is one second, which is calculated by the coordinator node. 
When using TTL, ensure that all nodes in the cluster have synchronized clocks.

A very short TTL is not very useful.

Expiring data uses additional 8 bytes of memory and disk space to record the TTL and grace period.

##Setting a TTL for a specific column
Use CQL to set the TTL.

To change the TTL of a specific column, you must re-insert the data with a new TTL. 
Cassandra upserts the column with the new TTL.

To remove TTL from a column, set TTL to zero. 

##Setting a TTL for a table
Use CREATE TABLE or ALTER TABLE to define the default_time_to_live property for all columns in a table. 
If any column exceeds TTL, the entire table is tombstoned.

>> CREATE TABLE [IF NOT EXISTS] keyspace_name.table_name ( 
   column_definition [, ...]
   PRIMARY KEY (column_name [, column_name ...])
WITH default_time_to_live = 0 ; //0 (disabled),max = 630720000 (20 years)

To set the TTL for data(one row), use the 'USING TTL seconds 'keywords. 
The TTL function may be used to retrieve the TTL information.

Insert data into the table cycling.calendar and use the USING TTL clause to set the expiration period 
to 86400 seconds(24 hours)

The following statement sets TTL for an entire row.

cqlsh> INSERT INTO cycling.calendar (race_id, race_name, race_start_date, race_end_date) 
    VALUES (200, 'placeholder','2015-05-27', '2015-05-27') USING TTL 86400;

Issue a SELECT statement to determine how much longer the data has to live.

cqlsh> SELECT TTL (race_name) from cycling.calendar WHERE race_id = 200;

If you repeat this step after some time, the time-to-live value will decrease.


The time-to-live value can also be updated with the USING TTL keywords in an UPDATE command.
Extend the expiration period to three days (259200 seconds) by using the UPDATE command 
with the USING TTL keyword. Also set the race name.

The following statement sets TTL for a single cell.

cqlsh> UPDATE cycling.calendar USING TTL 259200 
  SET race_name = 'Tour de France - Stage 12' 
  WHERE race_id = 200 AND race_start_date = '2015-05-27' AND race_end_date = '2015-05-27';


cqlsh> SELECT TTL (race_name) from cycling.calendar WHERE race_id = 200;


Delete a column's existing TTL by setting its value to zero.

cqlsh> UPDATE cycling.calendar USING TTL 0 
  SET race_name = 'Tour de France - Stage 12' 
  WHERE race_id = 200 AND race_start_date = '2015-05-27' AND race_end_date = '2015-05-27';


cqlsh> SELECT TTL (race_name) from cycling.calendar WHERE race_id = 200;

 ttl(race_name)
----------------
           null


###Inserting data using COPY and a CSV file
A comma-delimited file, or CSV file, is useful if several records need inserting. 
While not strictly an INSERT command, it is a common method for inserting data.


#cyclist_category.csv
category|point|id|lastname
GC|1269|829aa84a-4bba-411f-a4fb-38167a987cdb|TIRALONGO
One-day-races|367|829aa84a-4bba-411f-a4fb-38167a987cdc|TIRALONGO
GC|1324|829aa84a-4bba-411f-a4fb-38167a987cdd|KRUIJSWIJK

Check table 
cqlsh>  describe cycling.cyclist_category;

To insert the data, using the COPY command with CSV data.

cqlsh>  COPY cycling.cyclist_category FROM 'cyclist_category.csv' WITH DELIMITER='|' AND HEADER=TRUE;
Verify the new rows
cqlsh> select * from cycling.cyclist_category;

To export data 
cqlsh>  COPY cycling.cyclist_category TO 'cyclist_category2.csv' WITH HEADER = TRUE;


###HandsON  

Create the cycling.cyclist_name_handson table:
  id UUID 
  lastname text
  firstname text 
    and PK is id 

Insert data into cycling.cyclist_name_handson:

5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'


Export only the id and lastname columns from the cyclist_name table to a CSV file:

Copy the id and firstname to a different CSV file named cyclist_firstname.csv:

Remove all records from the cyclist name table:

Verify that there are no rows:

Import the cyclist first names:

Verify the new rows:

Import the last names:

Verify the that the records were updated:

Clear the data from the cyclist_name_handson table

##Further 
Start the copy input operation using the FROM STDIN option:

> COPY cycling.cyclist_name_handson FROM STDIN;

The line prompt changes to [copy]:

Using 7 child processes
              
Starting copy of cycling.cyclist_name with columns [id, firstname, lastname].
[Use . on a line by itself to end input]
[copy] e7cd5752-bc0d-4157-a80f-7523add8dbcd,Anna,VAN DER BREGGEN
[copy] .

Press Enter after the period:


Run this query to view the contents of the cyclist_name table:

> SELECT * FROM cycling.cyclist_name_handson;

 id                                   | firstname | lastname
--------------------------------------+-----------+-----------------
 e7cd5752-bc0d-4157-a80f-7523add8dbcd |      Anna | VAN DER BREGGEN
  
(1 rows)


###Details of Querying tables
https://docs.datastax.com/en/cql-oss/3.3/cql/cql_using/useQueryDataTOC.html

SELECT * | select_expression | DISTINCT partition 
FROM [keyspace_name.] table_name 
[WHERE partition_value
   [AND clustering_filters 
   [AND static_filters]]] 
[ORDER BY PK_column_name ASC|DESC] 
[LIMIT N]
[ALLOW FILTERING]

DISTINCT partition_key ,Use a comma separate list 

select_expression = * | aggregate(arguments) | function(arguments) 	| column_name AS alias_name etc 

partition_value (mention all partition keys in compound, clustering columns optional)
    Simple partition key, select a single partition:
    partition_column = value
    Simple partition key, select multiple partitions:
    partition_column IN(value1,value2[,...])
    For compound partition keys, create a condition for each key separated by AND:
    partition_column1 = value1  AND partition_column2 = value2 [AND ...])

clustering_filters (Only clustering columns(or any seperate indexed column) is used for filtering)
    clustering_column_name operator term
        | ( clustering_column_name [, clustering_column_name . . . ) operator term-tuple 
        | clustering_column_name IN ( term , term [,  term ] . . .] 
        | ( clustering_column_name, [, clustering_column_name] . . . ) IN term-tuple [, term-tuple] . . . )

operator is = | < | > | <= | >= | CONTAINS | CONTAINS KEY (NOT SEEN***)

term-tuple is  ( term, term, ... )  

term
    set 	
    { literal [, ...] }
    list 	
    [literal [, ...] ]
    map 	
    { key : value [, ...] }
   





###Retrieval using standard aggregate functions
The standard aggregate functions of min, max, avg, sum, and count are built-in functions.

A table cyclist_points records the race points for cyclists.

cqlsh>  CREATE TABLE IF NOT EXISTS cycling.cyclist_points (
  id UUID, 
  race_points int, 
  firstname text, 
  lastname text, 
  race_title text, 
  PRIMARY KEY (id, race_points)
);

>  INSERT INTO cycling.cyclist_points (
  id, race_points, firstname, lastname, race_title
) VALUES (
  e3b19ec4-774a-4d1c-9e5a-decec1e30aac, 6, 'Giorgia', 'BRONZINI', 'Trofeo Alfredo Binda - Commune di Cittiglio'
);

INSERT INTO cycling.cyclist_points (
  id, race_points, firstname, lastname, race_title
) VALUES (
  e3b19ec4-774a-4d1c-9e5a-decec1e30aac, 75, 'Giorgia', 'BRONZINI', 'Act van Westerveld'
);

INSERT INTO cycling.cyclist_points (
  id, race_points, firstname, lastname, race_title
) VALUES (
  e3b19ec4-774a-4d1c-9e5a-decec1e30aac, 120, 'Giorgia', 'BRONZINI', 'Tour of Chongming Island World Cup'
);

Calculate the standard aggregation function sum to find the sum of race points for a particular cyclist. 
The value of the aggregate will be returned.

cqlsh> SELECT sum(race_points) as sum, max(race_points), min(race_points), avg(race_points) FROM cycling.cyclist_points WHERE id=e3b19ec4-774a-4d1c-9e5a-decec1e30aac;

Another standard aggregate function is count. 
A table country_flag records the country of each cyclist.

cqlsh> CREATE TABLE cycling.country_flag (country text, cyclist_name text, flag int STATIC, PRIMARY KEY (country, cyclist_name));

>  INSERT INTO cycling.country_flag (country, cyclist_name, flag) VALUES ('Belgium', 'Jacques', 1);
INSERT INTO cycling.country_flag (country, cyclist_name) VALUES ('Belgium', 'Andre');
INSERT INTO cycling.country_flag (country, cyclist_name, flag) VALUES ('France', 'Andre', 2);
INSERT INTO cycling.country_flag (country, cyclist_name, flag) VALUES ('France', 'George', 3);

Calculate the standard aggregation function count to find the number of cyclists from Belgium. 
The value of the aggregate will be returned.

cqlsh> SELECT count(cyclist_name) FROM cycling.country_flag WHERE country='Belgium';

This example returns the number of rows in the users table:

SELECT COUNT(*)  FROM cycling.cyclist_name;


###Retrieving the date/time a write occurred
The WRITETIME function applied to a column returns the date/time in microseconds 
at which the column was written to the database.

For example, to retrieve the date/time that a write occurred to the first_name column of the user 
whose last name is Jones:

> select table_name from system_schema.tables;
> describe table cyclist_stats;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;

 writetime(firstname)
----------------------
     1622470237412000
     1622470237312000
     1622470237371000
     1622470237391000
     1622470237332000
     
     
The WRITETIME output in microseconds converts to November 15, 2012 at 12:16:34 GMT-8.
Note CQL timestamp 	is Date  with millisecond precision from EPOCH 

*** To use user-defined functions with Java or Javascript, enable_user_defined_functions must be set true 
in the cassandra.yaml file setting to enable the functions. 
$ vi /etc/cassandra/cassandra.yaml 

#Include some error, then it displays the generated code eg input is converted to java.util.Date 
#can not include System.out.println(input); include and se the generated code 
> CREATE OR REPLACE FUNCTION toString (input timestamp) CALLED ON NULL INPUT RETURNS text 
    LANGUAGE java AS 
    $$
        long wrong_epoch = input.getTime();
        java.util.Date cdate = new java.util.Date((long)wrong_epoch/1000);
        return cdate.toString();
    $$;
    
    
> SELECT toString(WRITETIME (lastname ))  FROM cycling.cyclist_stats ;
 cycling.tostring(writetime(lastname))
---------------------------------------
          Tue Jan 18 09:53:32 UTC 2022
          Tue Jan 18 09:53:39 UTC 2022
          
Cassandra server date and time is Jan18 
check with $ date command         
          

Note By default WRITETIME is the SYSTEM time or we can change it with USING TIMESTAMP epoch_in_microseconds 
> INSERT INTO cycling.cyclist_stats (id, lastname, basics) VALUES (
  e7ae5cf3-d358-4d99-b900-85902fda9bb1, 
  'FRAME2', 
  { birthday : '1993-06-18', nationality : 'New Zealand', weight : null, height : null }
) USING  TIMESTAMP 123456789;  //both TTL and TIMESTAMP // USING TTL 86400 AND TIMESTAMP 123456789;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;
writetime(lastname)
--------------------
          123456789
   1642499612808883
   1642499619689346
   
Unlike the INSERT command, the UPDATE command supports counters. 
Otherwise, the UPDATE and INSERT operations are identical.

> UPDATE cycling.cyclist_stats USING TIMESTAMP 123456799
    SET lastname = 'FRAME3'
        WHERE id = e7ae5cf3-d358-4d99-b900-85902fda9bb1;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;

###Querying a system table  
The system keyspace includes a number of tables that contain details 
about your Cassandra database objects  and cluster configuration.

Cassandra populates these tables and others in the 'system' keyspace.

#Table name 	    Column name 	Comment
available_ranges 	keyspace_name, ranges 	
batches 	        id, mutations, version 	
batchlog 	        id, data, version, written_at 	
built_views 	    keyspace_name, view_name 	Information on materialized views
compaction_history 	id, bytes_in, bytes_out, columnfamily_name, compacted_at, keyspace_name, rows_merged 	Information on compaction history
hints 	            target_id, hint_id, message_version, mutation 	
"IndexInfo" 	    table_name, index_name 	Information on indexes
local 	            key, bootstrapped, broadcast_address, cluster_name, cql_version, data_center, gossip_generation, host_id, listen_address, native_protocol_version, partitioner, rack, release_version, rpc_address, schema_version, thrift_version, tokens, truncated_at map 	Information on a node has about itself and a superset of gossip.
paxos 	            row_key, cf_id, in_progress_ballot, most_recent_commit, most_recent_commit_at, most_recent_commit_version, proposal, proposal_ballot, proposal_version 	Information on lightweight Paxos transactions
peers 	            peer, data_center, host_id, preferred_ip, rack, release_version, rpc_address, schema_version, tokens 	Each node records what other nodes tell it about themselves over the gossip.
peer_events 	    peer, hints_dropped 	
range_xfers 	    token_bytes,requested_at 	
size_estimates 	    keyspace_name, table_name, range_start, range_end, mean_partition_size, partitions_count 	Information on partitions
sstable_activity 	keyspace_name, columnfamily_name, generation, rate_120m, rate_15m 	
views_builds_in_progress 	keyspace_name, view_name, generation_number, last_token 	


Cassandra populates these tables in the 'system_schema' keyspace.
#Tables Table name 	Column name 	Comment
aggregates 	        keyspace_name, aggregate_name, argument_types, final_func, initcond, return_type, state_func, state_type 	Information about user-defined aggregates
columns 	        keyspace_name, table_name, column_name, clustering_order, column_name_bytes, kind, position, type 	Information about table columns
dropped_columns 	keyspace_name, table_name, column_name, dropped_time,type 	Information about dropped columns
functions 	        keyspace_name, function_name, argument_types, argument_names, body, called_on_null_input,language,return_type 	Information on user-defined functions
indexes 	        keyspace_name, table_name, index_name, kind,options 	Information about indexes
keyspaces 	        keyspace_name, durable_writes, replication 	Information on keyspace durable writes and replication
tables 	            keyspace_name, table_name, bloom_filter_fp_chance, caching, comment, compaction, compression, crc_check_chance, dclocal_read_repair_chance, default_time_to_live, extensions, flags, gc_grace_seconds, id, max_index_interval, memtable_flush_period_in_ms, min_index_interval, read_repair_chance, speculative_retry 	Information on columns and column indexes. Used internally for compound primary keys.
triggers 	        keyspace_name, table_name, trigger_name, options 	Information on triggers
types 	            keyspace_name, type_name, field_names, field_types 	Information about user-defined types
views 	            keyspace_name, view_name, base_table_id, base_table_name, bloom_filter_fp_chance, caching, comment, compaction, compression, crc_check_chance, dclocal_read_repair_chance, default_time_to_live, extensions, flags,gc_grace_seconds, include_all_columns, max_index_interval, memtable_flush_period_in_ms, min_index_interval, read_repair_chance, speculative_retry, where_clause 	Information about 

##Keyspace, table, and column information
Query the defined keyspaces using the SELECT statement.

cqlsh> SELECT * FROM system_schema.keyspaces;

 keyspace_name      | durable_writes | replication
--------------------+----------------+-------------------------------------------------------------------------------------
            cycling |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '1'}
               test |           True | {'Cassandra': '1', 'class': 'org.apache.cassandra.locator.NetworkTopologyStrategy'}
        system_auth |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '1'}
      system_schema |           True |  {'class': 'org.apache.cassandra.locator.LocalStrategy'}
          keyspace1 |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '2'}
 system_distributed |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '3'}
             system |           True |                             {'class': 'org.apache.cassandra.locator.LocalStrategy'}
      system_traces |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '2'}

(15 rows)

Get the schema information for tables in the cycling keyspace.

cqlsh> EXPAND ON; 
SELECT * FROM system_schema.tables  WHERE keyspace_name = 'cycling';

The following results shows the first record formatted with the cqlsh cqlshExpand ON option.

@ Row 1
-----------------------------+---------------------------------------------------------------------------------------------------------------------------
 keyspace_name               | cycling
 table_name                  | birthday_list
 bloom_filter_fp_chance      | 0.01
 caching                     | {'keys': 'ALL', 'rows_per_partition': 'NONE'}
 cdc                         | null
 comment                     |
 compaction                  | {'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold': '32', 'min_threshold': '4'}
 compression                 | {'chunk_length_in_kb': '64', 'class': 'org.apache.cassandra.io.compress.LZ4Compressor'}
 crc_check_chance            | 1
 dclocal_read_repair_chance  | 0.1
 default_time_to_live        | 0
 extensions                  | {'RLACA': 0x6379636c6973745f6e616d65} 
 flags                       | {'compound'}
 gc_grace_seconds            | 864000
 id                          | e439b922-2bc5-11e8-891b-23da85222d3d
 max_index_interval          | 2048
 memtable_flush_period_in_ms | 0
 min_index_interval          | 128
 nodesync                    | null
 read_repair_chance          | 0
 speculative_retry           | 99PERCENTILE
...

Get details about a table's columns from system_schema.columns.

cqlsh> 
SELECT * FROM system_schema.columns 
WHERE keyspace_name = 'cycling' AND table_name = 'cyclist_name';

 keyspace_name | table_name   | column_name | clustering_order | column_name_bytes    | kind          | position | type
---------------+--------------+-------------+------------------+----------------------+---------------+----------+------
       cycling | cyclist_name |   firstname |             none | 0x66697273746e616d65 |       regular |       -1 | text
       cycling | cyclist_name |          id |             none |               0x6964 | partition_key |        0 | uuid
       cycling | cyclist_name |    lastname |             none |   0x6c6173746e616d65 |       regular |       -1 | text

(3 rows)

Note: The system_schema table does NOT show search index or row-level access control settings.


##Cluster information
(No CLuster in our case) 
cqlsh> SELECT * FROM system.peers;

Output from querying the peers table looks something like this:

peer    | data_center | host_id     | preferred_ip | rack  | release_version | rpc_address | schema_version | tokens
-----------+-------------+-------------+--------------+-------+-----------------+-------------+----------------+-----------
127.0.0.3 | datacenter1 | edda8d72... |         null | rack1 |           2.1.0 | 127.0.0.3   | 59adb24e-f3... |  {3074...
127.0.0.2 | datacenter1 | ef863afa... |         null | rack1 |           2.1.0 | 127.0.0.2   | 3d19cd8f-c9... | {-3074...}
                    
(2 rows)

##Functions, aggregates, and user types
Show all user-defined functions in the system.schema_functions table.

cqlsh> SELECT * FROM system_schema.functions;

Show all user-defined aggregates in the system.schema_aggregates table.

cqlsh> SELECT * FROM system_schema.aggregates;

Show all user-defined types in the system.schema_usertypes table.

cqlsh> SELECT * FROM system_schema.types;



