###Creating the tuple  type
Dissimilar data types , Use for low cardinality data 
(netsed tuple does not require to be frozen, but can not be partially updated ) 

cqlsh> CREATE TABLE IF NOT EXISTS cycling.route 
    (race_id int, race_name text, point_id int, 
    lat_long tuple<text, tuple<float,float>>, PRIMARY KEY (race_id, point_id));

> CREATE TABLE cycling.nation_rank 
    ( nation text PRIMARY KEY, info tuple<int,text,int> );

It is possible to store the same data keyed to the rank. 
(RECOMMENDED as duplicates simulates join in cassandra--DATAMODEL )

> CREATE TABLE cycling.popular 
    (rank int PRIMARY KEY, cinfo tuple<text,text,int> );

##Inserting tuple data into a table
> INSERT INTO cycling.route (race_id, race_name, point_id, lat_long) 
    VALUES (500, '47th Tour du Pays de Vaud', 2, ('Champagne', (46.833, 6.65)));

cqlsh> INSERT INTO cycling.nation_rank (nation, info) 
    VALUES ('Spain', (1,'Alejandro VALVERDE' , 9054));

cqlsh> INSERT INTO cycling.popular (rank, cinfo) 
    VALUES (4, ('Italy', 'Fabio ARU', 163));

Tuples are retrieved in their entirety. 
This example uses AS to change the header of the tuple name.

cqlsh> SELECT race_name, point_id, lat_long AS CITY_LATITUDE_LONGITUDE 
    FROM cycling.route;

Since cycling.popular.cinfo is not in clustering or pertion column, 
this can not be used for query so create index -SECONDARY INDEX 

> CREATE INDEX on cycling.popular (cinfo); 
> select * from cycling.popular 
    where rank=4 AND cinfo=('Italy', 'Fabio ARU', 163);


###Creating a user-defined type (UDT)
(named tupled)

cqlsh> CREATE TYPE cycling.basic_info (
  birthday timestamp,
  nationality text,
  weight text,
  height text
);

cqlsh> CREATE TABLE cycling.cyclist_stats 
    ( id uuid PRIMARY KEY, lastname text, basics basic_info);  


##insert 
cqlsh> INSERT INTO cycling.cyclist_stats 
    (id, lastname, basics) VALUES (
      e7ae5cf3-d358-4d99-b900-85902fda9bb0, 
      'FRAME', 
      { birthday : '1993-06-18', nationality : 'New Zealand', weight : null, height : null }
    );

Note: Note the inclusion of null values for UDT elements that have no value. 
A value, whether null or otherwise, must be included for each element of the UDT.

##Updating individual field data in a UDT
In Cassandra 3.6 and later, user-defined types 
that include only non-collection fields can update individual field values. 
(use udt.field) 

> INSERT INTO cycling.cyclist_stats (id, lastname, basics) 
    VALUES (220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 
    'TIRALONGO', { birthday:'1977-07-08',nationality:'Italy', 
    weight:'63 kg',height:'1.78 m' });
    
> UPDATE cyclist_stats 
    SET basics.birthday = '2000-12-12' 
    WHERE id = 220844bf-4860-49d6-9a4b-6b5d3a79cbfb;

> SELECT * FROM cycling.cyclist_stats 
    WHERE id = 220844bf-4860-49d6-9a4b-6b5d3a79cbfb;

 id                                   | basics                                                                                                 | lastname
--------------------------------------+--------------------------------------------------------------------------------------------------------+-----------
 220844bf-4860-49d6-9a4b-6b5d3a79cbfb | {birthday: '2000-12-12 08:00:00.000000+0000', nationality: 'Italy', weight: '63 kg', height: '1.78 m'} | TIRALONGO

Note: UDTs with collection fields must be frozen in table creation, 
and individual field values cannot be updated.

When using the frozen keyword, you cannot update parts of a user-defined type value.
The entire value must be overwritten. 
Cassandra treats the value of a frozen, user-defined type like a blob.

cqlsh> CREATE TABLE cycling.cyclist_stats_f 
    ( id uuid PRIMARY KEY, lastname text, basics FROZEN<basic_info>);  

A user-defined type can be nested in another column type(here frozen is must).

cqlsh> CREATE TYPE cycling.race 
    (race_title text, race_date timestamp, race_time text);
    
cqlsh> CREATE TABLE cycling.cyclist_races 
    ( id UUID PRIMARY KEY, lastname text, firstname text, 
    races list<FROZEN <race>> );

Data can be inserted into a UDT that is nested in another column type. 

For example, a list of races, where the race name, date, 
and time are defined in a UDT has elements enclosed in curly brackets 
that are in turn enclosed in square brackets.

cqlsh> INSERT INTO cycling.cyclist_races 
    (id, lastname, firstname, races) VALUES (
  5b6962dd-3f90-4c93-8f61-eabfa4a803e2,
  'VOS',
  'Marianne',
  [{ race_title : 'Rabobank 7-Dorpenomloop Aalburg',
    race_date : '2015-05-09',race_time : '02:58:33' },
  { race_title : 'Ronde van Gelderland',
    race_date : '2015-04-19',race_time : '03:22:23' }]
);

Note: The UDT nested in the list is frozen, so the entire list 
will be read when querying the table.

cqlsh> select * from  cycling.cyclist_races;



##Altering a user-defined type
(datatype for existing field can not be changed)

cqlsh> CREATE TYPE cycling.fullname (firstname text, lastname text);

cqlsh> CREATE TABLE cycling.new_names 
    ( id UUID PRIMARY KEY, name cycling.fullname );

> INSERT INTO cycling.new_names (id, name) 
VALUES (
  e7ae5cf3-d358-4d99-b900-85902fda9bb0, 
  { firstname : 'many', lastname : 'names' }
);

Add a middlename column of type text to the user-defined type cycling.fullname.

cqlsh> ALTER TYPE cycling.fullname ADD middlename text;

This creates the column metadata and adds the column to the type schema. 

> select * from system_schema.types;

A column can be renamed in either  ALTER TYPE. 

cqlsh> ALTER TYPE cycling.fullname RENAME middlename TO middleinitial;

#check 
> select * from cycling.new_names;

 id                                   | name
--------------------------------------+-------------------------------------------------------------
 e7ae5cf3-d358-4d99-b900-85902fda9bb0 | {firstname: 'many', lastname: 'names', middleinitial: null}
 
#Cassandra 3.6 
> UPDATE  cycling.new_names SET name.middleinitial='empty' 
    where id = e7ae5cf3-d358-4d99-b900-85902fda9bb0;




###Understanding CQL functions  
https://cassandra.apache.org/doc/latest/cassandra/cql/functions.html

Note CQL does not have many functions 
    scalar functions that take a number of values and produce an output
    aggregate functions that aggregate multiple rows resulting 
        from a SELECT statement

Timestamp and time format 
    Timestamp(not time) also supports upserting the value as an integer. 
    The integer is the number of milliseconds after the Unix epoch (January 1, 1970).

    Use them formats in INSERT and UPDATE statements. 
    #Example 
    time eg '13:30:54.234', HH:MM:SS[.fff]
    timestamp  eg '2015-05-03 13:30:54.234' , '2011-02-03' , 'yyyy-mm-dd'T'HH:mm:ssZ'
    date eg '2011-12-25'  , yyyy-mm-dd
    
    Check for detail 
    https://docs.datastax.com/en/dse/5.1/cql/cql/cql_reference/refDateTimeFormats.html
    Driver client would convert them to appropriate eg java.sql
    For cqlsh uses ~/.cassandra/cqlshrc and the default format 
    ;; Used for displaying timestamps (and reading them with COPY)
    ; datetimeformat = %Y-%m-%d %H:%M:%S%z


#Methods 
uuid() 
    generates a random  uuid
    eg e7ae5cf3-d358-4d99-b900-85902fda9bb0
    
now()
    Generates a new unique timeuuid at the time the function is invoked 
    timeuuid is an uuid containing timestamp 
    making them ideal for use in applications requiring conflict-free timestamps
    
    
#Function name 	        Output type
currentTimestamp        timestamp
currentDate             date
currentTime             time
currentTimeUUID/now     timeUUID

#Function name 	Input type 	Description
toDate          timeuuid    Converts the timeuuid argument into a date type
toDate          timestamp   Converts the timestamp argument into a date type
toTimestamp     timeuuid    Converts the timeuuid argument into a timestamp type
toTimestamp     date        Converts the date argument into a timestamp type
toUnixTimestamp timeuuid    Converts the timeuuid argument into a bigInt raw value
toUnixTimestamp timestamp   Converts the timestamp argument into a bigInt raw value
toUnixTimestamp date        Converts the date argument into a bigInt raw value
dateOf          timeuuid    Similar to toTimestamp(timeuuid) (DEPRECATED)
unixTimestampOf timeuuid    Similar to toUnixTimestamp(timeuuid) (DEPRECATED)

#Example 
Use dummy; 

CREATE TABLE myTable (
    userid text PRIMARY KEY,
    username text,
    mydate date,  
    mytimestamp timestamp,
    mytime time, 
    myuuid  uuid ,
    mytimeuuid timeuuid,    
    count int
);
INSERT INTO myTable (userid, username, mydate, mytimestamp, mytime, 
    myuuid, mytimeuuid, count) 
    VALUES ( 'abc-123', 'dummy user', currentDate(), 
        currentTimestamp(), currentTime(), uuid(), now(), 2);

INSERT INTO myTable (userid, username, mydate, mytimestamp, mytime, 
    myuuid, mytimeuuid, count) 
    VALUES ( 'xyz-123', 'dummy user2', '2011-02-03', 
        '2015-05-03 13:30:54.234', '13:30:54.234', 
        5b6962dd-3f90-4c93-8f61-eabfa4a803e2, now(), 2);
    
#others are null
INSERT INTO myTable (userid, username, count) 
    VALUES ( 'xyz-1234', 'dummy user3', 2);
       
cqlsh> SELECT * FROM myTable;
 userid   | count | mydate     | mytime             | mytimestamp                     | mytimeuuid                           | myuuid                               | username
----------+-------+------------+--------------------+---------------------------------+--------------------------------------+--------------------------------------+-------------
  abc-123 |     2 | 2021-08-30 | 10:12:31.447377000 | 2021-08-30 10:12:31.446000+0000 | c997c670-097a-11ec-97f1-3b0edd44b0ae | 64d58408-545c-425d-93c5-43d4f53c6a8b |  dummy user
 xyz-1234 |     2 |       null |               null |                            null |          null                        |                                 null | dummy user3
  xyz-123 |     2 | 2011-02-03 | 13:30:54.234000000 | 2015-05-03 13:30:54.234000+0000 | db6210e0-097a-11ec-97f1-3b0edd44b0ae | 5b6962dd-3f90-4c93-8f61-eabfa4a803e2 | dummy user2
   
cqlsh> select toDate(mytimeuuid), toTimestamp(mytimeuuid) 
    from myTable where userid='abc-123';

 system.todate(mytimeuuid) | system.totimestamp(mytimeuuid)
---------------------------+---------------------------------
                2021-08-30 | 2021-08-30 10:12:31.447000+0000

#how to select timeuuid 
> SELECT * FROM myTable
 WHERE mytimeuuid > maxTimeuuid('2013-01-01 00:05+0000')
   AND mytimeuuid < minTimeuuid('2013-02-02 10:00+0000') ALLOW FILTERING;
   




##datetime function 
For example the last two days of data can be retrieved using:
> create index on myTable (mydate);

#Ny/mo/w/d/h/m/s - If h/m/s included , use currentTimestamp/currentTime

> SELECT * FROM myTable WHERE mydate >= currentDate() - 2d allow filtering;
> SELECT * FROM myTable WHERE mytimestamp >= currentTimestamp() - 1s allow filtering;

##Aggregate function 
#Count
> SELECT COUNT (*) FROM myTable;
> SELECT COUNT (1) FROM myTable;  //first col 
> SELECT COUNT (mydate) FROM myTable;

#Max and Min, Sum and AVG 
SELECT MIN (count), MAX (count), SUM(count), 
    avg(count) as AVG FROM myTable WHERE userid='abc-123';

##Understanding cast 
https://cassandra.apache.org/doc/latest/cassandra/cql/functions.html#cast

cqlsh> SELECT avg(cast(count as double)) FROM myTable;

 system.avg(cast(count as double))
-----------------------------------
                                 2



###Inserting JSON data into a table -- ADVANCED 
For JSON data all values can be inserted as a string 
if they are not a number,  will be stored using the column data type. 


cqlsh> INSERT INTO cycling.cyclist_category JSON '{
  "category" : "GC", 
  "points" : 780, 
  "id" : "829aa84a-4bba-411f-a4fb-38167a987cda",
  "lastname" : "SUTHERLAND" }';
  

A null value will be entered if a defined column like lastname, 
is not inserted into a table using JSON format.

cqlsh> INSERT INTO cycling.cyclist_category JSON '{
  "category" : "Sprint", 
  "points" : 700, 
  "id" : "829aa84a-4bba-411f-a4fb-38167a987cda"
}';

Check cassandra datatype vs json format below 
(eg most of CQL data type accept string json value 
and list/tuple/set accept json list)
https://cassandra.apache.org/doc/latest/cassandra/cql/json.html

To get json 
> SELECT JSON * FROM cycling.cyclist_category ;

#More retrival 

cqlsh> SELECT json lastname, firstname, teams 
    FROM cycling.cyclist_teams 
    WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;

{"lastname": "VOS", "firstname": "Marianne", 
"teams": {"2006": "Team DSB - Ballast Nedam", "2009": "DSB Bank- Nederland bloeit",
"2011": "Nederland bloeit", "2012": "Rabobank Women Team", "2015": "Rabobank-Liv Woman Cycling Team"}}

To specify the JSON format for a selected column, enclose its name in toJson(). 

cqlsh> SELECT lastname, firstname, toJson(teams) 
    FROM cycling.cyclist_teams 
    WHERE id=5b6962dd-3f90-4c93-8f61-eabfa4a803e2;



###Using lightweight transactions - CAS 
Note in cassandra Update is upsert and insert is update 

To make then conditional, Use  Compare and Set (CAS). (ie check exists and then update- atomic)
using IF . This is also called serialized transactions or LWT

INSERT INTO [keyspace_name.] table_name (column_list) VALUES (column_values) 
    [IF NOT EXISTS]
    
UPDATE [keyspace_name.] table_name SET assignment [, assignment] . . . WHERE row_specification
    [IF EXISTS | IF condition [AND condition] . . .] ;
    
DELETE [column_name (term)][, ...] FROM [keyspace_name.] table_name WHERE PK_column_conditions 
    [IF EXISTS | IF condition [AND condition] . . .]

A common use for lightweight transactions is an insertion operation 
that must be unique, such UserID creation 

Lightweight transactions should not be used casually,
as costly operations because Compare and set which involves 
4x round trip between client and server (uses Paxos concensus algorithm 
in distributed system)

Note in normal RDBMS, database/row  can be locked as in two pass trasaction algorithm
but when database is distributed, locking concensus is tricky, hence Paxos is 
a complex algorithm 

cqlsh> INSERT INTO cycling.cyclist_name (id, lastname, firstname)
  VALUES (4647f6d3-7bd2-4085-8d6c-1229351b5498, 'KNETEMANN', 'Roxxane')
  IF NOT EXISTS;

Perform a CAS operation against a row that does exist 

cqlsh> UPDATE cycling.cyclist_name
  SET firstname = 'Roxane'
  WHERE id = 4647f6d3-7bd2-4085-8d6c-1229351b5498
  IF firstname = 'Roxxane'; 



###Expiring data with time-to-live, TTL , in seconds
TTL is not supported on counter columns. 

Expiring data, using TTL  uses additional 8 bytes of memory 
and disk space to record the TTL and grace period.

To remove TTL from a column, set TTL to zero. 

##Setting a TTL for a table

>> CREATE TABLE [IF NOT EXISTS] keyspace_name.table_name ( 
   column_definition [, ...]
   PRIMARY KEY (column_name [, column_name ...])
WITH default_time_to_live = 0 ; //0 (disabled),max = 630720000 (20 years)

To set the TTL for data(one row), use the 'USING TTL seconds 'keywords. 
#86400 seconds(24 hours)

cqlsh> INSERT INTO cycling.calendar 
    (race_id, race_name, race_start_date, race_end_date) 
    VALUES (200, 'placeholder','2015-05-27', '2015-05-27') 
    USING TTL 86400;

Issue a SELECT statement to determine how much longer the data has to live.

cqlsh> SELECT TTL (race_name) from cycling.calendar 
    WHERE race_id = 200;

If you repeat this step after some time, the time-to-live value will decrease.

The time-to-live value can also be updated with the USING TTL keywords in an UPDATE

cqlsh> UPDATE cycling.calendar USING TTL 259200 
  SET race_name = 'Tour de France - Stage 12' 
  WHERE race_id = 200 AND race_start_date = '2015-05-27' 
  AND race_end_date = '2015-05-27';

cqlsh> SELECT TTL (race_name) from cycling.calendar WHERE race_id = 200;

Delete a column's existing TTL by setting its value to zero.

cqlsh> UPDATE cycling.calendar USING TTL 0 
  SET race_name = 'Tour de France - Stage 12' 
  WHERE race_id = 200 AND race_start_date = '2015-05-27' 
  AND race_end_date = '2015-05-27';


cqlsh> SELECT TTL (race_name) from cycling.calendar WHERE race_id = 200;

 ttl(race_name)
----------------
           null


###Inserting data using COPY and a CSV file

#cyclist_category.csv
category|point|id|lastname
GC|1269|829aa84a-4bba-411f-a4fb-38167a987cdb|TIRALONGO
One-day-races|367|829aa84a-4bba-411f-a4fb-38167a987cdc|TIRALONGO
GC|1324|829aa84a-4bba-411f-a4fb-38167a987cdd|KRUIJSWIJK

Check table 
cqlsh>  describe cycling.cyclist_category;

To insert the data, using the COPY command with CSV data.

cqlsh>  COPY cycling.cyclist_category 
    FROM 'cyclist_category.csv' WITH DELIMITER='|' 
    AND HEADER=TRUE;

cqlsh> select * from cycling.cyclist_category;

To export data 
cqlsh>  COPY cycling.cyclist_category TO 'cyclist_category2.csv' 
    WITH HEADER = TRUE;


###HandsON  

Create the cycling.cyclist_name_handson table:
  id UUID 
  lastname text
  firstname text 
    and PK is id 

Insert data into cycling.cyclist_name_handson:

5b6962dd-3f90-4c93-8f61-eabfa4a803e2, 'VOS','Marianne'
e7cd5752-bc0d-4157-a80f-7523add8dbcd, 'VAN DER BREGGEN','Anna'
e7ae5cf3-d358-4d99-b900-85902fda9bb0, 'FRAME','Alex'
220844bf-4860-49d6-9a4b-6b5d3a79cbfb, 'TIRALONGO','Paolo'
6ab09bec-e68e-48d9-a5f8-97e6fb4c9b47, 'KRUIKSWIJK','Steven'
fb372533-eb95-4bb4-8685-6ef61e994caa, 'MATTHEWS', 'Michael'


Export only the id and lastname columns from the cyclist_name table to a CSV file:

Copy the id and firstname to a different CSV file named cyclist_firstname.csv:

Remove all records from the cyclist name table:

Verify that there are no rows:

Import the cyclist first names:

Verify the new rows:

Import the last names:

Verify the that the records were updated:

Clear the data from the cyclist_name_handson table

##Further 
Start the copy input operation using the FROM STDIN option:

> COPY cycling.cyclist_name_handson FROM STDIN;

The line prompt changes to [copy]:

Using 7 child processes
              
Starting copy of cycling.cyclist_name with columns [id, firstname, lastname].
[Use . on a line by itself to end input]
[copy] e7cd5752-bc0d-4157-a80f-7523add8dbcd,Anna,VAN DER BREGGEN
[copy] .

Press Enter after the period:


Run this query to view the contents of the cyclist_name table:

> SELECT * FROM cycling.cyclist_name_handson;

 id                                   | firstname | lastname
--------------------------------------+-----------+-----------------
 e7cd5752-bc0d-4157-a80f-7523add8dbcd |      Anna | VAN DER BREGGEN
  
(1 rows)


###Retrieving the date/time a write occurred
The WRITETIME function applied to a column returns the date/time in microseconds 
at which the column was written to the database.

> select table_name from system_schema.tables;
> describe table cyclist_stats;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;

 writetime(firstname)
----------------------
     1622470237412000
     1622470237312000
     1622470237371000
     1622470237391000
     1622470237332000
     
     
The WRITETIME output in microseconds converts 
to November 15, 2012 at 12:16:34 GMT-8.

Note CQL timestamp 	is Date  with millisecond precision from EPOCH 

*** To use user-defined functions with Java or Javascript, 
enable_user_defined_functions must be set true in the cassandra.yaml 
file setting to enable the functions. 

$ vi /etc/cassandra/cassandra.yaml 

#Include some error, then it displays the generated code 
#eg input is converted to java.util.Date 
#can not include System.out.println(input); include and see the generated code to understand better  
> CREATE OR REPLACE FUNCTION toString (input timestamp) CALLED ON NULL INPUT RETURNS text 
    LANGUAGE java AS 
    $$
        long wrong_epoch = input.getTime();
        java.util.Date cdate = new java.util.Date((long)wrong_epoch/1000);
        return cdate.toString();
    $$;
    
    
> SELECT toString(WRITETIME (lastname ))  FROM cycling.cyclist_stats ;
 cycling.tostring(writetime(lastname))
---------------------------------------
          Tue Jan 18 09:53:32 UTC 2022
          Tue Jan 18 09:53:39 UTC 2022
          
Cassandra server date and time is Jan18 
check with $ date command         
          
Note By default WRITETIME is the SYSTEM time 
or we can change it with USING TIMESTAMP epoch_in_microseconds 

> INSERT INTO cycling.cyclist_stats (id, lastname, basics) VALUES (
  e7ae5cf3-d358-4d99-b900-85902fda9bb1, 
  'FRAME2', 
  { birthday : '1993-06-18', nationality : 'New Zealand', weight : null, height : null }
) USING  TIMESTAMP 123456789;  
//both TTL and TIMESTAMP // USING TTL 86400 AND TIMESTAMP 123456789;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;
writetime(lastname)
--------------------
          123456789
   1642499612808883
   1642499619689346
   
Unlike the INSERT command, the UPDATE command supports counters. 
Otherwise, the UPDATE and INSERT operations are identical.

> UPDATE cycling.cyclist_stats USING TIMESTAMP 123456799
    SET lastname = 'FRAME3'
    WHERE id = e7ae5cf3-d358-4d99-b900-85902fda9bb1;

> SELECT WRITETIME (lastname )  FROM cycling.cyclist_stats ;

###Querying a system table  
The system keyspace includes a number of tables that contain details 
about your Cassandra database objects  and cluster configuration.

Cassandra populates these tables and others in the 'system' keyspace.

#Table name 	    Column name 	Comment
available_ranges 	keyspace_name, ranges 	
batches 	        id, mutations, version 	
batchlog 	        id, data, version, written_at 	
built_views 	    keyspace_name, view_name 	Information on materialized views
compaction_history 	id, bytes_in, bytes_out, columnfamily_name, compacted_at, keyspace_name, rows_merged 	Information on compaction history
hints 	            target_id, hint_id, message_version, mutation 	
"IndexInfo" 	    table_name, index_name 	Information on indexes
local 	            key, bootstrapped, broadcast_address, cluster_name, cql_version, data_center, gossip_generation, host_id, listen_address, native_protocol_version, partitioner, rack, release_version, rpc_address, schema_version, thrift_version, tokens, truncated_at map 	Information on a node has about itself and a superset of gossip.
paxos 	            row_key, cf_id, in_progress_ballot, most_recent_commit, most_recent_commit_at, most_recent_commit_version, proposal, proposal_ballot, proposal_version 	Information on lightweight Paxos transactions
peers 	            peer, data_center, host_id, preferred_ip, rack, release_version, rpc_address, schema_version, tokens 	Each node records what other nodes tell it about themselves over the gossip.
peer_events 	    peer, hints_dropped 	
range_xfers 	    token_bytes,requested_at 	
size_estimates 	    keyspace_name, table_name, range_start, range_end, mean_partition_size, partitions_count 	Information on partitions
sstable_activity 	keyspace_name, columnfamily_name, generation, rate_120m, rate_15m 	
views_builds_in_progress 	keyspace_name, view_name, generation_number, last_token 	


Cassandra populates these tables in the 'system_schema' keyspace.
#Tables Table name 	Column name 	Comment
aggregates 	        keyspace_name, aggregate_name, argument_types, final_func, initcond, return_type, state_func, state_type 	Information about user-defined aggregates
columns 	        keyspace_name, table_name, column_name, clustering_order, column_name_bytes, kind, position, type 	Information about table columns
dropped_columns 	keyspace_name, table_name, column_name, dropped_time,type 	Information about dropped columns
functions 	        keyspace_name, function_name, argument_types, argument_names, body, called_on_null_input,language,return_type 	Information on user-defined functions
indexes 	        keyspace_name, table_name, index_name, kind,options 	Information about indexes
keyspaces 	        keyspace_name, durable_writes, replication 	Information on keyspace durable writes and replication
tables 	            keyspace_name, table_name, bloom_filter_fp_chance, caching, comment, compaction, compression, crc_check_chance, dclocal_read_repair_chance, default_time_to_live, extensions, flags, gc_grace_seconds, id, max_index_interval, memtable_flush_period_in_ms, min_index_interval, read_repair_chance, speculative_retry 	Information on columns and column indexes. Used internally for compound primary keys.
triggers 	        keyspace_name, table_name, trigger_name, options 	Information on triggers
types 	            keyspace_name, type_name, field_names, field_types 	Information about user-defined types
views 	            keyspace_name, view_name, base_table_id, base_table_name, bloom_filter_fp_chance, caching, comment, compaction, compression, crc_check_chance, dclocal_read_repair_chance, default_time_to_live, extensions, flags,gc_grace_seconds, include_all_columns, max_index_interval, memtable_flush_period_in_ms, min_index_interval, read_repair_chance, speculative_retry, where_clause 	Information about 

##Keyspace, table, and column information
Query the defined keyspaces using the SELECT statement.

cqlsh> SELECT * FROM system_schema.keyspaces;

 keyspace_name      | durable_writes | replication
--------------------+----------------+-------------------------------------------------------------------------------------
            cycling |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '1'}
               test |           True | {'Cassandra': '1', 'class': 'org.apache.cassandra.locator.NetworkTopologyStrategy'}
        system_auth |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '1'}
      system_schema |           True |  {'class': 'org.apache.cassandra.locator.LocalStrategy'}
          keyspace1 |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '2'}
 system_distributed |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '3'}
             system |           True |                             {'class': 'org.apache.cassandra.locator.LocalStrategy'}
      system_traces |           True | {'class': 'org.apache.cassandra.locator.SimpleStrategy', 'replication_factor': '2'}

(15 rows)

Get the schema information for tables in the cycling keyspace.

cqlsh> EXPAND ON; 
SELECT * FROM system_schema.tables  WHERE keyspace_name = 'cycling';

The following results shows the first record formatted with the cqlsh cqlshExpand ON option.

@ Row 1
-----------------------------+---------------------------------------------------------------------------------------------------------------------------
 keyspace_name               | cycling
 table_name                  | birthday_list
 bloom_filter_fp_chance      | 0.01
 caching                     | {'keys': 'ALL', 'rows_per_partition': 'NONE'}
 cdc                         | null
 comment                     |
 compaction                  | {'class': 'org.apache.cassandra.db.compaction.SizeTieredCompactionStrategy', 'max_threshold': '32', 'min_threshold': '4'}
 compression                 | {'chunk_length_in_kb': '64', 'class': 'org.apache.cassandra.io.compress.LZ4Compressor'}
 crc_check_chance            | 1
 dclocal_read_repair_chance  | 0.1
 default_time_to_live        | 0
 extensions                  | {'RLACA': 0x6379636c6973745f6e616d65} 
 flags                       | {'compound'}
 gc_grace_seconds            | 864000
 id                          | e439b922-2bc5-11e8-891b-23da85222d3d
 max_index_interval          | 2048
 memtable_flush_period_in_ms | 0
 min_index_interval          | 128
 nodesync                    | null
 read_repair_chance          | 0
 speculative_retry           | 99PERCENTILE
...

Get details about a table's columns from system_schema.columns.

cqlsh> 
SELECT * FROM system_schema.columns 
WHERE keyspace_name = 'cycling' AND table_name = 'cyclist_name';

 keyspace_name | table_name   | column_name | clustering_order | column_name_bytes    | kind          | position | type
---------------+--------------+-------------+------------------+----------------------+---------------+----------+------
       cycling | cyclist_name |   firstname |             none | 0x66697273746e616d65 |       regular |       -1 | text
       cycling | cyclist_name |          id |             none |               0x6964 | partition_key |        0 | uuid
       cycling | cyclist_name |    lastname |             none |   0x6c6173746e616d65 |       regular |       -1 | text

(3 rows)

Note: The system_schema table does NOT show search index or row-level access control settings.


##Cluster information
(No CLuster in our case) 
cqlsh> SELECT * FROM system.peers;

Output from querying the peers table looks something like this:

peer    | data_center | host_id     | preferred_ip | rack  | release_version | rpc_address | schema_version | tokens
-----------+-------------+-------------+--------------+-------+-----------------+-------------+----------------+-----------
127.0.0.3 | datacenter1 | edda8d72... |         null | rack1 |           2.1.0 | 127.0.0.3   | 59adb24e-f3... |  {3074...
127.0.0.2 | datacenter1 | ef863afa... |         null | rack1 |           2.1.0 | 127.0.0.2   | 3d19cd8f-c9... | {-3074...}
                    
(2 rows)

##Functions, aggregates, and user types
Show all user-defined functions in the system.schema_functions table.

cqlsh> SELECT * FROM system_schema.functions;

Show all user-defined aggregates in the system.schema_aggregates table.

cqlsh> SELECT * FROM system_schema.aggregates;

Show all user-defined types in the system.schema_usertypes table.

cqlsh> SELECT * FROM system_schema.types;



