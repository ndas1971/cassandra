package examples;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;
import java.net.InetSocketAddress;

//with docker 
public class Main2 {
  public static void main(String[] args) {
    String ip = "192.168.99.100";
    if (args.length > 0) {
        ip = args[0];
    }
    try (CqlSession session = CqlSession.builder().
        addContactPoint(new InetSocketAddress(ip, 9042)).
        withLocalDatacenter("datacenter1").build()) {
      ResultSet rs = session.execute("SELECT release_version FROM system.local");
      System.out.println(rs.one().getString(0));
      //OR 
      //System.out.println(row.getString("release_version"));  
    }
  }
}