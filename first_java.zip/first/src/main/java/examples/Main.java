package examples;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;


//with local but havving authenticator 

public class Main {
  public static void main(String[] args) {
    try (CqlSession session = CqlSession.builder().withAuthCredentials("cassandra", "cassandra").build()) {
      ResultSet rs = session.execute("SELECT release_version FROM system.local");
      System.out.println(rs.one().getString(0));
      //OR 
      //System.out.println(row.getString("release_version"));  
    }
  }
}